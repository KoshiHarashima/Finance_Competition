from datetime import datetime

import numpy as np
import pandas as pd
import pytest
import pytz  # type: ignore

from mlbacktester.bt import BackTester

jst = pytz.timezone("Asia/Tokyo")

CFG_PATH = "../config/example.yaml"


@pytest.fixture(scope="session")
def min_bar() -> pd.DataFrame:
    """ローソク足データを読み込む

    Returns:
        pd.DataFrame: ローソク足データ
    """
    min_bar = pd.DataFrame(
        {
            "timestamp": [
                pd.Timestamp("2021-01-01 00:00:00"),
                pd.Timestamp("2021-01-01 00:15:00"),
                pd.Timestamp("2021-01-01 00:30:00"),
                pd.Timestamp("2021-01-01 00:45:00"),
                pd.Timestamp("2021-01-01 01:00:00"),
                pd.Timestamp("2021-01-01 01:15:00"),
                pd.Timestamp("2021-01-01 01:30:00"),
                pd.Timestamp("2021-01-01 01:45:00"),
                pd.Timestamp("2021-01-01 02:00:00"),
                pd.Timestamp("2021-01-01 02:15:00"),
                pd.Timestamp("2021-01-01 02:30:00"),
                pd.Timestamp("2021-01-01 02:45:00"),
                pd.Timestamp("2021-01-01 03:00:00"),
                pd.Timestamp("2021-01-01 03:15:00"),
                pd.Timestamp("2021-01-01 03:30:00"),
                pd.Timestamp("2021-01-01 03:45:00"),
                pd.Timestamp("2021-01-01 04:00:00"),
                pd.Timestamp("2021-01-01 04:15:00"),
                pd.Timestamp("2021-01-01 04:30:00"),
                pd.Timestamp("2021-01-01 04:45:00"),
                pd.Timestamp("2021-01-01 05:00:00"),
                pd.Timestamp("2021-01-01 05:15:00"),
                pd.Timestamp("2021-01-01 05:30:00"),
                pd.Timestamp("2021-01-01 05:45:00"),
                pd.Timestamp("2021-01-01 06:00:00"),
                pd.Timestamp("2021-01-01 06:15:00"),
                pd.Timestamp("2021-01-01 06:30:00"),
                pd.Timestamp("2021-01-01 06:45:00"),
                pd.Timestamp("2021-01-01 07:00:00"),
                pd.Timestamp("2021-01-01 07:15:00"),
            ],
            "symbol": ["BTCUSDT"] * 30,
            "open": [100, 101, 102, 103, 104] * 6,
            "high": [101, 102, 103, 104, 105] * 6,
            "low": [99, 100, 101, 102, 103] * 6,
            "close": [100, 101, 102, 103, 104] * 6,
            "volume": [100, 100, 100, 100, 100] * 6,
        }
    )
    min_bar.set_index(["timestamp", "symbol"], inplace=True)
    """
    下のようなデータフレームをテストに使う
                                open  high  low  close  volume
    timestamp           symbol
    2021-01-01 00:00:00 BTCUSDT   100   101   99    100    100
    2021-01-01 00:15:00 BTCUSDT   101   102   100   101    100
    ...
    2021-01-01 07:15:00 BTCUSDT   104   105  103    104    100
    """
    return min_bar


@pytest.fixture(scope="session")
def fr_df() -> pd.DataFrame:
    """Funding Rateのヒストリカルデータを読み込む

    Returns:
        pd.DataFrame:
    """
    fr_df = pd.DataFrame(
        {
            "timestamp": [
                pd.Timestamp("2021-01-01 00:00:00"),
                pd.Timestamp("2021-01-01 01:00:00"),
                pd.Timestamp("2021-01-01 02:00:00"),
                pd.Timestamp("2021-01-01 03:00:00"),
                pd.Timestamp("2021-01-01 04:00:00"),
                pd.Timestamp("2021-01-01 05:00:00"),
                pd.Timestamp("2021-01-01 06:00:00"),
                pd.Timestamp("2021-01-01 07:00:00"),
            ],
            "symbol": ["BTCUSDT"] * 8,
            "fundingRate": [0.0001] * 8,
            "markPrice": [100.0] * 8,
        }
    )
    fr_df.set_index(["timestamp", "symbol"], inplace=True)
    """
    下のようなデータフレームをテストに使う
                                fundingRate  markPrice
    timestamp           symbol
    2021-01-01 00:00:00 BTCUSDT     0.0001        100
    2021-01-01 01:00:00 BTCUSDT     0.0001        100
    2021-01-01 02:00:00 BTCUSDT     0.0001        100
    2021-01-01 03:00:00 BTCUSDT     0.0001        100
    2021-01-01 04:00:00 BTCUSDT     0.0001        100
    2021-01-01 05:00:00 BTCUSDT     0.0001        100
    2021-01-01 06:00:00 BTCUSDT     0.0001        100
    2021-01-01 07:00:00 BTCUSDT     0.0001        100
    """
    return fr_df


@pytest.fixture(scope="function")
def bt(min_bar: pd.DataFrame, fr_df: pd.DataFrame) -> BackTester:
    """テスト対象のモジュールの読み込み

    Returns:
        Scoring: テスト対象のモジュール
    """
    cfg = {
        "trade_config": {
            "max_leverage": 2,
            "min_margin_rate": 0.5,
            "warmup_period": 100,
            "strategy_timeframe": "1h",
            "initial_margin_balance": 100000,
            "quote_currency": "USD",
        },
        "backtester_config": {
            "ohlcv_data_path": "./data/bybit_forward_traindata_15min_220320_231208_multi.pkl",
            "fr_data_path": "./data/bybit_BTCUSDT_fr_20200326_20240605.pkl",
            "time_zone": "Asia/Tokyo",
            "start_date": "2021-01-01",
            "end_date": "2021-01-02",
            "exchange": "binance",
            "symbol": ["BTCUSDT"],
            "backtest_timeframe": "15min",
            "slippage": 0.01,
            "delay": 0,
            "compounding_strategy": False,
            "use_wandb": False,
            "save_model": True,
            "logging": True,
            "position_in_fiat": True,
            "daily_position": True,
            "backtest_num_worker": 1,
            "get_model_num_worker": 1,
        },
        "exchange_config": {
            "BTCUSDT": {
                "min_lot": 0.001,
                "market_max_lot": 120,
                "limit_max_lot": 1000,
                "lot_size_currency": "BTC",
                "is_linear": True,
                "maker_fee": [{"start": None, "end": None, "value": 0.01}],
                "taker_fee": [{"start": None, "end": None, "value": 0.03}],
                "leverage_fee": [{"start": None, "end": None, "value": 0.04}],
                "tick_size": [
                    {
                        "start": None,
                        "end": jst.localize(datetime(2023, 2, 10, 17, 0)),
                        "value": 0.5,
                    },
                    {
                        "start": jst.localize(datetime(2023, 2, 10, 17, 0)),
                        "end": None,
                        "value": 0.1,
                    },
                ],
            }
        },
        "strategy_config": {
            "name": "sample_strategy",
            "file_path": "submission/sample_strategy.py",
        },
        "cv": {"type": "cpcv", "n_purge": 24, "n_path": 1},
        "wandb": {"pjt_name": "crypto-strategy", "entity": "mkj-fin", "tag": ""},
    }
    bt = BackTester(cfg)
    # テストでは15分足データを使う.
    # 15分足での経路に対して、1時間足ストラテジーを想定したテストを実施する
    raw_df = bt.data_initialize(min_bar, [], fr_df)
    """
    raw_dfは以下のようなデータフレーム
                                        open   high    low  close  volume
    timestamp                 symbol
    2021-01-01 00:00:00+09:00 BTCUSDT  100.0  104.0   99.0  103.0     400
    2021-01-01 01:00:00+09:00 BTCUSDT  104.0  105.0   99.0  102.0     400
    2021-01-01 02:00:00+09:00 BTCUSDT  103.0  105.0   99.0  101.0     400
    2021-01-01 03:00:00+09:00 BTCUSDT  102.0  105.0   99.0  100.0     400
    2021-01-01 04:00:00+09:00 BTCUSDT  101.0  105.0  100.0  104.0     400
    2021-01-01 05:00:00+09:00 BTCUSDT  100.0  104.0   99.0  103.0     400
    2021-01-01 06:00:00+09:00 BTCUSDT  104.0  105.0   99.0  102.0     400
    2021-01-01 07:00:00+09:00 BTCUSDT  103.0  105.0  102.0  104.0     200
    """
    bt.initialize()
    bt.data_handler.initialize(raw_df, raw_df)
    return bt


@pytest.fixture(scope="function")
def nan_bt(bt: BackTester):
    """欠損値処理のテスト対象の読み込み

    Returns:
        nan_bt: 欠損値を含むmin_barによるbt
    """
    # btと同様の設定を使う
    cfg = bt.cfg
    nan_bt = BackTester(cfg)
    # timestampの間隔に欠損を含むようにする
    nan_min_bar = bt.min_bar.copy(deep=True)
    nan_min_bar = nan_min_bar[
        nan_min_bar.index.get_level_values(0)
        != pd.Timestamp("2021-01-01 03:00:00", tz=cfg["backtester_config"]["time_zone"])
    ]
    nan_min_bar = nan_min_bar[
        nan_min_bar.index.get_level_values(0)
        != pd.Timestamp("2021-01-01 03:15:00", tz=cfg["backtester_config"]["time_zone"])
    ]
    nan_min_bar = nan_min_bar[
        nan_min_bar.index.get_level_values(0)
        != pd.Timestamp("2021-01-01 03:30:00", tz=cfg["backtester_config"]["time_zone"])
    ]
    nan_min_bar = nan_min_bar[
        nan_min_bar.index.get_level_values(0)
        != pd.Timestamp("2021-01-01 03:45:00", tz=cfg["backtester_config"]["time_zone"])
    ]
    # 値に欠損を含むようにする
    nan_min_bar["close"][
        nan_min_bar.index.get_level_values(0)
        == pd.Timestamp("2021-01-01 01:00:00", tz=cfg["backtester_config"]["time_zone"])
    ] = np.nan
    nan_min_bar["close"][
        nan_min_bar.index.get_level_values(0)
        == pd.Timestamp("2021-01-01 01:15:00", tz=cfg["backtester_config"]["time_zone"])
    ] = np.nan
    nan_min_bar["close"][
        nan_min_bar.index.get_level_values(0)
        == pd.Timestamp("2021-01-01 01:30:00", tz=cfg["backtester_config"]["time_zone"])
    ] = np.nan
    nan_min_bar["close"][
        nan_min_bar.index.get_level_values(0)
        == pd.Timestamp("2021-01-01 01:45:00", tz=cfg["backtester_config"]["time_zone"])
    ] = np.nan
    print(nan_min_bar)
    fr_df = pd.DataFrame(columns=["fundingRate", "markPrice"])
    nan_raw_df = nan_bt.data_initialize(nan_min_bar, [], fr_df)
    """
    nan_raw_dfは以下のようなデータフレーム
                                        open   high    low  close  volume
    timestamp                 symbol
    2021-01-01 00:00:00+09:00 BTCUSDT  100.0  104.0   99.0  103.0     400
    2021-01-01 01:00:00+09:00 BTCUSDT  104.0  105.0   99.0  103.0     400
    2021-01-01 02:00:00+09:00 BTCUSDT  103.0  105.0   99.0  101.0     400
    2021-01-01 03:00:00+09:00 BTCUSDT  101.0  101.0  101.0  101.0       0
    2021-01-01 04:00:00+09:00 BTCUSDT  101.0  105.0  100.0  104.0     400
    2021-01-01 05:00:00+09:00 BTCUSDT  100.0  104.0   99.0  103.0     400
    2021-01-01 06:00:00+09:00 BTCUSDT  104.0  105.0   99.0  102.0     400
    2021-01-01 07:00:00+09:00 BTCUSDT  103.0  105.0  102.0  104.0     200
    """
    nan_bt.initialize()
    print(nan_raw_df)
    nan_bt.data_handler.initialize(nan_raw_df, nan_raw_df)
    return nan_bt
