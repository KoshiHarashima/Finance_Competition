import pandas as pd

from mlbacktester.bt import BackTester


def test_data_min_step(bt: BackTester):
    """data_handlerのmin_stepが正しく動いているか確認する

    Args:
        bt (BackTester): BackTester
    """
    latest_bar = bt.data_handler.latest_bar
    latest_timestamp = bt.data_handler.latest_timestamp
    assert latest_bar.index[0][0] == pd.Timestamp(
        "2021-01-01 00:00:00", tz="Asia/Tokyo"
    )
    assert latest_timestamp == pd.Timestamp("2021-01-01 00:15:00", tz="Asia/Tokyo")
    # NOTE: latest_barは15分ずつ更新される
    # latest_barのtimestampはopenの時刻, latest_timestampはcloseの時刻になっている.
    bt.data_handler.min_step()
    latest_bar = bt.data_handler.latest_bar
    latest_timestamp = bt.data_handler.latest_timestamp
    assert latest_bar.index[0][0] == pd.Timestamp(
        "2021-01-01 00:15:00", tz="Asia/Tokyo"
    ), "latest_barが正しく更新されていない"
    assert latest_timestamp == pd.Timestamp(
        "2021-01-01 00:30:00", tz="Asia/Tokyo"
    ), "latest_timestampが正しく更新されていない"
    bt.data_handler.min_step()
    latest_bar = bt.data_handler.latest_bar
    latest_timestamp = bt.data_handler.latest_timestamp
    assert latest_bar.index[0][0] == pd.Timestamp(
        "2021-01-01 00:30:00", tz="Asia/Tokyo"
    ), "latest_barが正しく更新されていない"
    assert latest_timestamp == pd.Timestamp(
        "2021-01-01 00:45:00", tz="Asia/Tokyo"
    ), "latest_timestampが正しく更新されていない"


def test_data_step(bt: BackTester):
    """data_handlerのstepが正しく動いているか確認する

    Args:
        bt (BackTester): BackTester
    """
    latest_signal = bt.data_handler.latest_signal
    next_order_timestamp = bt.data_handler.next_order_timestamp
    assert latest_signal.index[0][0] == pd.Timestamp(
        "2021-01-01 00:00:00", tz="Asia/Tokyo"
    )
    assert next_order_timestamp == pd.Timestamp("2021-01-01 01:00:00", tz="Asia/Tokyo")
    # NOTE: latest_signalは1時間ずつ更新される
    # latest_signalのtimestampはその時点の時刻, next_order_timestampは次の発注時刻になっている.
    bt.data_handler.step()
    latest_signal = bt.data_handler.latest_signal
    next_order_timestamp = bt.data_handler.next_order_timestamp
    assert latest_signal.index[0][0] == pd.Timestamp(
        "2021-01-01 01:00:00", tz="Asia/Tokyo"
    ), "latest_signalが正しく更新されていない"
    assert next_order_timestamp == pd.Timestamp(
        "2021-01-01 02:00:00", tz="Asia/Tokyo"
    ), "next_order_timestampが正しく更新されていない"

    bt.data_handler.step()
    latest_signal = bt.data_handler.latest_signal
    next_order_timestamp = bt.data_handler.next_order_timestamp
    assert latest_signal.index[0][0] == pd.Timestamp(
        "2021-01-01 02:00:00", tz="Asia/Tokyo"
    ), "latest_signalが正しく更新されていない"
    assert next_order_timestamp == pd.Timestamp(
        "2021-01-01 03:00:00", tz="Asia/Tokyo"
    ), "next_order_timestampが正しく更新されていない"


def test_latest_funding_record(bt: BackTester):
    """data_handlerのlatest_funding_recordが正しく動いているか確認する"""
    timestamp_list = [
        pd.Timestamp("2021-01-01 01:00:00", tz="Asia/Tokyo"),
        pd.Timestamp("2021-01-01 02:00:00", tz="Asia/Tokyo"),
        pd.Timestamp("2021-01-01 03:00:00", tz="Asia/Tokyo"),
        pd.Timestamp("2021-01-01 04:00:00", tz="Asia/Tokyo"),
    ]
    # 開始時latest_timestampは00:15:00なので01:00:00まで進める
    for timestamp in timestamp_list:
        for _ in range(3):
            latest_funding_record = bt.data_handler.latest_funding_record
            assert latest_funding_record.empty
            bt.data_handler.min_step()
        # latest_timestampが01:00:00の時、funding rateの更新がある
        latest_funding_record = bt.data_handler.latest_funding_record
        assert len(latest_funding_record) == 1
        assert latest_funding_record.index[0][0] == timestamp
        bt.data_handler.step()
        bt.data_handler.min_step()


def test_raw_df_and_signal_index(bt: BackTester):
    """data_handlerの_raw_dfと_signalsのindexが一致しているか確認する"""
    assert bt.data_handler._signals.index.equals(bt.data_handler._raw_df.index)
