import numpy as np
import pandas as pd

from mlbacktester.bt import BackTester


def test_min_bar_nanprocess(nan_bt: BackTester):
    """min_barの欠損値が正しく処理されていることを確認する"""
    min_bar = nan_bt.min_bar
    assert (
        min_bar.reset_index().notnull().all().all()
    ), "min_barに欠損値が存在しています"

    start_date = min_bar.index[0][0]
    end_date = min_bar.index[-1][0]
    min_bar_idx = np.array(min_bar.index.get_level_values(0).unique())
    true_min_bar_idx = np.array(
        pd.date_range(
            start_date,
            end_date,
            freq=nan_bt.cfg["backtester_config"]["backtest_timeframe"],
        )
    )
    print(min_bar_idx)
    print(true_min_bar_idx)
    assert np.array_equal(
        min_bar_idx, true_min_bar_idx
    ), "min_barのtimestampの間隔が一定ではありません"


def test_raw_df_nanprocess(nan_bt: BackTester):
    """raw_dfの欠損値が正しく処理されていることを確認する"""
    raw_df = nan_bt.raw_df
    assert raw_df.reset_index().notnull().all().all(), "raw_dfに欠損値が存在しています"

    start_date = raw_df.index[0][0]
    end_date = raw_df.index[-1][0]
    raw_df_idx = np.array(raw_df.index.get_level_values(0).unique())
    true_raw_df_idx = np.array(
        pd.date_range(
            start_date, end_date, freq=nan_bt.cfg["trade_config"]["strategy_timeframe"]
        )
    )
    print(raw_df_idx)
    print(true_raw_df_idx)
    assert np.array_equal(
        raw_df_idx, true_raw_df_idx
    ), "raw_dfのtimestampの間隔が一定ではありません"
