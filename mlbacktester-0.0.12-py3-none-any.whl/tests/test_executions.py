from collections import deque

import numpy as np
import pandas as pd

from mlbacktester.bt import BackTester
from mlbacktester.utils.custom_types import OrderEvent


def test_market_order(bt: BackTester):
    """market orderが正しく動いているか確認する"""
    order_event = OrderEvent(
        type="MARKET",
        side="BUY",
        size=0.01,
        price=None,
        timestamp=pd.Timestamp("2021-01-01 00:00:00", tz="Asia/Tokyo"),
    )
    # order_eventを追加
    bt.event_handler.append_order_event(order_event, "BTCUSDT")
    bt.event_handler.append_order_history(order_event, "BTCUSDT")
    # order_eventがキューに追加されているか確認
    assert bt.event_handler.order_events["BTCUSDT"] == deque([order_event])
    assert bt.event_handler.order_history["BTCUSDT"] == [order_event]
    assert bt.event_handler.fill_events["BTCUSDT"] == []
    bt.data_handler.min_step()
    bt.exec_handler.execute()
    # market orderが正しく動いているか確認
    # market orderは即約定するので、order_eventから削除され、fill_eventとopen_positionに追加される
    assert len(bt.event_handler.order_events["BTCUSDT"]) == 0
    assert len(bt.event_handler.fill_events["BTCUSDT"]) == 1
    assert len(bt.pos_manager.open_positions["BTCUSDT"]) == 1


def test_limit_order(bt: BackTester):
    """limit orderが正しく動いているか確認する"""
    # 開始時刻は00:15:00なので、次の注文時刻01:00:00まで進める
    for _ in range(3):
        bt.data_handler.min_step()
    # 約定できる指値のケース(安値より高い値を指定)
    # 発注時刻を確認
    assert bt.data_handler.latest_timestamp == pd.Timestamp(
        "2021-01-01 01:00:00", tz="Asia/Tokyo"
    )
    order_event = OrderEvent(
        type="LIMIT",
        side="BUY",
        size=0.01,
        price=100,
        timestamp=pd.Timestamp("2021-01-01 01:00:00", tz="Asia/Tokyo"),
        minutes_to_expire=60,
    )
    # order_eventを追加
    bt.event_handler.append_order_event(order_event, "BTCUSDT")
    bt.event_handler.append_order_history(order_event, "BTCUSDT")
    # order_eventがキューに追加されているか確認
    assert bt.event_handler.order_events["BTCUSDT"] == deque([order_event])
    assert bt.event_handler.order_history["BTCUSDT"] == [order_event]
    assert bt.event_handler.fill_events["BTCUSDT"] == []
    # 15分 x 4回更新する. この間に指値注文が約定する設定でのテスト
    for _ in range(4):
        bt.data_handler.min_step()
        bt.exec_handler.execute()
    bt.data_handler.step()
    # limit orderが正しく動いているか確認
    # order_eventから削除され、fill_eventとopen_positionに追加される
    assert bt.event_handler.order_events["BTCUSDT"] == deque([])
    assert len(bt.event_handler.fill_events["BTCUSDT"]) == 1
    assert len(bt.pos_manager.open_positions["BTCUSDT"]) == 1
    assert len(bt.event_handler.order_history["BTCUSDT"]) == 1
    assert len(bt.event_handler.expired_orders["BTCUSDT"]) == 0

    # 約定できない指値のケース(安値より低い値を指定)
    # 発注時刻を確認
    assert bt.data_handler.latest_timestamp == pd.Timestamp(
        "2021-01-01 02:00:00", tz="Asia/Tokyo"
    )
    order_event = OrderEvent(
        type="LIMIT",
        side="BUY",
        size=0.01,
        price=90,
        timestamp=pd.Timestamp("2021-01-01 02:00:00", tz="Asia/Tokyo"),
        minutes_to_expire=60,
    )
    # order_eventを追加
    bt.event_handler.append_order_event(order_event, "BTCUSDT")
    bt.event_handler.append_order_history(order_event, "BTCUSDT")
    # order_eventがキューに追加されているか確認
    assert bt.event_handler.order_events["BTCUSDT"] == deque([order_event])
    # 15分 x 4回進める. この間に指値注文は約定しない設定でのテスト
    for _ in range(4):
        bt.data_handler.min_step()
        bt.exec_handler.execute()
    bt.data_handler.step()
    # latest_timestampが2021-01-01 03:00:00時点では注文が残っている
    assert bt.data_handler.latest_timestamp == pd.Timestamp(
        "2021-01-01 03:00:00", tz="Asia/Tokyo"
    )
    assert bt.event_handler.order_events["BTCUSDT"] == deque([order_event])
    # 次の15分先に進める.この間に注文がキャンセルされる
    bt.data_handler.min_step()
    bt.exec_handler.execute()
    # latest_timestampが2021-01-01 03:15:00で注文が失効する
    assert bt.data_handler.latest_timestamp == pd.Timestamp(
        "2021-01-01 03:15:00", tz="Asia/Tokyo"
    )
    # order_eventから削除され、expired_ordersに追加される
    assert bt.event_handler.order_events["BTCUSDT"] == deque([])
    assert len(bt.event_handler.fill_events["BTCUSDT"]) == 1
    assert len(bt.pos_manager.open_positions["BTCUSDT"]) == 1
    assert len(bt.event_handler.order_history["BTCUSDT"]) == 2
    assert len(bt.event_handler.expired_orders["BTCUSDT"]) == 1


def test_stop_order(bt: BackTester):
    """stop orderが正しく動いているか確認する"""
    # 開始時刻は00:15:00なので、次の注文時刻01:00:00まで進める
    for _ in range(3):
        bt.data_handler.min_step()
    # 約定できる逆指値のケース(高値より低い値を指定)
    # 発注時刻を確認
    assert bt.data_handler.latest_timestamp == pd.Timestamp(
        "2021-01-01 01:00:00", tz="Asia/Tokyo"
    )
    order_event = OrderEvent(
        type="STOP",
        side="BUY",
        size=0.01,
        price=104,
        timestamp=pd.Timestamp("2021-01-01 01:00:00", tz="Asia/Tokyo"),
        minutes_to_expire=60,
    )
    # order_eventを追加
    bt.event_handler.append_order_event(order_event, "BTCUSDT")
    bt.event_handler.append_order_history(order_event, "BTCUSDT")
    # order_eventがキューに追加されているか確認
    assert bt.event_handler.order_events["BTCUSDT"] == deque([order_event])
    assert bt.event_handler.order_history["BTCUSDT"] == [order_event]
    assert bt.event_handler.fill_events["BTCUSDT"] == []
    # 15分 x 4回更新する. この間に指値注文が約定する設定でのテスト
    for _ in range(4):
        bt.data_handler.min_step()
        bt.exec_handler.execute()
    bt.data_handler.step()
    # limit orderが正しく動いているか確認
    # order_eventから削除され、fill_eventとopen_positionに追加される
    assert bt.event_handler.order_events["BTCUSDT"] == deque([])
    assert len(bt.event_handler.fill_events["BTCUSDT"]) == 1
    assert len(bt.pos_manager.open_positions["BTCUSDT"]) == 1
    assert len(bt.event_handler.order_history["BTCUSDT"]) == 1
    assert len(bt.event_handler.expired_orders["BTCUSDT"]) == 0

    # 約定できない指値のケース(高値より上の値を指定)
    # 発注時刻を確認
    assert bt.data_handler.latest_timestamp == pd.Timestamp(
        "2021-01-01 02:00:00", tz="Asia/Tokyo"
    )
    order_event = OrderEvent(
        type="STOP",
        side="BUY",
        size=0.01,
        price=106,
        timestamp=pd.Timestamp("2021-01-01 02:00:00", tz="Asia/Tokyo"),
        minutes_to_expire=60,
    )
    # order_eventを追加
    bt.event_handler.append_order_event(order_event, "BTCUSDT")
    bt.event_handler.append_order_history(order_event, "BTCUSDT")
    # order_eventがキューに追加されているか確認
    assert bt.event_handler.order_events["BTCUSDT"] == deque([order_event])
    # 15分 x 4回更新する. この間に逆指値注文は約定しない設定でのテスト
    for _ in range(4):
        bt.data_handler.min_step()
        bt.exec_handler.execute()
    bt.data_handler.step()
    # latest_timestampが2021-01-01 03:00:00時点では注文が残っている
    assert bt.data_handler.latest_timestamp == pd.Timestamp(
        "2021-01-01 03:00:00", tz="Asia/Tokyo"
    )
    assert bt.event_handler.order_events["BTCUSDT"] == deque([order_event])
    # 15分先に進める.この間に注文がキャンセルされる
    bt.data_handler.min_step()
    bt.exec_handler.execute()
    # latest_timestampが2021-01-01 03:15:00で注文が失効する
    assert bt.data_handler.latest_timestamp == pd.Timestamp(
        "2021-01-01 03:15:00", tz="Asia/Tokyo"
    )
    # order_eventから削除され、expired_ordersに追加される
    assert bt.event_handler.order_events["BTCUSDT"] == deque([])
    assert len(bt.event_handler.fill_events["BTCUSDT"]) == 1
    assert len(bt.pos_manager.open_positions["BTCUSDT"]) == 1
    assert len(bt.event_handler.order_history["BTCUSDT"]) == 2
    assert len(bt.event_handler.expired_orders["BTCUSDT"]) == 1


def test_open_position(bt: BackTester):
    """約定イベントによるopen_positionの更新が正しく動いているか確認する"""
    # 開始時刻は00:15:00なので、次の注文時刻01:00:00まで進める
    for _ in range(3):
        bt.data_handler.min_step()
    # 発注時刻を確認
    assert bt.data_handler.latest_timestamp == pd.Timestamp(
        "2021-01-01 01:00:00", tz="Asia/Tokyo"
    )
    order_event = OrderEvent(
        type="MARKET",
        side="BUY",
        size=0.01,
        price=None,
        timestamp=pd.Timestamp("2021-01-01 01:00:00", tz="Asia/Tokyo"),
    )
    # order_eventを追加
    bt.event_handler.append_order_event(order_event, "BTCUSDT")
    bt.event_handler.append_order_history(order_event, "BTCUSDT")
    for _ in range(4):
        bt.data_handler.min_step()
        bt.exec_handler.execute()
    # market orderでopen_positionが正しく更新されているか確認
    assert len(bt.pos_manager.open_positions["BTCUSDT"]) == 1
    # exitする
    # 発注時刻を確認
    assert bt.data_handler.latest_timestamp == pd.Timestamp(
        "2021-01-01 02:00:00", tz="Asia/Tokyo"
    )
    order_event = OrderEvent(
        type="MARKET",
        side="SELL",
        size=0.01,
        price=None,
        timestamp=pd.Timestamp("2021-01-01 02:00:00", tz="Asia/Tokyo"),
        exit=True,
        exit_id=bt.pos_manager.open_positions["BTCUSDT"][0].id,
    )
    # order_eventを追加
    bt.event_handler.append_order_event(order_event, "BTCUSDT")
    bt.event_handler.append_order_history(order_event, "BTCUSDT")
    for _ in range(4):
        bt.data_handler.min_step()
        bt.exec_handler.execute()
    # exit orderでopen_positionが正しく更新されているか確認
    assert len(bt.pos_manager.open_positions["BTCUSDT"]) == 0
    assert len(bt.event_handler.close_events["BTCUSDT"]) == 1

    # 2つのopen_positionを作成する
    # 発注時刻を確認
    assert bt.data_handler.latest_timestamp == pd.Timestamp(
        "2021-01-01 03:00:00", tz="Asia/Tokyo"
    )
    order_event = OrderEvent(
        type="MARKET",
        side="BUY",
        size=0.01,
        price=None,
        timestamp=pd.Timestamp("2021-01-01 03:00:00", tz="Asia/Tokyo"),
    )
    # order_eventを追加
    bt.event_handler.append_order_event(order_event, "BTCUSDT")
    bt.event_handler.append_order_history(order_event, "BTCUSDT")
    bt.event_handler.append_order_event(order_event, "BTCUSDT")
    bt.event_handler.append_order_history(order_event, "BTCUSDT")
    bt.event_handler.append_order_event(order_event, "BTCUSDT")
    bt.event_handler.append_order_history(order_event, "BTCUSDT")
    for _ in range(4):
        bt.data_handler.min_step()
        print(bt.data_handler.latest_timestamp)
        bt.exec_handler.execute()
    # market orderでopen_positionが正しく更新されているか確認
    assert len(bt.pos_manager.open_positions["BTCUSDT"]) == 3
    # 1つだけidを指定せずexitする
    # 発注時刻を確認
    assert bt.data_handler.latest_timestamp == pd.Timestamp(
        "2021-01-01 04:00:00", tz="Asia/Tokyo"
    )
    order_event = OrderEvent(
        type="MARKET",
        side="SELL",
        size=0.01,
        price=None,
        timestamp=pd.Timestamp("2021-01-01 04:00:00", tz="Asia/Tokyo"),
        exit=True,
    )
    bt.event_handler.append_order_event(order_event, "BTCUSDT")
    bt.event_handler.append_order_history(order_event, "BTCUSDT")
    # 1つだけidを指定してexitする
    order_event = OrderEvent(
        type="MARKET",
        side="SELL",
        size=0.01,
        price=None,
        timestamp=pd.Timestamp("2021-01-01 04:00:00", tz="Asia/Tokyo"),
        exit=True,
        exit_id="4",
    )
    # order_eventを追加
    bt.event_handler.append_order_event(order_event, "BTCUSDT")
    bt.event_handler.append_order_history(order_event, "BTCUSDT")
    for _ in range(4):
        bt.data_handler.min_step()
        print(bt.data_handler.latest_timestamp)
        bt.exec_handler.execute()
    # exit orderでopen_positionが正しく更新されているか確認
    # 先頭(exit_id指定なし)と最後(exit_idを指定した)open_positionがexitされているはず
    assert len(bt.pos_manager.open_positions["BTCUSDT"]) == 1
    assert bt.pos_manager.open_positions["BTCUSDT"][0].id == "3"
    assert len(bt.event_handler.close_events["BTCUSDT"]) == 3


def test_calc_profit(bt: BackTester):
    # 設定した注文による利益と実際の計算が正しいかを確認
    # funding feeとレバレッジ手数料が正しく計算されているかを確認
    # 設定
    # 01:00:00-02:00:00 -> 102円で1000枚買
    # 02:00:00-03:00:00 -> 100円で1000枚売、1000枚買
    # 03:00:00-04:00:00 -> 待機
    # 04:00:00-05:00:00 -> 待機
    # 05:00:00-06:00:00 -> 待機
    # 06:00:00-07:00:00 -> 105円で1000枚売
    # 開始時刻は00:15:00なので、次の注文時刻01:00:00まで進める
    for _ in range(3):
        bt.data_handler.min_step()
    # 01:00:00-02:00:00 -> 102円で1000枚買
    # 発注時刻を確認
    assert bt.data_handler.latest_timestamp == pd.Timestamp(
        "2021-01-01 01:00:00", tz="Asia/Tokyo"
    )
    order_event = OrderEvent(
        type="LIMIT",
        side="BUY",
        size=1000,
        price=102,
        timestamp=pd.Timestamp("2021-01-01 01:00:00", tz="Asia/Tokyo"),
        minutes_to_expire=60,
    )
    # order_eventを追加
    bt.event_handler.append_order_event(order_event, "BTCUSDT")
    bt.event_handler.append_order_history(order_event, "BTCUSDT")
    for _ in range(4):
        bt.data_handler.min_step()
        bt.pos_manager.update_funding_fee()
        bt.exec_handler.execute()
        bt.pos_manager.calc_statistic()
        bt.pos_manager.take_snapshot()
    bt.data_handler.step()
    # 02:00:00-03:00:00 -> 100円で1000枚売
    # 発注時刻を確認
    assert bt.data_handler.latest_timestamp == pd.Timestamp(
        "2021-01-01 02:00:00", tz="Asia/Tokyo"
    )
    order_event = OrderEvent(
        type="LIMIT",
        side="SELL",
        size=1000,
        price=100,
        timestamp=pd.Timestamp("2021-01-01 02:00:00", tz="Asia/Tokyo"),
        minutes_to_expire=60,
    )
    # order_eventを追加
    bt.event_handler.append_order_event(order_event, "BTCUSDT")
    bt.event_handler.append_order_history(order_event, "BTCUSDT")
    # 02:00:00-03:00:00 -> 100円で1000枚買
    order_event = OrderEvent(
        type="LIMIT",
        side="BUY",
        size=1000,
        price=100,
        timestamp=pd.Timestamp("2021-01-01 02:00:00", tz="Asia/Tokyo"),
        minutes_to_expire=60,
    )
    # order_eventを追加
    bt.event_handler.append_order_event(order_event, "BTCUSDT")
    bt.event_handler.append_order_history(order_event, "BTCUSDT")
    for _ in range(4):
        bt.data_handler.min_step()
        bt.pos_manager.update_funding_fee()
        bt.exec_handler.execute()
        bt.pos_manager.calc_statistic()
        bt.pos_manager.take_snapshot()
    bt.data_handler.step()
    # 03:00:00-06:00:00 -> 待機
    for __ in range(3):
        for _ in range(4):
            bt.data_handler.min_step()
            bt.pos_manager.update_funding_fee()
            bt.exec_handler.execute()
            bt.pos_manager.calc_statistic()
            bt.pos_manager.take_snapshot()
        bt.data_handler.step()
    # 06:00:00-07:00:00 -> 105円で1000枚売
    # 発注時刻を確認
    assert bt.data_handler.latest_timestamp == pd.Timestamp(
        "2021-01-01 06:00:00", tz="Asia/Tokyo"
    )
    order_event = OrderEvent(
        type="LIMIT",
        side="SELL",
        size=1000,
        price=105,
        timestamp=pd.Timestamp("2021-01-01 06:00:00", tz="Asia/Tokyo"),
        minutes_to_expire=60,
    )
    # order_eventを追加
    bt.event_handler.append_order_event(order_event, "BTCUSDT")
    bt.event_handler.append_order_history(order_event, "BTCUSDT")
    for _ in range(4):
        bt.data_handler.min_step()
        bt.pos_manager.update_funding_fee()
        bt.exec_handler.execute()
        bt.pos_manager.calc_statistic()
        bt.pos_manager.take_snapshot()
    bt.data_handler.step()
    # 想定利益
    # 1000枚で102買->100売, 100買->105売 の2回の売買で最終3000円のrpnl, upnlは0円
    # 手数料(maker fee) = 102×1000×0.01% + 100×1000×0.01% × 2 + 105×1000×0.01% = 40.7円
    # Funding Fee = 1000×100×0.0001 × 5 = 50円
    # Leverage Fee = 1000×100×0.0004 = 40円
    # 合わせて2869.3円の利益のはずなので、
    # score(pnl/initial_mbalance) = 2869.3 / 100000 = 0.028693
    # max drawdownは05:15:00時点, それ以前の最大effective_marginは101949.8より
    # max_dd = [{100000 - (2000 + 102×1000×0.01% + 100×1000×0.01% × 2 + 1000×100×0.01% × 4)} - 101949.8] / 100000 = -0.040200
    # sharpe_ratio = 対数利益率 / リターン標準偏差 だが、リターンのリサンプリング間隔が1日なのでリターン標準偏差が求まらずsharpe_ratioはnanになる
    bt.stats.make_stats()
    # bt.stats.save_results("logs.pkl", "fills.pkl")
    assert (
        round(bt.stats.stats["pnl/initial_balance"], 7) == 0.028693
    ), "scoreの計算結果が想定と異なります"
    assert (
        round(bt.stats.stats["max_dd"], 7) == -0.040200
    ), "max_ddの計算結果が想定と異なります"
    assert np.isnan(
        bt.stats.stats["annual_sharpe_ratio"]
    ), "sharpe_ratioの計算結果が想定と異なります"
