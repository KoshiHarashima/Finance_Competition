from typing import Any

import hydra


def log_info_if_enabled(message: Any, logging_enabled: bool = True) -> None:
    """
    Log the provided message if logging is enabled.

    Parameters:
    - logging_enabled (bool): A flag indicating whether logging is enabled.
    - message (str): The message to log.
    """
    if logging_enabled:
        hydra.utils.log.info(message)
