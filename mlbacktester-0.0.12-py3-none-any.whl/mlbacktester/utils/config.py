# Third Party Library
from omegaconf import DictConfig, OmegaConf

from .exchanges import load_exchange_cfg


def override_cfg(cfg: DictConfig) -> dict:
    if isinstance(cfg, DictConfig):
        cfg = OmegaConf.to_container(cfg)  # type: ignore

    ex_cfgs = {}
    symbols = cfg["backtester_config"]["symbol"]
    for symbol in symbols:
        ex_cfgs[symbol] = load_exchange_cfg(
            cfg["backtester_config"]["exchange"], symbol
        )

    # ユーザー指定された設定を優先
    if cfg.get("exchange_config") is None:
        cfg["exchange_config"] = dict()

    for symbol, ex_cfg in ex_cfgs.items():
        if symbol not in cfg["exchange_config"]:
            cfg["exchange_config"][symbol] = dict()
        preserved_keys = set(cfg["exchange_config"].get(symbol, {}).keys())
        for key, value in ex_cfg.items():
            if key not in preserved_keys:
                cfg["exchange_config"][symbol][key] = value

    CURRENCIES = ["USD", "USDT", "JPY", "BTC"]

    initial_margin_balance = cfg.get("trade_config", {}).get("initial_margin_balance")
    quote_currency = cfg.get("trade_config", {}).get("quote_currency")

    if isinstance(initial_margin_balance, str) and initial_margin_balance.endswith(
        tuple(CURRENCIES)
    ):
        if quote_currency is not None:
            raise ValueError("Cannot specify quote_currency with old margin notation")
        cfg["trade_config"]["initial_margin_balance"] = float(
            initial_margin_balance.rstrip("".join(CURRENCIES))
        )
        cfg["trade_config"]["quote_currency"] = initial_margin_balance.rstrip(
            "1234567890."
        )
    elif isinstance(initial_margin_balance, (int, float)):
        if quote_currency not in CURRENCIES:
            raise ValueError(
                "quote_currency must be one of the valid currencies with new margin notation"
            )
    else:
        raise ValueError("Invalid margin format")

    return cfg  # type: ignore


def load_cfg(cfg_path: str) -> dict:
    cfg = override_cfg(OmegaConf.load(cfg_path))  # type: ignore

    # cfgのチェック
    if cfg.get("backtester_config") is None:
        raise KeyError("backtester_config is not found in config file")
    if cfg.get("trade_config") is None:
        raise KeyError("trade_config is not found in config file")
    return cfg  # type: ignore
