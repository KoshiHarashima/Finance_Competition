from datetime import datetime

import pytz  # type: ignore

jst = pytz.timezone("Asia/Tokyo")
utc = pytz.timezone("UTC")

exchange_cfg = {
    "bitflyer": {
        "FX_BTC_JPY": {
            "min_lot": 0.01,
            "max_lot": 100,
            "lot_size_currency": "BTC",
            "is_linear": True,
            "maker_fee": [{"start": None, "end": None, "value": 0}],
            "taker_fee": [{"start": None, "end": None, "value": 0}],
            "leverage_fee": [{"start": None, "end": None, "value": 0.04}],
            "tick_size": [{"start": None, "end": None, "value": 1}],
        },
    },
    "gmo": {
        "BTC_JPY": {
            "min_lot": 0.01,
            "max_lot": 5,
            "lot_size_currency": "BTC",
            "is_linear": True,
            "maker_fee": [
                {
                    "start": None,
                    "end": jst.localize(datetime(2020, 9, 9, 16, 0)),
                    "value": -0.035,
                },
                {
                    "start": jst.localize(datetime(2020, 9, 9, 16, 0)),
                    "end": jst.localize(datetime(2020, 11, 4, 16)),
                    "value": -0.025,
                },
                {
                    "start": jst.localize(datetime(2020, 11, 4, 16)),
                    "end": None,
                    "value": 0,
                },
            ],
            "taker_fee": [
                {
                    "start": None,
                    "end": jst.localize(datetime(2020, 9, 9, 16, 0)),
                    "value": 0.04,
                },
                {
                    "start": jst.localize(datetime(2020, 9, 9, 16, 0)),
                    "end": jst.localize(datetime(2020, 11, 4, 16)),
                    "value": 0.03,
                },
                {
                    "start": jst.localize(datetime(2020, 11, 4, 16)),
                    "end": None,
                    "value": 0,
                },
            ],
            "leverage_fee": [{"start": None, "end": None, "value": 0.04}],
            "tick_size": [{"start": None, "end": None, "value": 1}],
        },
        "ETH_JPY": {
            "min_lot": 0.1,
            "max_lot": 100,
            "lot_size_currency": "ETH",
            "is_linear": True,
            "maker_fee": [{"start": None, "end": None, "value": 0}],
            "taker_fee": [{"start": None, "end": None, "value": 0}],
            "leverage_fee": [{"start": None, "end": None, "value": 0.04}],
            "tick_size": [{"start": None, "end": None, "value": 1}],
        },
        "BCH_JPY": {
            "min_lot": 0.1,
            "max_lot": 100,
            "lot_size_currency": "BCH",
            "is_linear": True,
            "maker_fee": [{"start": None, "end": None, "value": 0}],
            "taker_fee": [{"start": None, "end": None, "value": 0}],
            "leverage_fee": [{"start": None, "end": None, "value": 0.04}],
            "tick_size": [{"start": None, "end": None, "value": 1}],
        },
        "LTC_JPY": {
            "min_lot": 1,
            "max_lot": 500,
            "lot_size_currency": "LTC",
            "is_linear": True,
            "maker_fee": [{"start": None, "end": None, "value": 0}],
            "taker_fee": [{"start": None, "end": None, "value": 0}],
            "leverage_fee": [{"start": None, "end": None, "value": 0.04}],
            "tick_size": [{"start": None, "end": None, "value": 1}],
        },
        "XRP_JPY": {
            "min_lot": 10,
            "max_lot": 100000,
            "lot_size_currency": "XRP",
            "is_linear": True,
            "maker_fee": [{"start": None, "end": None, "value": 0}],
            "taker_fee": [{"start": None, "end": None, "value": 0}],
            "leverage_fee": [{"start": None, "end": None, "value": 0.04}],
            "tick_size": [{"start": None, "end": None, "value": 0.001}],
        },
        "DOT_JPY": {
            "min_lot": 1,
            "max_lot": 5000,
            "lot_size_currency": "DOT",
            "is_linear": True,
            "maker_fee": [{"start": None, "end": None, "value": 0}],
            "taker_fee": [{"start": None, "end": None, "value": 0.03}],
            "leverage_fee": [{"start": None, "end": None, "value": 0.04}],
            "tick_size": [{"start": None, "end": None, "value": 1}],
        },
        "ATOM_JPY": {
            "min_lot": 1,
            "max_lot": 2000,
            "lot_size_currency": "ATOM",
            "is_linear": True,
            "maker_fee": [{"start": None, "end": None, "value": 0}],
            "taker_fee": [{"start": None, "end": None, "value": 0.03}],
            "leverage_fee": [{"start": None, "end": None, "value": 0.04}],
            "tick_size": [{"start": None, "end": None, "value": 1}],
        },
        "ADA_JPY": {
            "min_lot": 10,
            "max_lot": 50000,
            "lot_size_currency": "ADA",
            "is_linear": True,
            "maker_fee": [{"start": None, "end": None, "value": 0}],
            "taker_fee": [{"start": None, "end": None, "value": 0.03}],
            "leverage_fee": [{"start": None, "end": None, "value": 0.04}],
            "tick_size": [{"start": None, "end": None, "value": 0.001}],
        },
        "LINK_JPY": {
            "min_lot": 1,
            "max_lot": 2000,
            "lot_size_currency": "LINK",
            "is_linear": True,
            "maker_fee": [{"start": None, "end": None, "value": 0}],
            "taker_fee": [{"start": None, "end": None, "value": 0.03}],
            "leverage_fee": [{"start": None, "end": None, "value": 0.04}],
            "tick_size": [{"start": None, "end": None, "value": 1}],
        },
        "DOGE_JPY": {
            "min_lot": 100,
            "max_lot": 200000,
            "lot_size_currency": "DOGE",
            "is_linear": True,
            "maker_fee": [{"start": None, "end": None, "value": 0}],
            "taker_fee": [{"start": None, "end": None, "value": 0.03}],
            "leverage_fee": [{"start": None, "end": None, "value": 0.04}],
            "tick_size": [{"start": None, "end": None, "value": 0.001}],
        },
        "SOL_JPY": {
            "min_lot": 0.1,
            "max_lot": 500,
            "lot_size_currency": "SOL",
            "is_linear": True,
            "maker_fee": [{"start": None, "end": None, "value": 0}],
            "taker_fee": [{"start": None, "end": None, "value": 0.03}],
            "leverage_fee": [{"start": None, "end": None, "value": 0.04}],
            "tick_size": [{"start": None, "end": None, "value": 1}],
        },
    },
    "binance": {  # 2023/10 中盤 taker fee 変更 (公式アナウンスなく暫定値)
        "BTCUSDT": {
            "min_lot": 0.001,
            "market_max_lot": 120,
            "limit_max_lot": 1000,
            "lot_size_currency": "BTC",
            "is_linear": True,
            "maker_fee": [{"start": None, "end": None, "value": 0.02}],
            "taker_fee": [
                {
                    "start": None,
                    "end": utc.localize(datetime(2023, 10, 15, 3, 30)),
                    "value": 0.04,
                },
                {
                    "start": utc.localize(datetime(2023, 10, 15, 3, 30)),
                    "end": None,
                    "value": 0.05,
                },
            ],
            "leverage_fee": [{"start": None, "end": None, "value": 0}],
            "tick_size": [
                {
                    "start": None,
                    "end": utc.localize(datetime(2022, 2, 15, 3, 30)),
                    "value": 0.01,
                },
                {
                    "start": utc.localize(datetime(2022, 2, 15, 3, 30)),
                    "end": None,
                    "value": 0.1,
                },
            ],
        },
        "ETHUSDT": {
            "min_lot": 0.001,
            "market_max_lot": 2000,
            "limit_max_lot": 10000,
            "lot_size_currency": "ETH",
            "is_linear": True,
            "maker_fee": [{"start": None, "end": None, "value": 0.02}],
            "taker_fee": [
                {
                    "start": None,
                    "end": utc.localize(datetime(2023, 10, 15, 3, 30)),
                    "value": 0.04,
                },
                {
                    "start": utc.localize(datetime(2023, 10, 15, 3, 30)),
                    "end": None,
                    "value": 0.05,
                },
            ],
            "leverage_fee": [{"start": None, "end": None, "value": 0}],
            "tick_size": [{"start": None, "end": None, "value": 0.01}],
        },
        "BCHUSDT": {
            "min_lot": 0.001,
            "market_max_lot": 850,
            "limit_max_lot": 10000,
            "lot_size_currency": "BCH",
            "is_linear": True,
            "maker_fee": [{"start": None, "end": None, "value": 0.02}],
            "taker_fee": [
                {
                    "start": None,
                    "end": utc.localize(datetime(2023, 10, 15, 3, 30)),
                    "value": 0.04,
                },
                {
                    "start": utc.localize(datetime(2023, 10, 15, 3, 30)),
                    "end": None,
                    "value": 0.05,
                },
            ],
            "leverage_fee": [{"start": None, "end": None, "value": 0}],
            "tick_size": [{"start": None, "end": None, "value": 0.01}],
        },
        "LTCUSDT": {  # fee の変更履歴が未調査
            "min_lot": 0.001,
            "market_max_lot": 5000,
            "limit_max_lot": 10000,
            "lot_size_currency": "LTC",
            "is_linear": True,
            "maker_fee": [{"start": None, "end": None, "value": 0.02}],
            "taker_fee": [{"start": None, "end": None, "value": 0.05}],
            "leverage_fee": [{"start": None, "end": None, "value": 0}],
            "tick_size": [{"start": None, "end": None, "value": 0.01}],
        },
        "XRPUSDT": {
            "min_lot": 0.1,
            "market_max_lot": 2000000,
            "limit_max_lot": 10000000,
            "lot_size_currency": "XRP",
            "is_linear": True,
            "maker_fee": [{"start": None, "end": None, "value": 0.02}],
            "taker_fee": [
                {
                    "start": None,
                    "end": utc.localize(datetime(2023, 10, 15, 3, 30)),
                    "value": 0.04,
                },
                {
                    "start": utc.localize(datetime(2023, 10, 15, 3, 30)),
                    "end": None,
                    "value": 0.05,
                },
            ],
            "leverage_fee": [{"start": None, "end": None, "value": 0}],
            "tick_size": [{"start": None, "end": None, "value": 0.0001}],
        },
        # 以降Binanceの銘柄では fee の変更履歴が未調査
        "DOTUSDT": {
            "min_lot": 0.1,
            "market_max_lot": 50000,
            "limit_max_lot": 1000000,
            "lot_size_currency": "DOT",
            "is_linear": True,
            "maker_fee": [{"start": None, "end": None, "value": 0.02}],
            "taker_fee": [{"start": None, "end": None, "value": 0.05}],
            "leverage_fee": [{"start": None, "end": None, "value": 0}],
            "tick_size": [{"start": None, "end": None, "value": 0.001}],
        },
        "ATOMUSDT": {
            "min_lot": 0.01,
            "market_max_lot": 20000,
            "limit_max_lot": 100000,
            "lot_size_currency": "ATOM",
            "is_linear": True,
            "maker_fee": [{"start": None, "end": None, "value": 0.02}],
            "taker_fee": [{"start": None, "end": None, "value": 0.05}],
            "leverage_fee": [{"start": None, "end": None, "value": 0}],
            "tick_size": [{"start": None, "end": None, "value": 0.001}],
        },
        "ADAUSDT": {
            "min_lot": 1,
            "market_max_lot": 300000,
            "limit_max_lot": 20000000,
            "lot_size_currency": "ADA",
            "is_linear": True,
            "maker_fee": [{"start": None, "end": None, "value": 0.02}],
            "taker_fee": [{"start": None, "end": None, "value": 0.05}],
            "leverage_fee": [{"start": None, "end": None, "value": 0}],
            "tick_size": [
                {
                    "start": None,
                    "end": utc.localize(datetime(2021, 5, 11, 3, 30)),
                    "value": 0.00001,
                },
                {
                    "start": utc.localize(datetime(2021, 5, 11, 3, 30)),
                    "end": None,
                    "value": 0.0001,
                },
            ],
        },
        "LINKUSDT": {
            "min_lot": 0.01,
            "market_max_lot": 20000,
            "limit_max_lot": 200000,
            "lot_size_currency": "LINK",
            "is_linear": True,
            "maker_fee": [{"start": None, "end": None, "value": 0.02}],
            "taker_fee": [{"start": None, "end": None, "value": 0.05}],
            "leverage_fee": [{"start": None, "end": None, "value": 0}],
            "tick_size": [{"start": None, "end": None, "value": 0.001}],
        },
        "DOGEUSDT": {
            "min_lot": 1,
            "market_max_lot": 30000000,
            "limit_max_lot": 50000000,
            "lot_size_currency": "DOGE",
            "is_linear": True,
            "maker_fee": [{"start": None, "end": None, "value": 0.02}],
            "taker_fee": [{"start": None, "end": None, "value": 0.05}],
            "leverage_fee": [{"start": None, "end": None, "value": 0}],
            "tick_size": [
                {
                    "start": None,
                    "end": utc.localize(datetime(2021, 5, 11, 3, 30)),
                    "value": 0.000001,
                },
                {
                    "start": utc.localize(datetime(2021, 5, 11, 3, 30)),
                    "end": None,
                    "value": 0.00001,
                },
            ],
        },
        "SOLUSDT": {
            "min_lot": 1,
            "market_max_lot": 5000,
            "limit_max_lot": 1000000,
            "lot_size_currency": "SOL",
            "is_linear": True,
            "maker_fee": [{"start": None, "end": None, "value": 0.02}],
            "taker_fee": [{"start": None, "end": None, "value": 0.05}],
            "leverage_fee": [{"start": None, "end": None, "value": 0}],
            "tick_size": [
                {
                    "start": None,
                    "end": utc.localize(datetime(2021, 5, 11, 3, 30)),
                    "value": 0.0001,
                },
                {
                    "start": utc.localize(datetime(2021, 5, 11, 3, 30)),
                    "end": utc.localize(datetime(2021, 12, 13, 3, 30)),
                    "value": 0.001,
                },
                {
                    "start": utc.localize(datetime(2021, 12, 13, 3, 30)),
                    "end": utc.localize(datetime(2022, 11, 9, 12, 00)),
                    "value": 0.01,
                },
                {
                    "start": utc.localize(datetime(2022, 11, 9, 12, 00)),
                    "end": None,
                    "value": 0.001,
                },
            ],
        },
    },
    "bybit": {
        "BTCUSDT": {
            "min_lot": 0.001,
            "max_lot": 1190,
            "lot_size_currency": "BTC",
            "is_linear": True,  # TODO: インバース対応
            "maker_fee": [
                {
                    "start": None,
                    "end": utc.localize(datetime(2022, 3, 18, 7, 0)),
                    "value": -0.025,
                },
                {
                    "start": utc.localize(datetime(2022, 3, 18, 7, 0)),
                    "end": utc.localize(datetime(2023, 7, 20, 7, 0)),
                    "value": 0.01,
                },
                {
                    "start": jst.localize(datetime(2023, 7, 20, 7, 0)),
                    "end": None,
                    "value": 0.02,
                },
            ],
            "taker_fee": [
                {
                    "start": None,
                    "end": utc.localize(datetime(2022, 3, 18, 7, 0)),
                    "value": 0.075,
                },
                {
                    "start": utc.localize(datetime(2022, 3, 18, 7, 0)),
                    "end": utc.localize(datetime(2023, 7, 20, 7, 0)),
                    "value": 0.06,
                },
                {
                    "start": utc.localize(datetime(2023, 7, 20, 7, 0)),
                    "end": None,
                    "value": 0.055,
                },
            ],
            "leverage_fee": [{"start": None, "end": None, "value": 0}],
            "tick_size": [
                {
                    "start": None,
                    "end": utc.localize(datetime(2023, 2, 10, 7, 30)),
                    "value": 0.5,
                },
                {
                    "start": utc.localize(datetime(2023, 2, 10, 7, 30)),
                    "end": None,
                    "value": 0.1,
                },
            ],
        },
        "ETHUSDT": {
            "min_lot": 0.01,
            "max_lot": 7240,
            "lot_size_currency": "ETH",
            "is_linear": True,  # TODO: インバース対応
            "maker_fee": [
                {
                    "start": None,
                    "end": utc.localize(datetime(2022, 3, 18, 7, 0)),
                    "value": -0.025,
                },
                {
                    "start": utc.localize(datetime(2022, 3, 18, 7, 0)),
                    "end": utc.localize(datetime(2023, 7, 20, 7, 0)),
                    "value": 0.01,
                },
                {
                    "start": utc.localize(datetime(2023, 7, 20, 7, 0)),
                    "end": None,
                    "value": 0.02,
                },
            ],
            "taker_fee": [
                {
                    "start": None,
                    "end": utc.localize(datetime(2022, 3, 18, 7, 0)),
                    "value": 0.075,
                },
                {
                    "start": utc.localize(datetime(2022, 3, 18, 7, 0)),
                    "end": utc.localize(datetime(2023, 7, 20, 7, 0)),
                    "value": 0.06,
                },
                {
                    "start": utc.localize(datetime(2023, 7, 20, 7, 0)),
                    "end": None,
                    "value": 0.055,
                },
            ],
            "leverage_fee": [{"start": None, "end": None, "value": 0}],
            "tick_size": [
                {
                    "start": None,
                    "end": utc.localize(datetime(2023, 1, 17, 7, 0)),
                    "value": 0.05,
                },
                {
                    "start": utc.localize(datetime(2023, 1, 17, 7, 0)),
                    "end": None,
                    "value": 0.01,
                },
            ],
        },
        "BCHUSDT": {
            "min_lot": 0.01,
            "max_lot": 5300,
            "lot_size_currency": "BCH",
            "is_linear": True,  # TODO: インバース対応
            "maker_fee": [
                {
                    "start": None,
                    "end": utc.localize(datetime(2022, 3, 18, 7, 0)),
                    "value": -0.025,
                },
                {
                    "start": utc.localize(datetime(2022, 3, 18, 7, 0)),
                    "end": utc.localize(datetime(2023, 7, 20, 7, 0)),
                    "value": 0.01,
                },
                {
                    "start": utc.localize(datetime(2023, 7, 20, 7, 0)),
                    "end": None,
                    "value": 0.02,
                },
            ],
            "taker_fee": [
                {
                    "start": None,
                    "end": utc.localize(datetime(2022, 3, 18, 7, 0)),
                    "value": 0.075,
                },
                {
                    "start": utc.localize(datetime(2022, 3, 18, 7, 0)),
                    "end": utc.localize(datetime(2023, 7, 20, 7, 0)),
                    "value": 0.06,
                },
                {
                    "start": utc.localize(datetime(2023, 7, 20, 7, 0)),
                    "end": None,
                    "value": 0.055,
                },
            ],
            "leverage_fee": [{"start": None, "end": None, "value": 0}],
            "tick_size": [{"start": None, "end": None, "value": 0.05}],
        },
        "LTCUSDT": {  # fee の変更履歴が未調査
            "min_lot": 0.1,
            "max_lot": 28740,
            "lot_size_currency": "LTC",
            "is_linear": True,
            "maker_fee": [{"start": None, "end": None, "value": 0.02}],
            "taker_fee": [{"start": None, "end": None, "value": 0.055}],
            "leverage_fee": [{"start": None, "end": None, "value": 0}],
            "tick_size": [{"start": None, "end": None, "value": 0.01}],
        },
        "XRPUSDT": {
            "min_lot": 1,
            "max_lot": 10965300,
            "lot_size_currency": "XRP",
            "is_linear": True,  # TODO: インバース対応
            "maker_fee": [
                {
                    "start": None,
                    "end": utc.localize(datetime(2022, 3, 11, 7, 30)),
                    "value": -0.025,
                },
                {
                    "start": utc.localize(datetime(2022, 3, 11, 7, 30)),
                    "end": utc.localize(datetime(2023, 7, 20, 7, 0)),
                    "value": 0.01,
                },
                {
                    "start": utc.localize(datetime(2023, 7, 20, 7, 0)),
                    "end": None,
                    "value": 0.02,
                },
            ],
            "taker_fee": [
                {
                    "start": None,
                    "end": utc.localize(datetime(2022, 3, 11, 7, 30)),
                    "value": 0.075,
                },
                {
                    "start": utc.localize(datetime(2022, 3, 11, 7, 30)),
                    "end": utc.localize(datetime(2023, 7, 20, 7, 0)),
                    "value": 0.06,
                },
                {
                    "start": utc.localize(datetime(2023, 7, 20, 7, 0)),
                    "end": None,
                    "value": 0.055,
                },
            ],
            "leverage_fee": [{"start": None, "end": None, "value": 0}],
            "tick_size": [{"start": None, "end": None, "value": 0.0001}],
        },
        # 以降 Bybit の銘柄では fee の変更履歴が未調査
        "DOTUSDT": {
            "min_lot": 0.1,
            "max_lot": 198890,
            "lot_size_currency": "DOT",
            "is_linear": True,
            "maker_fee": [{"start": None, "end": None, "value": 0.02}],
            "taker_fee": [{"start": None, "end": None, "value": 0.055}],
            "leverage_fee": [{"start": None, "end": None, "value": 0}],
            "tick_size": [
                {
                    "start": None,
                    "end": utc.localize(datetime(2023, 2, 3, 8, 15)),
                    "value": 0.005,
                },
                {
                    "start": utc.localize(datetime(2023, 2, 3, 8, 15)),
                    "end": None,
                    "value": 0.001,
                },
            ],
        },
        "ATOMUSDT": {
            "min_lot": 0.1,
            "max_lot": 139180,
            "lot_size_currency": "ATOM",
            "is_linear": True,
            "maker_fee": [{"start": None, "end": None, "value": 0.02}],
            "taker_fee": [{"start": None, "end": None, "value": 0.055}],
            "leverage_fee": [{"start": None, "end": None, "value": 0}],
            "tick_size": [
                {
                    "start": None,
                    "end": utc.localize(datetime(2023, 2, 24, 7, 53)),
                    "value": 0.005,
                },
                {
                    "start": utc.localize(datetime(2023, 2, 24, 7, 53)),
                    "end": None,
                    "value": 0.001,
                },
            ],
        },
        "ADAUSDT": {
            "min_lot": 1,
            "max_lot": 6315500,
            "lot_size_currency": "ADA",
            "is_linear": True,
            "maker_fee": [{"start": None, "end": None, "value": 0.02}],
            "taker_fee": [{"start": None, "end": None, "value": 0.055}],
            "leverage_fee": [{"start": None, "end": None, "value": 0}],
            "tick_size": [{"start": None, "end": None, "value": 0.0001}],
        },
        "LINKUSDT": {
            "min_lot": 0.1,
            "max_lot": 196310,
            "lot_size_currency": "LINK",
            "is_linear": True,
            "maker_fee": [{"start": None, "end": None, "value": 0.02}],
            "taker_fee": [{"start": None, "end": None, "value": 0.055}],
            "leverage_fee": [{"start": None, "end": None, "value": 0}],
            "tick_size": [{"start": None, "end": None, "value": 0.001}],
        },
        "DOGEUSDT": {
            "min_lot": 1,
            "max_lot": 43678900,
            "lot_size_currency": "DOGE",
            "is_linear": True,
            "maker_fee": [{"start": None, "end": None, "value": 0.02}],
            "taker_fee": [{"start": None, "end": None, "value": 0.055}],
            "leverage_fee": [{"start": None, "end": None, "value": 0}],
            "tick_size": [
                {
                    "start": None,
                    "end": utc.localize(datetime(2022, 11, 29, 9, 45)),
                    "value": 0.0001,
                },
                {
                    "start": utc.localize(datetime(2022, 11, 29, 9, 45)),
                    "end": None,
                    "value": 0.00001,
                },
            ],
        },
        "SOLUSDT": {
            "min_lot": 0.1,
            "max_lot": 79770,
            "lot_size_currency": "SOL",
            "is_linear": True,
            "maker_fee": [{"start": None, "end": None, "value": 0.02}],
            "taker_fee": [{"start": None, "end": None, "value": 0.055}],
            "leverage_fee": [{"start": None, "end": None, "value": 0}],
            "tick_size": [
                {
                    "start": None,
                    "end": utc.localize(datetime(2023, 2, 24, 7, 50)),
                    "value": 0.005,
                },
                {
                    "start": utc.localize(datetime(2023, 2, 24, 7, 50)),
                    "end": utc.localize(datetime(2024, 4, 3, 10, 27)),
                    "value": 0.001,
                },
                {
                    "start": utc.localize(datetime(2024, 4, 3, 10, 27)),
                    "end": None,
                    "value": 0.01,
                },
            ],
        },
    },
    "deribit": {
        "BTC-PERPETUAL": {
            "min_lot": 10,
            "max_lot": 1000000,
            "lot_size_currency": "USDT",
            "is_linear": False,
            "maker_fee": [
                {
                    "start": None,
                    "end": jst.localize(datetime(2020, 8, 24, 9, 0)),
                    "value": -0.025,
                },
                {
                    "start": jst.localize(datetime(2020, 8, 24, 9, 0)),
                    "end": None,
                    "value": 0,
                },
            ],
            "taker_fee": [
                {
                    "start": None,
                    "end": jst.localize(datetime(2020, 8, 24, 9, 0)),
                    "value": 0.075,
                },
                {
                    "start": jst.localize(datetime(2020, 8, 24, 9, 0)),
                    "end": None,
                    "value": 0.05,
                },
            ],
            "leverage_fee": [{"start": None, "end": None, "value": 0}],
            "tick_size": [
                {
                    "start": None,
                    "end": jst.localize(datetime(2019, 1, 30, 8, 0)),
                    "value": 0.5,
                },
                {
                    "start": jst.localize(datetime(2019, 1, 30, 8, 0)),
                    "end": jst.localize(datetime(2019, 6, 7, 21, 0)),
                    "value": 0.25,
                },
                {
                    "start": jst.localize(datetime(2019, 6, 7, 21, 0)),
                    "end": None,
                    "value": 0.5,
                },
            ],
        },
    },
}


def load_exchange_cfg(exchange: str, symbol: str) -> dict:
    if exchange not in exchange_cfg:
        raise ValueError(f"exchange {exchange} is not supported")
    if symbol not in exchange_cfg[exchange]:
        raise ValueError(f"symbol {symbol} is not supported")
    return exchange_cfg[exchange][symbol]
