# Standard Library
from dataclasses import dataclass, field
from typing import Optional

# Third Party Library
import pandas as pd


@dataclass
class Order:
    type: str
    side: str
    size: float
    price: Optional[float]
    symbol: Optional[str] = None
    minutes_to_expire: Optional[int] = None
    exit: bool = False
    exit_id: Optional[str] = None
    params: Optional[dict] = None
    message: Optional[str] = None


@dataclass
class MessageOnlyOrder(Order):
    def __init__(self, message: str):
        super().__init__(
            type="",
            side="",
            size=0,
            price=None,
            symbol=None,
            minutes_to_expire=None,
            exit=False,
            exit_id=None,
            params=None,
            message=message,
        )


@dataclass
class OrderEvent:
    type: str
    side: str
    size: float
    price: Optional[float]
    timestamp: pd.Timestamp
    minutes_to_expire: int = 60
    exit: bool = False
    exit_id: Optional[str] = None
    params: Optional[dict] = None
    triggered_timestamp: Optional[pd.Timestamp] = None


@dataclass
class OpenPosition:
    id: str
    side: str
    size: float
    price: float
    order_type: str
    timestamp: pd.Timestamp
    params: Optional[dict] = None


@dataclass
class Fill:
    id: str
    type: str
    side: str
    size: float
    price: float
    timestamp: pd.Timestamp
    triggered_timestamp: Optional[pd.Timestamp]
    exit: bool = False
    entry_position_id: str = ""
    exit_position_ids: list[str] = field(default_factory=list)


@dataclass
class CloseEvent:
    id: str
    rpnl: float
    commission: float
    slippage: float
    timestamp: pd.Timestamp
    duration: pd.Timedelta


@dataclass
class AssetInfo:
    effective_margin: float
    margin_balance: float
    rpnls: dict
    upnls: dict
    signed_pos_sizes: dict
    open_positions: dict[str, list[OpenPosition]]
    commissions: dict
    slippages: dict
    realized_funding_fees: dict
    avg_prices: dict
    pos_sizes_in_quote: dict
    tick_sizes: dict


@dataclass
class PositionSnapShot:
    timestamp: pd.Timestamp
    symbol: str
    effective_margin: float
    margin_balance: float
    rpnl: float
    upnl: float
    signed_pos_size: float
    commission: float
    slippage: float
    realized_funding_fee: float
    avg_price: float
    effective_leverage: float
