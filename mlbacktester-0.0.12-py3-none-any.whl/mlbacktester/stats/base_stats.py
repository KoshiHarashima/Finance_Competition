# Third Party Library
from typing import Any, Optional, cast

import japanize_matplotlib  # noqa

# Third Party Library
import matplotlib
import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import matplotlib.style as mplstyle
import numpy as np
import pandas as pd
import seaborn as sns

# First Party Library
import wandb

from ..data_handler.base_data_handler import BaseDataHandler
from ..event_handler.base_event_handler import BaseEventHandler
from ..pos_manager.base_pos_manager import BasePosManager


class BaseStats:
    def __init__(
        self,
        data_handler: BaseDataHandler,
        pos_manager: BasePosManager,
        event_handler: BaseEventHandler,
        cfg: dict,
    ) -> None:
        self.data_handler = data_handler
        self.pos_manager = pos_manager
        self.event_handler = event_handler
        self.cfg = cfg
        self.stats = {}  # type: ignore

        # Seaborn Setting
        sns.set()
        mplstyle.use("fast")
        plt.rcParams["font.family"] = "IPAexGothic"

    def make_stats(self) -> None:
        freq = "24h"  # リターンのサンプリング周期
        f = pd.Timedelta(freq)

        # 最初にsnapshotをpd.DataFrameに変換する
        self.pos_manager.set_snapshot_df()
        effective_margin = (
            self.pos_manager.snapshots.loc[
                (slice(None), self.cfg["backtester_config"]["symbol"][0]), :
            ]
            .reset_index("symbol", drop=True)
            .effective_margin.resample(freq)
            .last()
        )
        rpnl = {
            symbol: self.pos_manager.snapshots.loc[
                (slice(None), symbol), :
            ].rpnl.values[-1]
            for symbol in self.cfg["backtester_config"]["symbol"]
        }
        upnl = {
            symbol: self.pos_manager.snapshots.loc[
                (slice(None), symbol), :
            ].upnl.values[-1]
            for symbol in self.cfg["backtester_config"]["symbol"]
        }
        commission = {
            symbol: self.pos_manager.snapshots.loc[
                (slice(None), symbol), :
            ].commission.values[-1]
            for symbol in self.cfg["backtester_config"]["symbol"]
        }
        slippage = {
            symbol: self.pos_manager.snapshots.loc[
                (slice(None), symbol), :
            ].slippage.values[-1]
            for symbol in self.cfg["backtester_config"]["symbol"]
        }
        realized_funding_fee = {
            symbol: self.pos_manager.snapshots.loc[
                (slice(None), symbol), :
            ].realized_funding_fee.values[-1]
            for symbol in self.cfg["backtester_config"]["symbol"]
        }
        self.stats["average_annual_return"] = self.average_annual_return(
            effective_margin,
            f,
            self.cfg["backtester_config"]["compounding_strategy"],
            self.cfg["trade_config"]["initial_margin_balance"],
        )
        self.stats["average_annual_risk"] = self.average_annual_risk(
            effective_margin,
            f,
            self.cfg["backtester_config"]["compounding_strategy"],
            self.cfg["trade_config"]["initial_margin_balance"],
        )
        if self.stats["average_annual_risk"]:
            self.stats["annual_sharpe_ratio"] = (
                self.stats["average_annual_return"] / self.stats["average_annual_risk"]
            )
        else:
            self.stats["annual_sharpe_ratio"] = 0
        (
            self.stats["max_dd"],
            self.stats["max_dd_stime"],
            self.stats["max_dd_etime"],
            self.stats["underwater_etime"],
        ) = self.max_drawdown(
            self.pos_manager.snapshots.loc[
                (slice(None), self.cfg["backtester_config"]["symbol"][0]), :
            ]
            .reset_index("symbol", drop=True)
            .effective_margin,
            self.cfg["backtester_config"]["compounding_strategy"],
            self.cfg["trade_config"]["initial_margin_balance"],
        )
        # バックテスト終了時点の価格をもとにポジションサイズを計算
        self.stats["pnl/initial_balance"] = sum(
            [
                (
                    rpnl[symbol]
                    + upnl[symbol]
                    - commission[symbol]
                    - slippage[symbol]
                    + realized_funding_fee[symbol]
                )
                / self.cfg["trade_config"]["initial_margin_balance"]
                for symbol in self.cfg["backtester_config"]["symbol"]
            ]
        )

    def summary(self) -> tuple[list, list]:
        # logで出力するsummaryのリストを出力
        summary_info: list = []
        forced_liquidation_summary_info: list = []

        close_event_list = []
        for symbol in self.cfg["backtester_config"]["symbol"]:
            if len(self.event_handler.close_events[symbol]) == 0:
                close_event_df = pd.DataFrame(self.event_handler.close_events[symbol])
            else:
                close_event_df = pd.DataFrame(
                    self.event_handler.close_events[symbol]
                ).set_index("timestamp")
                close_event_df.index = np.array(
                    [pd.Timestamp(t_str) for t_str in close_event_df.index]
                )
                close_event_df["symbol"] = symbol
                close_event_list.append(close_event_df)
        close_events = (
            pd.DataFrame()
            if len(close_event_list) == 0
            else pd.concat(close_event_list)
            .sort_index()
            .set_index("symbol", append=True)
        )

        if (
            sum(
                [
                    len(self.event_handler.fill_events[symbol])
                    for symbol in self.cfg["backtester_config"]["symbol"]
                ]
            )
            == 0
        ):
            summary_info.append("    No Fills Occurred")
            return summary_info, forced_liquidation_summary_info
        else:
            fill_list = []
            order_list = []
            for symbol in self.event_handler.fill_events.keys():
                fill_df = pd.DataFrame(self.event_handler.fill_events[symbol])
                fill_df["symbol"] = symbol
                fill_list.append(fill_df)
            fill_list = [fill for fill in fill_list if len(fill) != 0]
            fills = (
                pd.DataFrame()
                if len(fill_list) == 0
                else pd.concat(fill_list).set_index("timestamp")
            )
            fills.index = np.array([pd.Timestamp(t_str) for t_str in fills.index])
            fills = (
                fills
                if len(fill_list) == 0
                else fills.sort_index().set_index("symbol", append=True)
            )
            for symbol in self.event_handler.order_history.keys():
                order_df = pd.DataFrame(self.event_handler.order_history[symbol])
                order_df["symbol"] = symbol
                order_list.append(order_df)
            order_list = [order for order in order_list if len(order) != 0]
            orders = (
                pd.DataFrame()
                if len(order_list) == 0
                else pd.concat(order_list).set_index("timestamp")
            )
            orders.index = np.array([pd.Timestamp(t_str) for t_str in orders.index])
            orders = (
                orders
                if len(order_list) == 0
                else orders.sort_index().set_index("symbol", append=True)
            )

            order_interval_mean, fill_interval_mean = self.get_mean_intervals(
                orders, fills
            )

        summary_info.append("Performance Metrics")
        summary_info.append(
            f"\tAnnual Sharpe Ratio: {self.stats['annual_sharpe_ratio']:.2f}"
        )
        summary_info.append(
            f"\t\tAverage Annual Return: {self.stats['average_annual_return']:.1%}"
        )
        summary_info.append(
            f"\t\tAverage Annual Risk: {self.stats['average_annual_risk']:.1%}"
        )
        if close_events.empty:
            summary_info.append("\tWin Rate: 0")
        else:
            win_rate_str = ", ".join(
                [
                    f"{symbol} -> {(close_events.loc[(slice(None), symbol), :].rpnl - close_events.loc[(slice(None), symbol), :].commission - close_events.loc[(slice(None), symbol), :].slippage).apply(lambda x: 1 if x > 0 else 0).mean():.1%}"
                    for symbol in close_events.index.get_level_values(1).unique()
                ]
            )
            summary_info.append(f"\tWin Rate: {win_rate_str}")

        summary_info.append(
            f"PnL Profile (Final Effective Margin {self.pos_manager.effective_margin:.0f})"
        )
        summary_info.append(
            f"\tInitial Margin Balance: {self.cfg['trade_config']['initial_margin_balance']}"
        )
        rpnl_str = ", ".join(
            [
                f"{symbol} -> {self.pos_manager.rpnls[symbol]:+.0f}"
                for symbol in self.cfg["backtester_config"]["symbol"]
            ]
        )
        upnl_str = ", ".join(
            [
                f"{symbol} -> {self.pos_manager.upnls[symbol]:+.0f}"
                for symbol in self.cfg["backtester_config"]["symbol"]
            ]
        )
        fee_str = ", ".join(
            [
                f"{symbol} -> {-self.pos_manager.snapshots.loc[(slice(None), symbol), :].commission.values[-1]:+.0f}"
                for symbol in self.cfg["backtester_config"]["symbol"]
            ]
        )
        slippage_str = ", ".join(
            [
                f"{symbol} -> {-self.pos_manager.snapshots.loc[(slice(None), symbol), :].slippage.values[-1]:+.0f}"
                for symbol in self.cfg["backtester_config"]["symbol"]
            ]
        )
        realized_funding_fee_str = ", ".join(
            [
                f"{symbol} -> {self.pos_manager.realized_funding_fees[symbol]:+.0f}"
                for symbol in self.cfg["backtester_config"]["symbol"]
            ]
        )
        summary_info.append(f"\tTotal RPnL: {rpnl_str}")
        summary_info.append(f"\tFinal UPnL: {upnl_str}")
        summary_info.append(f"\tTotal Fee:  {fee_str}")
        summary_info.append(f"\tTotal Slippage Cost: {slippage_str}")
        summary_info.append(f"\tTotal Funding Fee: {realized_funding_fee_str}")

        summary_info.append("Drawdown Profile")
        summary_info.append(f"\tMax Drawdown: {self.stats['max_dd']:.1%}")
        summary_info.append(f"\tMax DD Start: {self.stats['max_dd_stime']}")
        summary_info.append(f"\tMax DD End: {self.stats['max_dd_etime']}")

        summary_info.append("Order/Fill Profile")
        types = types = ["MARKET", "LIMIT", "STOP", "STOP_LIMIT", "TAKE_LIMIT"]
        exec_ratio_str = ", ".join(
            [
                f"{symbol} -> {len(fills.loc[(slice(None), symbol), :])}/{len(orders.loc[(slice(None), symbol), :])}"
                for symbol in fills.index.get_level_values(1).unique()
            ]
        )
        type_str_dict = {
            type_: ", ".join(
                [
                    f"{symbol} -> {len(fills[fills['type'] == type_])}/{len(orders[orders['type'] == type_])}"
                    for symbol in fills.index.get_level_values(1).unique()
                ]
            )
            for type_ in types
        }
        info_messages = [
            f"\tNumber of Fills/Orders:  {exec_ratio_str}",
            *[f"\t\t{type_.ljust(10)} : {type_str_dict[type_]}" for type_ in types],
        ]
        for message in info_messages:
            summary_info.append(message)

        order_interval_mean_str = ", ".join(
            [
                f"{symbol} -> {order_interval_mean[symbol]:.0f} minutes"
                for symbol in order_interval_mean.keys()
            ]
        )
        fill_interval_mean_str = ", ".join(
            [
                f"{symbol} -> {fill_interval_mean[symbol]:.0f} minutes"
                for symbol in fill_interval_mean.keys()
            ]
        )
        summary_info.append("\tAverage Interval:")
        summary_info.append(f"\t\tOrders: {order_interval_mean_str}")
        summary_info.append(f"\t\tFills:  {fill_interval_mean_str}")

        max_pos_str = ", ".join(
            [
                f"{symbol} -> {self.pos_manager.snapshots.loc[(slice(None), symbol), :].signed_pos_size.abs().max()}"
                for symbol in self.cfg["backtester_config"]["symbol"]
            ]
        )
        summary_info.append("Position Profile")
        summary_info.append(f"\tMax Position Size: {max_pos_str}")
        if close_events.empty:
            summary_info.append("\tAverage Duration: 0")
        else:
            average_duration_str = ", ".join(
                [
                    f"{symbol} -> {(close_events.loc[(slice(None), symbol), :].duration.mean().round('s'))}"
                    for symbol in close_events.index.get_level_values(1).unique()
                ]
            )
            summary_info.append(f"\tAverage Duration: {average_duration_str}")

        if self.pos_manager.forced_liquidation:
            forced_liquidation_summary_info.append(
                "\033[91m" + "Forced liquidation has occurred." + "\033[0m"
            )
            for (
                forced_liquidation_info_message
            ) in self.pos_manager.forced_liquidation_info:
                forced_liquidation_summary_info.append(
                    "\033[91m" + str(forced_liquidation_info_message) + "\033[0m"
                )

        return summary_info, forced_liquidation_summary_info

    def save_results(self, log_path: str, fills_path: str) -> None:
        if (
            sum(
                [
                    len(self.event_handler.fill_events[symbol])
                    for symbol in self.event_handler.fill_events.keys()
                ]
            )
            > 0
        ):
            self.output_fills(fills_path)
            self.output_log(log_path)

    def plot_graph(
        self,
        df: pd.DataFrame,
        snapshots: pd.DataFrame,
        stats: dict,
        filename: dict,
    ) -> None:
        snapshots_ = snapshots.copy(deep=True)

        # 複数シンボルによるバックテストの場合はポートフォリオ全体の結果をプロット
        if filename.get("portfolio", False):
            self._plot_portfolio(df, snapshots_, stats, filename["portfolio"])

        # 各シンボルのバックテスト結果をプロット
        for symbol in self.cfg["backtester_config"]["symbol"]:
            df_ = df.loc[
                pd.IndexSlice[snapshots_.index[0][0] :, symbol], :
            ].reset_index("symbol", drop=True)
            single_snapshots_ = snapshots_.loc[(slice(None), symbol), :].reset_index(
                "symbol", drop=True
            )
            if self.cfg["backtester_config"]["compounding_strategy"]:
                pnl_without_cost = (
                    self.cfg["trade_config"]["initial_margin_balance"]
                    + single_snapshots_["rpnl"]
                    + single_snapshots_["upnl"]
                )
                unrealized_return = (
                    single_snapshots_["upnl"] / single_snapshots_["effective_margin"]
                )
            else:
                pnl_without_cost = single_snapshots_["rpnl"] + single_snapshots_["upnl"]
                unrealized_return = (
                    single_snapshots_["upnl"]
                    / self.cfg["trade_config"]["initial_margin_balance"]
                )
            pnl_with_cost = (
                pnl_without_cost
                + single_snapshots_["realized_funding_fee"]
                - single_snapshots_["commission"]
                - single_snapshots_["slippage"]
            )

            fig, axes = plt.subplots(nrows=6, ncols=1, figsize=(15, 16))
            fig.suptitle(f"Backtest Result ({symbol})")

            # Plot symbol close price
            axes[0].plot(
                df_.index, df_["close"], alpha=0.7, label="Close Price", c="tab:blue"
            )
            axes[0].set_title(f"Underlying Asset Price ({symbol})")
            axes[0].ticklabel_format(style="plain", axis="y")
            axes[0].legend(loc="upper left", bbox_to_anchor=(1, 1))

            # Plot symbol cumulative profit and loss
            max_dd, max_dd_stime, max_dd_etime, underwater_etime = self.max_drawdown(
                pnl_with_cost,
                self.cfg["backtester_config"]["compounding_strategy"],
                self.cfg["trade_config"]["initial_margin_balance"],
            )
            axes[1].plot(
                pnl_with_cost.index,
                pnl_with_cost,
                label="PnL w/ cost",
                alpha=0.7,
                color="tab:blue",
            )
            axes[1].plot(
                pnl_without_cost.index,
                pnl_without_cost,
                label="PnL w/o cost",
                alpha=0.7,
                color="tab:blue",
                linestyle="dotted",
            )
            if max_dd != 0.0 and underwater_etime is not None:
                axes[1].scatter(
                    [max_dd_etime],
                    [pnl_with_cost.loc[max_dd_etime]],
                    color="red",
                    label=f"Max Drawdown : {max_dd:.1%}",
                    s=10,
                )
                axes[1].plot(
                    pnl_with_cost.loc[max_dd_stime:underwater_etime].index,
                    pnl_with_cost[max_dd_stime:underwater_etime],
                    color="orange",
                    alpha=0.7,
                    label=f"MDD Underwater ({(underwater_etime - max_dd_stime).days} days)",
                )
            axes[1].set_title(f"Cumulative Profit and Loss ({symbol})")
            if self.cfg["backtester_config"]["compounding_strategy"]:
                axes[1].set_yscale("log")
            else:
                axes[1].ticklabel_format(style="plain", axis="y")
            axes[1].legend(loc="upper left", bbox_to_anchor=(1, 1))

            # Plot symbol cost
            axes[2].plot(
                single_snapshots_.index,
                -single_snapshots_["realized_funding_fee"],
                label="Funding Fee",
                alpha=0.7,
                color="tab:gray",
            )
            axes[2].plot(
                single_snapshots_.index,
                single_snapshots_["commission"],
                label="Execution Fee",
                alpha=0.7,
                color="tab:brown",
            )
            axes[2].plot(
                single_snapshots_.index,
                single_snapshots_["slippage"],
                label="Slippage Cost",
                alpha=0.7,
                color="tab:olive",
            )
            axes[2].plot(
                single_snapshots_.index,
                -single_snapshots_["realized_funding_fee"]
                + single_snapshots_["commission"]
                + single_snapshots_["slippage"],
                label="Total Cost",
                alpha=0.7,
                color="black",
            )
            axes[2].set_title(f"Cumulative Cost ({symbol})")
            axes[2].ticklabel_format(style="plain", axis="y")
            axes[2].legend(loc="upper left", bbox_to_anchor=(1, 1))

            # Plot symbol upnl
            axes[3].plot(
                unrealized_return.index,
                unrealized_return,
                label="Unrealized PnL",
                alpha=0.7,
                c="tab:blue",
            )
            axes[3].scatter(
                [single_snapshots_.index[unrealized_return.argmin()]],
                [unrealized_return.min()],
                color="red",
                label=f"Worst UPnL: {unrealized_return.min():.1%}",
                s=10,
            )
            axes[3].axhline(
                0, color="black", linestyle="--", linewidth=0.5, alpha=0.7
            )  # Change horizontal line color to black
            axes[3].set_title(f"Unrealized Profit and Loss ({symbol})")
            axes[3].yaxis.set_major_formatter(matplotlib.ticker.PercentFormatter(1.0))
            axes[3].legend(loc="upper left", bbox_to_anchor=(1, 1))

            if self.cfg["backtester_config"]["position_in_fiat"]:
                single_snapshots_ = pd.merge(
                    single_snapshots_,
                    df_[["close"]],
                    left_index=True,
                    right_index=True,
                    how="inner",
                )
                single_snapshots_["fiat_pos_size"] = (
                    single_snapshots_["signed_pos_size"] * single_snapshots_["close"]
                )
                posplot_column = "fiat_pos_size"
            else:
                posplot_column = "signed_pos_size"

            # Plot symbol position
            tmp_snapshots = (
                single_snapshots_.resample("D").last().dropna()
                if self.cfg["backtester_config"]["daily_position"]
                else single_snapshots_
            )
            axes[4].plot(
                tmp_snapshots.index,
                tmp_snapshots[posplot_column],
                alpha=0.7,
                label="Position",
                c="tab:blue",
            )
            axes[4].scatter(
                tmp_snapshots.index[tmp_snapshots[posplot_column].argmax()],
                tmp_snapshots[posplot_column].max(),
                color="green",
                label=f"Largest Long: {tmp_snapshots[posplot_column].max():.0f}",
                s=10,
            )
            axes[4].scatter(
                tmp_snapshots.index[tmp_snapshots[posplot_column].argmin()],
                tmp_snapshots[posplot_column].min(),
                color="red",
                label=f"Largest Short: {abs(tmp_snapshots[posplot_column].min()):.0f}",
                s=10,
            )

            position_title = (
                f"{symbol} Position (Base Currency)"
                if self.cfg["backtester_config"]["position_in_fiat"]
                else f"{symbol} Position (Quote Currency)"
            )
            axes[4].ticklabel_format(style="plain", axis="y")
            axes[4].set_title(position_title)
            axes[4].legend(loc="upper left", bbox_to_anchor=(1, 1))

            # Plot symbol margin rate
            if self.cfg["backtester_config"]["compounding_strategy"]:
                effective_leverage = (
                    abs(
                        single_snapshots_["signed_pos_size"]
                        * single_snapshots_["avg_price"]
                    )
                    / single_snapshots_["effective_margin"]
                )
            else:
                effective_leverage = (
                    abs(
                        single_snapshots_["signed_pos_size"]
                        * single_snapshots_["avg_price"]
                    )
                    / self.cfg["trade_config"]["initial_margin_balance"]
                )
            axes[5].plot(
                effective_leverage.index,
                effective_leverage,
                alpha=0.7,
                label="Effective Leverage",
                c="tab:blue",
            )
            axes[5].axhline(
                self.cfg["trade_config"]["max_leverage"],
                color="red",
                linestyle="--",
                linewidth=0.5,
                alpha=0.7,
                label=f"Max Leverage: {self.cfg['trade_config']['max_leverage']:.0f}",
            )

            if effective_leverage.max() > self.cfg["trade_config"]["max_leverage"]:
                forced_liquidation_level = (
                    self.cfg["trade_config"]["max_leverage"]
                    / self.cfg["trade_config"]["min_margin_rate"]
                )
                axes[5].axhline(
                    forced_liquidation_level,
                    color="red",
                    linestyle="-",
                    linewidth=0.5,
                    alpha=0.7,
                    label=f"Forced Liquidation Level: {forced_liquidation_level:.0f}",
                )

            axes[5].scatter(
                [effective_leverage.index[effective_leverage.argmax()]],
                [effective_leverage.max()],
                color="red",
                label=f"Realized Peak: {effective_leverage.max():.1f}",
                s=10,
            )

            axes[5].set_title(f"Effective Leverage ({symbol})")
            axes[5].ticklabel_format(style="plain", axis="y")
            axes[5].legend(loc="upper left", bbox_to_anchor=(1, 1))

            for ax in axes:
                ax.grid(True, which="both", linestyle="--", linewidth=0.5)
                ax.xaxis.set_major_locator(mdates.AutoDateLocator())
                ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y-%m-%d"))
                # type: ignore
                ax.set_xlim(pd.to_datetime([df_.index[0], df_.index[-1]]))

            # Adjust spacing between subplots
            fig.tight_layout(rect=(0, 0, 1, 0.99))

            # Save the figure
            fig.savefig(filename[symbol])
            plt.close()

            if self.cfg["backtester_config"]["use_wandb"]:
                wandb.log({"backtest graph": wandb.Image(fig)})

    def _plot_portfolio(
        self, raw_df: pd.DataFrame, snapshots: pd.DataFrame, stats: dict, filename: str
    ) -> None:
        """複数シンボルでのバックテストにおいてポートフォリオ全体の結果をプロット

        Args:
            raw_df (pd.DataFrame): strategy_timeframeのローソク足
            snapshots (pd.DataFrame): バックテストのログ
            stats (dict): ドローダウン等の統計値
            filename (str): 保存パス
        """
        max_dd = stats["max_dd"]
        max_dd_stime = stats["max_dd_stime"]
        max_dd_etime = stats["max_dd_etime"]
        underwater_etime = stats["underwater_etime"]

        fig, axes = plt.subplots(nrows=6, ncols=1, figsize=(15, 16))
        fig.suptitle("Backtest Result (Aggregate)")

        total_execution_fee = (
            snapshots.reset_index()[["commission", "timestamp"]]
            .groupby("timestamp")
            .sum()["commission"]
        )
        total_slippage_cost = (
            snapshots.reset_index()[["slippage", "timestamp"]]
            .groupby("timestamp")
            .sum()["slippage"]
        )
        total_funding_fee = (
            snapshots.reset_index()[["realized_funding_fee", "timestamp"]]
            .groupby("timestamp")
            .sum()["realized_funding_fee"]
        )

        # Plot portfolio cumulative profit and loss
        effective_margin = (
            snapshots.loc[(slice(None), self.cfg["backtester_config"]["symbol"][0]), :]
            .reset_index("symbol", drop=True)
            .effective_margin
        )
        if self.cfg["backtester_config"]["compounding_strategy"]:
            pnl_with_cost = effective_margin
        else:
            pnl_with_cost = (
                effective_margin - self.cfg["trade_config"]["initial_margin_balance"]
            )
        pnl_without_cost = (
            pnl_with_cost
            + total_execution_fee
            + total_slippage_cost
            - total_funding_fee
        )

        axes[0].plot(
            pnl_with_cost.index,
            pnl_with_cost,
            label="PnL w/ cost",
            alpha=0.7,
            color="tab:blue",
        )
        axes[0].plot(
            pnl_without_cost.index,
            pnl_without_cost,
            label="PnL w/o cost",
            alpha=0.7,
            color="tab:blue",
            linestyle="dotted",
        )
        if max_dd != 0.0 and underwater_etime is not None:
            axes[0].scatter(
                [max_dd_etime],
                [pnl_with_cost.loc[max_dd_etime]],
                color="red",
                label=f"Max Drawdown : {max_dd:.1%}",
                s=10,
            )
            axes[0].plot(
                pnl_with_cost.loc[max_dd_stime:underwater_etime].index,
                pnl_with_cost[max_dd_stime:underwater_etime],
                color="orange",
                alpha=0.7,
                label=f"MDD Underwater ({(underwater_etime - max_dd_stime).days} days)",
            )

        axes[0].set_title("Cumulative Profit and Loss (Aggregate)")
        if self.cfg["backtester_config"]["compounding_strategy"]:
            axes[0].set_yscale("log")
        else:
            axes[0].ticklabel_format(style="plain", axis="y")
        axes[0].legend(loc="upper left", bbox_to_anchor=(1, 1))

        # Plot portfolio cumulative cost
        axes[1].plot(
            total_funding_fee.index,
            -total_funding_fee,
            label="Funding Fee",
            alpha=0.7,
            color="tab:gray",
        )
        axes[1].plot(
            total_execution_fee.index,
            total_execution_fee,
            label="Execution Fee",
            alpha=0.7,
            color="tab:brown",
        )
        axes[1].plot(
            total_slippage_cost.index,
            total_slippage_cost,
            label="Slippage Cost",
            alpha=0.7,
            color="tab:olive",
        )
        axes[1].plot(
            total_funding_fee.index,
            -total_funding_fee + total_execution_fee + total_slippage_cost,
            label="Total Cost",
            alpha=0.7,
            color="black",
        )
        axes[1].set_title("Cumulative Cost (Aggregate)")
        axes[1].ticklabel_format(style="plain", axis="y")
        axes[1].legend(loc="upper left", bbox_to_anchor=(1, 1))

        # Plot portfolio unrealized profit and loss
        unrealized_return = (
            snapshots.reset_index()[["upnl", "timestamp"]]
            .groupby("timestamp")
            .sum()["upnl"]
        )
        if self.cfg["backtester_config"]["compounding_strategy"]:
            unrealized_return = unrealized_return / effective_margin
        else:
            unrealized_return = (
                unrealized_return / self.cfg["trade_config"]["initial_margin_balance"]
            )

        axes[2].plot(
            unrealized_return.index,
            unrealized_return,
            label="Unrealized PnL",
            alpha=0.7,
            c="tab:blue",
        )
        axes[2].scatter(
            [unrealized_return.index[unrealized_return.argmin()]],
            [unrealized_return.min()],
            color="red",
            label=f"Worst UPnL: {unrealized_return.min():.1%}",
            s=10,
        )
        axes[2].axhline(
            0, color="black", linestyle="--", linewidth=0.5, alpha=0.7
        )  # Change horizontal line color to black
        axes[2].set_title("Unrealized Profit and Loss (Aggregate)")
        axes[2].yaxis.set_major_formatter(matplotlib.ticker.PercentFormatter(1.0))
        axes[2].legend(loc="upper left", bbox_to_anchor=(1, 1))

        # Plot total position
        position = pd.merge(
            snapshots,
            raw_df[["close"]],
            left_index=True,
            right_index=True,
            how="inner",
        )
        position["pos_fiat"] = position["signed_pos_size"] * position["close"]
        gross_position = (
            position.abs()
            .reset_index()[["timestamp", "pos_fiat"]]
            .groupby("timestamp")
            .sum()["pos_fiat"]
        )
        net_position = (
            position.reset_index()[["timestamp", "pos_fiat"]]
            .groupby("timestamp")
            .sum()["pos_fiat"]
        )
        # Plot total gross position
        axes[3].plot(
            gross_position.index,
            gross_position,
            alpha=0.7,
            label="Position",
            c="tab:blue",
        )
        axes[3].scatter(
            gross_position.index[gross_position.argmax()],
            gross_position.max(),
            color="green",
            label=f"Gross Maximum: {gross_position.max():.0f}",
            s=10,
        )

        position_title = "Aggregated Gross Position (Base Currency)"
        axes[3].ticklabel_format(style="plain", axis="y")
        axes[3].set_title(position_title)
        axes[3].legend(loc="upper left", bbox_to_anchor=(1, 1))
        # Plot total net position
        axes[4].plot(
            net_position.index,
            net_position,
            alpha=0.7,
            label="Position",
            c="tab:blue",
        )
        axes[4].scatter(
            net_position.index[net_position.argmax()],
            net_position.max(),
            color="green",
            label=f"Net Maximum: {net_position.max():.0f}",
            s=10,
        )
        axes[4].scatter(
            net_position.index[net_position.argmin()],
            net_position.min(),
            color="red",
            label=f"Net Minimum: {net_position.min():.0f}",
            s=10,
        )

        position_title = "Aggregated Net Position (Base Currency)"
        axes[4].ticklabel_format(style="plain", axis="y")
        axes[4].set_title(position_title)
        axes[4].legend(loc="upper left", bbox_to_anchor=(1, 1))

        # Plot total margin rate
        total_effective_leverage = (
            snapshots.reset_index()[["effective_leverage", "timestamp"]]
            .groupby("timestamp")
            .last()["effective_leverage"]
        )
        axes[5].plot(
            total_effective_leverage.index,
            total_effective_leverage,
            alpha=0.7,
            label="Effective Leverage",
            c="tab:blue",
        )
        axes[5].axhline(
            self.cfg["trade_config"]["max_leverage"],
            color="red",
            linestyle="--",
            linewidth=0.5,
            alpha=0.7,
            label=f"Max Leverage: {self.cfg['trade_config']['max_leverage']:.0f}",
        )

        if total_effective_leverage.max() > self.cfg["trade_config"]["max_leverage"]:
            forced_liquidation_level = (
                self.cfg["trade_config"]["max_leverage"]
                / self.cfg["trade_config"]["min_margin_rate"]
            )
            axes[5].axhline(
                forced_liquidation_level,
                color="red",
                linestyle="-",
                linewidth=0.5,
                alpha=0.7,
                label=f"Forced Liquidation Level: {forced_liquidation_level:.0f}",
            )

        axes[5].scatter(
            [total_effective_leverage.index[total_effective_leverage.argmax()]],
            [total_effective_leverage.max()],
            color="red",
            label=f"Realized Peak: {total_effective_leverage.max():.1f}",
            s=10,
        )

        axes[5].set_title("Effective Leverage (Aggregate)")
        axes[5].ticklabel_format(style="plain", axis="y")
        axes[5].legend(loc="upper left", bbox_to_anchor=(1, 1))

        for ax in axes:
            ax.grid(True, which="both", linestyle="--", linewidth=0.5)
            ax.xaxis.set_major_locator(mdates.AutoDateLocator())
            ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y-%m-%d"))
            # type: ignore
            ax.set_xlim(pd.to_datetime([raw_df.index[0][0], raw_df.index[-1][0]]))

        # Adjust spacing between subplots
        fig.tight_layout(rect=(0, 0, 1, 0.99))

        # Save the figure
        fig.savefig(filename)
        plt.close()

        if self.cfg["backtester_config"]["use_wandb"]:
            wandb.log({"backtest graph": wandb.Image(fig)})

    def plot_combined_effective_margin(
        self, snapshots_list: list, raw_df: pd.DataFrame, filename: dict
    ) -> None:
        for symbol in self.cfg["backtester_config"]["symbol"]:
            # Create a figure and axis object
            fig, ax1 = plt.subplots(figsize=(15, 10))

            # Get the original indices based on the sorting of the final effective_margin values
            def get_effective_margin_value(k: int) -> Any:
                return (
                    snapshots_list[k]
                    .loc[(slice(None), self.cfg["backtester_config"]["symbol"][0]), :]
                    .reset_index("symbol", drop=True)
                    .effective_margin.iloc[-1]
                )

            sorted_indices = sorted(
                range(len(snapshots_list)), key=get_effective_margin_value, reverse=True
            )

            # Sort the snapshots based on the final effective_margin value in descending order
            sorted_snapshots_list = [
                snapshots_list[i]
                .loc[(slice(None), self.cfg["backtester_config"]["symbol"][0]), :]
                .reset_index("symbol", drop=True)
                for i in sorted_indices
            ]

            # Generate colors by restricting the range of the colormap
            cmap = plt.get_cmap("coolwarm")
            num = len(snapshots_list)

            # Get colors by excluding the range 0.2-0.8
            color_values = list(np.linspace(0, 0.2, num // 2)) + list(
                np.linspace(0.8, 1, num - num // 2)
            )
            colors = cmap(color_values)

            # Iterate over each snapshot and plot its effective_margin using the color palette

            for original_idx, snapshots, color in zip(
                sorted_indices, sorted_snapshots_list, colors
            ):
                raw_df_ = raw_df.loc[(slice(None), symbol), :].reset_index(
                    "symbol", drop=True
                )
                ax1.plot(
                    snapshots.index,
                    snapshots.effective_margin,
                    label=f"Path {original_idx}",
                    color=color,
                    linewidth=0.85,
                )

            ax2 = ax1.twinx()  # Creating a second y-axis
            ax2.plot(
                raw_df_.index,
                raw_df_.close,
                label="Close Price",
                alpha=0.3,
                color="gray",
                linewidth=0.8,
            )

            ax1.set_title("Combined Effective Margin from Different Paths")
            ax1.set_xlabel("Date")
            ax1.set_ylabel("Effective Margin")
            ax2.set_ylabel("Close Price")

            # Combining legends from both axes and placing them at the top
            lines, labels = ax1.get_legend_handles_labels()
            lines2, labels2 = ax2.get_legend_handles_labels()
            ax1.legend(lines + lines2, labels + labels2, loc="upper left")

            ax1.grid(
                True, which="both", linestyle="--", linewidth=0.5, color="gray"
            )  # Displaying the grid
            plt.tight_layout()

            plt.savefig(filename[symbol])
            plt.close()

            if self.cfg["backtester_config"]["use_wandb"]:
                wandb.log({"combined effective_margin": wandb.Image(fig)})

    # ログをpklファイルに出力
    def output_log(self, filename: str) -> None:
        self.pos_manager.snapshots.to_pickle(filename)

    # fillsをpklファイルに出力
    def output_fills(self, filename: str) -> None:
        fill_list = []
        for symbol in self.event_handler.fill_events.keys():
            fill_df = pd.DataFrame(self.event_handler.fill_events[symbol])
            fill_df["symbol"] = symbol
            fill_list.append(fill_df)
        fill_list = [fill for fill in fill_list if len(fill) != 0]
        fills = (
            pd.DataFrame()
            if len(fill_list) == 0
            else pd.concat(fill_list).set_index("timestamp")
        )
        fills.index = np.array([pd.Timestamp(t_str) for t_str in fills.index])
        fills = (
            fills
            if len(fill_list) == 0
            else fills.sort_index().set_index("symbol", append=True)
        )
        fills.to_pickle(filename)

    def log_summary(self) -> list:
        wandb_log_messages = []
        wandb_log_messages.append(
            {
                "sharpe_ratio": self.stats["sharpe_ratio"],
                "max_dd": self.stats["max_dd"],
                # wandb側で/がエスケープ文字
                "profit_ratio": self.stats["pnl/initial_balance"],
                "max_dd_stime": str(self.stats["max_dd_stime"]),
                "max_dd_etime": str(self.stats["max_dd_etime"]),
                "effective_margin": self.pos_manager.effective_margin,
                "margin_balance": self.pos_manager.margin_balance,
                "commission": {
                    symbol: self.pos_manager.snapshots.loc[
                        (slice(None), symbol), :
                    ].commission.values[-1]
                    for symbol in self.cfg["backtester_config"]["symbol"]
                },
                "slippage": self.pos_manager.slippages,
                "realized_funding_fee": self.pos_manager.realized_funding_fees,
                "rpnl": self.pos_manager.rpnls,
                "upnl": self.pos_manager.upnls,
                "オーダー回数": {
                    symbol: len(self.event_handler.order_history[symbol])
                    for symbol in self.cfg["backtester_config"]["symbol"]
                },
                "約定回数": {
                    symbol: len(self.event_handler.fill_events[symbol])
                    for symbol in self.cfg["backtester_config"]["symbol"]
                },
                "ポジションサイズの最大値": {
                    symbol: self.pos_manager.snapshots.loc[(slice(None), symbol), :]
                    .signed_pos_size.abs()
                    .max()
                    for symbol in self.cfg["backtester_config"]["symbol"]
                },
            }
        )
        close_event_list = []
        for symbol in self.cfg["backtester_config"]["symbol"]:
            close_event_df = pd.DataFrame(
                self.event_handler.close_events[symbol]
            ).set_index("timestamp")
            close_event_df.index = np.array(
                [pd.Timestamp(t_str) for t_str in close_event_df.index]
            )
            close_event_df["symbol"] = symbol
            close_event_list.append(close_event_df)
        close_events = (
            pd.concat(close_event_list).sort_index().set_index("symbol", append=True)
        )
        if close_events.empty:
            wandb_log_messages.append({"ポジション保有時間": 0, "勝率": 0})
        else:
            wandb_log_messages.append(
                {
                    "平均ポジション保有時間": {
                        symbol: str(
                            close_events.loc[(slice(None), symbol), :].duration.mean()
                        )
                        for symbol in self.cfg["backtester_config"]["symbol"]
                    },
                    "勝率": {
                        symbol: (
                            close_events.loc[(slice(None), symbol), :].rpnl
                            - close_events.loc[(slice(None), symbol), :].commission
                            - close_events.loc[(slice(None), symbol), :].slippage
                        )
                        .apply(lambda x: 1 if x > 0 else 0)
                        .mean()
                        for symbol in self.cfg["backtester_config"]["symbol"]
                    },
                }
            )
        return wandb_log_messages

    def output_wandb_log(self, wandb_log_message: dict) -> None:
        wandb.log(wandb_log_message)

    def max_drawdown(
        self,
        effective_margin: pd.Series,
        compounding: bool = False,
        initial_margin_balance: Optional[float] = None,
    ) -> tuple[float, pd.Timestamp, pd.Timestamp, pd.Timestamp]:
        """Calculates max drawdown from a series of net asset values"""
        effective_margin_tmp = effective_margin.copy(deep=True)
        effective_margin_tmp = pd.DataFrame(effective_margin_tmp)
        effective_margin_tmp["cummax"] = effective_margin_tmp.cummax()
        effective_margin_tmp["timestamp"] = effective_margin_tmp.index
        effective_margin_tmp = effective_margin_tmp.merge(
            effective_margin_tmp.groupby("cummax")[["timestamp"]].first().reset_index(),
            on="cummax",
        )
        effective_margin_tmp.rename(
            columns={"timestamp_y": "max_timestamp"}, inplace=True
        )
        effective_margin_tmp.index = effective_margin_tmp.timestamp_x
        del effective_margin_tmp["timestamp_x"]

        if compounding:
            effective_margin_tmp["dd"] = (
                (effective_margin - effective_margin.cummax())
                / effective_margin.cummax()
            ).values
        else:
            if initial_margin_balance is None:
                raise ValueError(
                    "If compounding is False, initial_margin_balance must be provided."
                )
            effective_margin_tmp["dd"] = (
                (effective_margin - effective_margin.cummax()) / initial_margin_balance
            ).values
        effective_margin_tmp["dd"] = effective_margin_tmp["dd"].apply(
            lambda x: 0 if x == -float("inf") else x
        )
        max_dd_etime = effective_margin_tmp.dd.idxmin()
        max_dd_stime = effective_margin_tmp.loc[max_dd_etime, "max_timestamp"]

        recovery_index = effective_margin_tmp.loc[max_dd_etime:].index
        recovery_value = effective_margin_tmp.loc[max_dd_stime, "cummax"]
        try:
            underwater_etime = recovery_index[
                effective_margin.loc[recovery_index] >= recovery_value
            ][0]
        except IndexError:
            underwater_etime = None
        return effective_margin_tmp["dd"].min(), max_dd_stime, max_dd_etime, underwater_etime  # type: ignore

    def log_returns(self, effective_margin: pd.Series) -> pd.Series:
        """Calculates log returns from a series of net asset values"""
        start_value = (
            np.log(effective_margin.values[0])
            if effective_margin.values[0] > 0
            else -np.log(abs(effective_margin.values[0]))
        )
        ret = effective_margin.apply(
            lambda x: np.log(x) if x > 0 else -np.log(abs(x))
        ).diff()  # effective_marginが負の値だったら絶対値に直した上で対数をとりマイナスをとる
        # diffでできた欠損を穴埋め
        ret = ret.fillna(
            start_value
            - np.log(self.cfg["backtester_config"]["initial_margin_balance"])
        )
        ret = ret[ret != -float("inf")]
        return ret

    def average_annual_return(
        self,
        effective_margin: pd.Series,
        freq: pd.Timedelta,
        compounding: bool = False,
        initial_margin_balance: Optional[float] = None,
        year_periods: pd.Timedelta = pd.Timedelta("365d"),
    ) -> float:
        annualizer = year_periods / freq
        if compounding:
            log_return = self.log_returns(effective_margin)
            return log_return.mean() * annualizer  # type: ignore
        else:
            if initial_margin_balance is None:
                raise ValueError(
                    "If compounding is False, initial_margin_balance must be provided."
                )
            pnl = effective_margin.diff()
            # diffでできた欠損を穴埋め
            pnl = pnl.fillna(
                effective_margin.values[0]
                - self.cfg["trade_config"]["initial_margin_balance"]
            )
            simple_return = pnl / initial_margin_balance
            return simple_return.mean() * annualizer  # type: ignore

    def average_annual_risk(
        self,
        effective_margin: pd.Series,
        freq: pd.Timedelta,
        compounding: bool = False,
        initial_margin_balance: Optional[float] = None,
        year_periods: pd.Timedelta = pd.Timedelta("365d"),
    ) -> float:
        annualizer = np.sqrt(year_periods / freq)
        if compounding:
            log_return = self.log_returns(effective_margin)
            return log_return.std() * annualizer  # type: ignore
        else:
            if initial_margin_balance is None:
                raise ValueError(
                    "If compounding is False, initial_margin_balance must be provided."
                )
            pnl = effective_margin.diff()
            # diffでできた欠損を穴埋め
            pnl = pnl.fillna(
                effective_margin.values[0]
                - self.cfg["trade_config"]["initial_margin_balance"]
            )
            simple_return = pnl / initial_margin_balance
            return simple_return.std() * annualizer  # type: ignore

    def get_mean_intervals(
        self,
        orders: pd.DataFrame,
        fills: pd.DataFrame,
    ) -> tuple[dict[str, float], dict[str, float]]:
        stime = pd.Timestamp(
            self.data_handler.raw_df.index.get_level_values(0).unique()[0]
        )
        etime = pd.Timestamp(
            self.data_handler.raw_df.index.get_level_values(0).unique()[-1]
        )

        order_interval_mean = {}
        fill_interval_mean = {}
        for symbol in orders.index.get_level_values(1).unique():
            order_times = list(
                orders.loc[(slice(None), symbol), :].index.get_level_values(0).unique()
            )
            if stime not in order_times:
                order_times.append(stime)
            if etime not in order_times:
                order_times.append(etime)
            order_times = sorted(order_times)
            order_interval = [
                (ti - tj).total_seconds() / 60
                for ti, tj in zip(order_times[1:], order_times[:-1])
            ]
            order_interval_mean[symbol] = cast(float, np.mean(order_interval))
        for symbol in fills.index.get_level_values(1).unique():
            fill_times = list(
                fills.loc[(slice(None), symbol), :].index.get_level_values(0).unique()
            )
            if stime not in fill_times:
                fill_times.append(stime)
            if etime not in fill_times:
                fill_times.append(etime)
            fill_times = sorted(fill_times)
            fill_interval = [
                pd.Timedelta(ti - tj).total_seconds() / 60
                for ti, tj in zip(fill_times[1:], fill_times[:-1])
            ]
            fill_interval_mean[symbol] = cast(float, np.mean(fill_interval))

        return order_interval_mean, fill_interval_mean
