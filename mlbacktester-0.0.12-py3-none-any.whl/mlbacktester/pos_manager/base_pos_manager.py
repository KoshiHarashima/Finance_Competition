# Standard Library
from collections import OrderedDict
from datetime import datetime, timedelta, timezone
from typing import Any, Optional

# Third Party Library
import numpy as np
import pandas as pd

# Local Library
from ..data_handler.base_data_handler import BaseDataHandler
from ..event_handler.base_event_handler import BaseEventHandler
from ..utils.custom_types import (
    AssetInfo,
    CloseEvent,
    Fill,
    OpenPosition,
    PositionSnapShot,
)


class BasePosManager:
    """Base class for position manager."""

    class ForcedLiquidation(Exception):
        """forced liquidation"""

    def __init__(
        self, data_handler: BaseDataHandler, event_handler: BaseEventHandler, cfg: dict
    ) -> None:
        """open_positions is a list of open_positions."""
        self.data_handler = data_handler
        self.event_handler = event_handler
        self.cfg = cfg
        self._open_positions: dict[str, OrderedDict[str, OpenPosition]] = {
            symbol: OrderedDict() for symbol in cfg["backtester_config"]["symbol"]
        }
        self._signed_pos_sizes: dict = {
            symbol: 0.0 for symbol in cfg["backtester_config"]["symbol"]
        }
        self._commissions: dict = {
            symbol: 0.0 for symbol in cfg["backtester_config"]["symbol"]
        }
        self._slippages: dict = {
            symbol: 0.0 for symbol in cfg["backtester_config"]["symbol"]
        }
        self._realized_funding_fees = {
            symbol: 0.0 for symbol in cfg["backtester_config"]["symbol"]
        }
        self._taker_fees: dict = {
            symbol: cfg["exchange_config"][symbol]["taker_fee"]
            for symbol in cfg["backtester_config"]["symbol"]
        }
        self._maker_fees: dict = {
            symbol: cfg["exchange_config"][symbol]["maker_fee"]
            for symbol in cfg["backtester_config"]["symbol"]
        }
        self._margin_balance: float = cfg["trade_config"]["initial_margin_balance"]
        self._rpnls: dict = {
            symbol: 0.0 for symbol in cfg["backtester_config"]["symbol"]
        }
        self._snapshots: list[PositionSnapShot] = []
        self.eval_starttime: datetime = self.data_handler._min_bar.index[0][0]
        self.forced_liquidation = False
        self.forced_liquidation_info: list[str] = [""]
        self.tick_sizes: dict = {
            symbol: 0.0 for symbol in cfg["backtester_config"]["symbol"]
        }
        self.pos_ids: dict = {
            symbol: 0 for symbol in cfg["backtester_config"]["symbol"]
        }
        self._upnls: dict = {
            symbol: 0.0 for symbol in cfg["backtester_config"]["symbol"]
        }
        self._avg_prices = {
            symbol: 0.0 for symbol in cfg["backtester_config"]["symbol"]
        }
        self._pos_sizes_in_quote = {
            symbol: 0.0 for symbol in cfg["backtester_config"]["symbol"]
        }

    def update_open_position(
        self,
        fill: Fill,
        _type: str,
        symbol: str,
        exit: bool = False,
        exit_id: Optional[str] = None,
        params: Optional[dict] = None,
    ) -> tuple[bool, str, list[str]]:
        """Update open position."""
        size = fill.size
        price = fill.price
        side = fill.side
        timestamp = fill.timestamp
        size = abs(size) if side == "BUY" else -abs(size)
        exit_position_ids = []
        entry_position_id = ""
        exit_ = False
        # 新たにポジションを持つもしくは同じ方向で増加させる場合
        if (
            self._signed_pos_sizes[symbol] == 0
            or self._signed_pos_sizes[symbol] * size > 0
        ):
            self.pos_ids[symbol] += 1
            entry_position_id = str(self.pos_ids[symbol])
            self._open_positions[symbol][str(self.pos_ids[symbol])] = OpenPosition(
                id=str(self.pos_ids[symbol]),
                side=side,
                size=size,
                price=price,
                order_type=_type,
                timestamp=timestamp,
                params=params,
            )
            self._increase(size, price, _type, symbol)
        # ポジションを減らす場合
        else:
            remain = size
            # 新しいオーダーのサイズが打ち消すまで処理する.
            while remain != 0:
                if exit and exit_id is not None:
                    open_position = self._pop_open_position(symbol, exit_id)
                else:
                    open_position = self._pop_open_position(symbol)
                if open_position is None:
                    break
                if abs(open_position.size) <= abs(remain):
                    remain += open_position.size
                    remain = round(
                        remain,
                        round(
                            -np.log10(self.cfg["exchange_config"][symbol]["min_lot"])
                        ),
                    )
                    self._decrease(
                        open_position.size,
                        open_position.timestamp,
                        open_position.price,
                        price,
                        _type,
                        symbol,
                    )
                    # 取り出されたopen position分をclose eventとして記録
                    open_commission = self._calc_commission(
                        open_position.size,
                        open_position.price,
                        open_position.order_type,
                        symbol,
                    )
                    open_slippage = (
                        open_position.price
                        * (open_position.order_type in ["MARKET", "STOP"])
                        * self.cfg["backtester_config"]["slippage"]
                        * 0.01
                        * abs(open_position.size)
                    )
                    close_slippage = (
                        price
                        * (_type in ["MARKET", "STOP"])
                        * self.cfg["backtester_config"]["slippage"]
                        * 0.01
                        * abs(open_position.size)
                    )
                    self.event_handler.close_events[symbol].append(
                        CloseEvent(
                            id=open_position.id,
                            rpnl=open_position.size * (price - open_position.price),
                            commission=open_commission
                            + self._calc_commission(
                                open_position.size, price, _type, symbol
                            ),
                            slippage=open_slippage + close_slippage,
                            timestamp=self.data_handler.latest_timestamp,
                            duration=self.data_handler.latest_timestamp
                            - open_position.timestamp,
                        )
                    )
                    exit_position_ids.append(open_position.id)
                    exit_ = True
                else:
                    self._decrease(
                        -remain,
                        open_position.timestamp,
                        open_position.price,
                        price,
                        _type,
                        symbol,
                    )
                    # 既存のpositionからsizeを減らす
                    self._open_positions[symbol][open_position.id] = OpenPosition(
                        id=open_position.id,
                        side=open_position.side,
                        size=round(
                            open_position.size + remain,
                            round(
                                -np.log10(
                                    self.cfg["exchange_config"][symbol]["min_lot"]
                                )
                            ),
                        ),
                        price=open_position.price,
                        order_type=open_position.order_type,
                        timestamp=open_position.timestamp,
                        params=open_position.params,
                    )
                    # 減らした分をclose eventとして記録
                    open_commission = self._calc_commission(
                        -remain, open_position.price, open_position.order_type, symbol
                    )
                    open_slippage = (
                        open_position.price
                        * (open_position.order_type in ["MARKET", "STOP"])
                        * self.cfg["backtester_config"]["slippage"]
                        * 0.01
                        * abs(-remain)
                    )
                    close_slippage = (
                        price
                        * (_type in ["MARKET", "STOP"])
                        * self.cfg["backtester_config"]["slippage"]
                        * 0.01
                        * abs(remain)
                    )
                    self.event_handler.close_events[symbol].append(
                        CloseEvent(
                            id=open_position.id,
                            rpnl=-remain * (price - open_position.price),
                            commission=open_commission
                            + self._calc_commission(remain, price, _type, symbol),
                            slippage=open_slippage + close_slippage,
                            timestamp=self.data_handler.latest_timestamp,
                            duration=self.data_handler.latest_timestamp
                            - open_position.timestamp,
                        )
                    )
                    remain = 0
            # ドテン
            if remain != 0:
                self.pos_ids[symbol] += 1
                entry_position_id = str(self.pos_ids[symbol])
                self._open_positions[symbol][str(self.pos_ids[symbol])] = OpenPosition(
                    id=str(self.pos_ids[symbol]),
                    side=side,
                    size=remain,
                    price=price,
                    order_type=_type,
                    timestamp=timestamp,
                    params=params,
                )
                self._increase(remain, price, _type, symbol)
        return exit_, entry_position_id, exit_position_ids

    def _pop_open_position(
        self, symbol: str, pos_id: Optional[str] = None
    ) -> Optional[OpenPosition]:
        if len(self._open_positions[symbol]) == 0:
            return None
        if pos_id is not None:
            if pos_id in self._open_positions[symbol]:
                return self._open_positions[symbol].pop(pos_id)
            else:
                return None
        # 古い方から取り出す
        return self._open_positions[symbol].popitem(last=False)[1]

    def _increase(self, size: float, price: float, _type: str, symbol: str) -> None:
        """Increase position."""
        self._signed_pos_sizes[symbol] += size
        self._signed_pos_sizes[symbol] = round(
            self._signed_pos_sizes[symbol],
            -round(np.log10(self.cfg["exchange_config"][symbol]["min_lot"])),
        )
        self._commissions[symbol] += self._calc_commission(size, price, _type, symbol)
        self._margin_balance -= self._calc_commission(size, price, _type, symbol)
        if _type in ["MARKET", "STOP"]:
            slippage = (
                price * self.cfg["backtester_config"]["slippage"] * 0.01 * abs(size)
            )
            self._slippages[symbol] += slippage
            self._margin_balance -= slippage

    def _decrease(
        self,
        size: float,
        timestamp: pd.Timestamp,
        open_price: float,
        price: float,
        _type: str,
        symbol: str,
    ) -> None:
        """Decrease position."""
        self._signed_pos_sizes[symbol] -= size
        self._signed_pos_sizes[symbol] = round(
            self._signed_pos_sizes[symbol],
            -round(np.log10(self.cfg["exchange_config"][symbol]["min_lot"])),
        )
        self._commissions[symbol] += self._calc_commission(size, price, _type, symbol)
        # sizeが負の場合(売りの場合)、self._avg_priceがpx(買値)より大きい方が儲かる(pnl>0)となる
        self._rpnls[symbol] += size * (price - open_price)
        self._margin_balance += size * (price - open_price) - self._calc_commission(
            size, price, _type, symbol
        )
        if _type in ["MARKET", "STOP"]:
            slippage = (
                price * self.cfg["backtester_config"]["slippage"] * 0.01 * abs(size)
            )
            self._slippages[symbol] += slippage
            self._margin_balance -= slippage

    def _calc_commission(
        self, size: float, price: float, _type: str, symbol: str
    ) -> Any:
        """Calculate commission."""
        if _type == "MARKET" or _type == "STOP" or _type == "TAKE_LIMIT":
            return abs(size) * price * self._taker_fees[symbol] * 0.01
        elif _type == "LIMIT" or _type == "STOP_LIMIT":
            return abs(size) * price * self._maker_fees[symbol] * 0.01
        else:
            raise ValueError("Invalid order type.")

    def update_funding_fee(self) -> None:
        """funding feeを更新"""
        # 資金調達料を付与・徴収
        for idx, rows in self.data_handler.latest_funding_record.iterrows():
            symbol = idx[1]
            if symbol not in self.cfg["backtester_config"]["symbol"]:
                continue
            if self.signed_pos_sizes[symbol] == 0:
                continue
            funding_rate, mark_price = rows["fundingRate"], rows["markPrice"]
            funding_fee = -self.signed_pos_sizes[symbol] * mark_price * funding_rate
            self._realized_funding_fees[symbol] += funding_fee
            self._margin_balance += funding_fee
        # レバレッジ手数料を徴収(毎日6:00+09:00に発生)
        current_ts = self.data_handler.latest_timestamp.astimezone(
            timezone(timedelta(hours=9))
        )
        previous_ts = self.data_handler.latest_bar.index[0][0].astimezone(
            timezone(timedelta(hours=9))
        )
        _leverage_fee_rate = self.get_value_at_datetime(
            self.data_handler.latest_timestamp,
            self.cfg["exchange_config"],
            "leverage_fee",
        )
        for symbol in self.cfg["backtester_config"]["symbol"]:
            # min_barが日足より下位足の場合
            if (current_ts.hour >= 6) and (previous_ts.hour < 6):
                leverage_fee = (
                    -abs(self.signed_pos_sizes[symbol])
                    * self.avg_prices[symbol]
                    * _leverage_fee_rate[symbol]
                    * 0.01
                )
            # min_barが日足より上位足の場合
            elif (current_ts - previous_ts) >= pd.Timedelta(days=1):
                leverage_fee = (
                    -abs(self.signed_pos_sizes[symbol])
                    * self.avg_prices[symbol]
                    * _leverage_fee_rate[symbol]
                    * 0.01
                    * (current_ts - previous_ts).days
                )
            else:
                leverage_fee = 0
            self._realized_funding_fees[symbol] += leverage_fee
            self._margin_balance += leverage_fee

    def take_snapshot(self) -> None:
        timestamp = self.data_handler.latest_timestamp
        for symbol in self.cfg["backtester_config"]["symbol"]:
            self._snapshots.append(
                PositionSnapShot(
                    timestamp=timestamp,
                    symbol=symbol,
                    signed_pos_size=self.signed_pos_sizes[symbol],
                    upnl=self.upnls[symbol],
                    rpnl=round(self.rpnls[symbol], 8),
                    effective_margin=self.effective_margin,
                    margin_balance=self.margin_balance,
                    commission=round(self.commissions[symbol], 8),
                    slippage=round(self.slippages[symbol], 8),
                    realized_funding_fee=round(self.realized_funding_fees[symbol], 8),
                    avg_price=self.avg_prices[symbol],
                    effective_leverage=self.effective_leverage,
                )
            )

    def check_forced_liquidation(self) -> None:
        # check forced liquidation
        max_leverage = self.cfg["trade_config"]["max_leverage"]
        upnl_str = ", ".join(
            [
                "{0} -> {1}".format(symbol, self.upnls[symbol])
                for symbol in self.cfg["backtester_config"]["symbol"]
            ]
        )
        total_amount_str = ", ".join(
            [
                "{0} -> {1}".format(
                    symbol,
                    abs(
                        self.data_handler.latest_bar.close.values[
                            self.data_handler.symbol_idx[symbol]
                        ]
                        * self.signed_pos_sizes[symbol]
                    ),
                )
                for symbol in self.cfg["backtester_config"]["symbol"]
            ]
        )
        tick_close_str = ", ".join(
            [
                "{0} -> {1}".format(
                    symbol,
                    self.data_handler.latest_bar.close.values[
                        self.data_handler.symbol_idx[symbol]
                    ],
                )
                for symbol in self.cfg["backtester_config"]["symbol"]
            ]
        )
        pos_size_str = ", ".join(
            [
                "{0} -> {1}".format(symbol, self.signed_pos_sizes[symbol])
                for symbol in self.cfg["backtester_config"]["symbol"]
            ]
        )
        ErrForcedLiquidation = [
            f"Forced liquidation at time:{self.data_handler.latest_timestamp}",
            "Margin is not enough to continue investment.",
            "----- Assets Info -----",
            f"Effective Margin:{self.effective_margin}",
            f"Margin Balance:{self.margin_balance}",
            f"UPnL:{upnl_str}",
            "----- Managed Assets -----",
            f"Total Amount of Assets:{total_amount_str}",
            "----- Leverage Info -----",
            f"Max Leverage:{max_leverage}",
            f"self._tick.close: {tick_close_str}",
            f"self._pos_size: {pos_size_str}",
        ]

        # 証拠金維持率が最低証拠金維持率を下回った場合にロスカット
        if self.margin_rate < self.cfg["trade_config"]["min_margin_rate"]:
            self.forced_liquidation = True
            self.forced_liquidation_info = ErrForcedLiquidation

    def calc_statistic(self) -> None:
        # 計算が必要な統計量を前もって計算する
        self._avg_prices = {}
        for symbol in self.cfg["backtester_config"]["symbol"]:
            if self.signed_pos_sizes[symbol] == 0:
                self._avg_prices[symbol] = 0
            else:
                self._avg_prices[symbol] = (
                    sum([p.price * p.size for p in self.open_positions[symbol]])
                    / self.signed_pos_sizes[symbol]
                )
        self._upnls = {
            symbol: round(
                self.signed_pos_sizes[symbol]
                * (
                    self.data_handler.latest_bar.close.values[
                        self.data_handler.symbol_idx[symbol]
                    ]
                    - self.avg_prices[symbol]
                ),
                8,
            )
            for symbol in self.cfg["backtester_config"]["symbol"]
        }
        self._pos_sizes_in_quote = {
            symbol: abs(self.signed_pos_sizes[symbol] * self.avg_prices[symbol])
            for symbol in self.cfg["backtester_config"]["symbol"]
        }

    def set_snapshot_df(self) -> None:
        """_snapshotsをpd.DataFrameに変換したものを作成"""
        self._snapshots_df = (
            pd.DataFrame.from_records([vars(s) for s in self._snapshots])
            .set_index(["timestamp", "symbol"])
            .sort_index()
        )
        self._snapshots_df = self._snapshots_df[
            self._snapshots_df.index.get_level_values(0) >= self.eval_starttime
        ]

    @property
    def margin_balance(self) -> float:
        return self._margin_balance

    @property
    def open_positions(self) -> dict[str, list[OpenPosition]]:
        return {
            symbol: list(self._open_positions[symbol].values())
            for symbol in self.cfg["backtester_config"]["symbol"]
        }

    @property
    def open_positions_ids(self) -> dict:
        return self._open_positions

    @property
    def signed_pos_sizes(self) -> dict:
        return self._signed_pos_sizes

    @property
    def avg_prices(self) -> dict:
        return self._avg_prices

    @property
    def commissions(self) -> dict:
        return self._commissions

    @property
    def slippages(self) -> dict:
        return self._slippages

    @property
    def realized_funding_fees(self) -> dict:
        return self._realized_funding_fees

    @property
    def rpnls(self) -> dict:
        return self._rpnls

    @property
    def upnls(self) -> dict:
        # type: ignore
        return self._upnls

    @property
    def effective_margin(self) -> Any:
        return round(
            self.margin_balance + sum(self.upnls.values()),
            8,
        )

    @property
    def signed_margin_req_dict_by_symbol(self) -> dict:
        return {
            symbol: self.signed_pos_sizes[symbol]
            * self.avg_prices[symbol]
            / self.cfg["trade_config"]["max_leverage"]
            for symbol in self.cfg["backtester_config"]["symbol"]
        }

    @property
    def margin_req(self) -> Any:
        return (
            sum(
                [
                    abs(self.signed_pos_sizes[symbol] * self.avg_prices[symbol])
                    for symbol in self.cfg["backtester_config"]["symbol"]
                ]
            )
            / self.cfg["trade_config"]["max_leverage"]
        )

    @property
    def margin_rate(self) -> Any:
        if self.margin_req == 0:
            return np.inf
        elif self.cfg["backtester_config"]["compounding_strategy"]:
            return self.effective_margin / self.margin_req
        else:
            return self.cfg["trade_config"]["initial_margin_balance"] / self.margin_req

    @property
    def effective_leverage(self) -> Any:
        return self.cfg["trade_config"]["max_leverage"] / self.margin_rate

    @property
    def pos_sizes_in_quote(self) -> Any:
        return self._pos_sizes_in_quote

    @property
    def asset_info(self) -> AssetInfo:
        return AssetInfo(
            effective_margin=self.effective_margin,
            margin_balance=self.margin_balance,
            rpnls=self.rpnls,
            upnls=self.upnls,
            signed_pos_sizes=self.signed_pos_sizes,
            avg_prices=self.avg_prices,
            open_positions=self.open_positions,
            commissions=self.commissions,
            slippages=self.slippages,
            realized_funding_fees=self.realized_funding_fees,
            pos_sizes_in_quote=self.pos_sizes_in_quote,
            tick_sizes=self.tick_sizes,
        )

    @property
    def snapshots(self) -> pd.DataFrame:
        return self._snapshots_df

    def get_value_at_datetime(
        self, dt: datetime, dct: dict, param: str
    ) -> dict[str, float]:
        param_dict = {}
        for symbol, value in dct.items():
            lst = value[param]
            for d in lst:
                if d["start"] is not None and d["end"] is not None:
                    if d["start"] <= dt < d["end"]:
                        param_dict[symbol] = d["value"]
                elif d["start"] is None and d["end"] is not None and d["end"] > dt:
                    param_dict[symbol] = d["value"]
                elif d["end"] is None and d["start"] is not None and d["start"] <= dt:
                    param_dict[symbol] = d["value"]
                elif d["start"] is None and d["end"] is None:
                    param_dict[symbol] = d["value"]
            if symbol not in param_dict.keys():
                param_dict[symbol] = None
        return param_dict

    def update_parameter(self, param_name: str, value: dict) -> None:
        if hasattr(self, param_name):
            setattr(self, param_name, value)
        else:
            raise ValueError(f"No such parameter: {param_name}")
