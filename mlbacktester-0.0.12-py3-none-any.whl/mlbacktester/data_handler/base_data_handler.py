import pandas as pd


class BaseDataHandler:
    def __init__(
        self,
        cfg: dict,
        min_bar: pd.DataFrame,
        fr_df: pd.DataFrame,
    ) -> None:
        self.cfg = cfg
        self._min_bar = min_bar
        self._fr_df = fr_df

    def initialize(self, raw_df: pd.DataFrame, signals: pd.DataFrame) -> None:
        """初期化

        Args:
            raw_df (pd.DataFrame): raw data
        """
        self._raw_df, self._signals = self.align_dataframe(raw_df, signals)

        self._processed_df = self._raw_df
        self._next_order_index = 0
        self._latest_signal = self._signals.iloc[
            0 : len(self.cfg["backtester_config"]["symbol"])
        ]
        # 次の発注時刻(00:01が現在として、次は00:15のはず、その時にindex=00:00のsignalを見る)
        # 00:15にはindexが00:00のsignalを使うということ
        self._next_order_timestamp = self._raw_df.index.get_level_values(0).unique()[1]

        # 1分足で、1個目を見る時刻は00:01のはず(closeがわかっているから)
        # 00:00:15になったら発注する
        # 判定はindexが00:15-00:29のものが使われる
        self._latest_timestamp = self._min_bar.index.get_level_values(0).unique()[1]
        self._latest_bar = self._min_bar.iloc[
            0 : len(self.cfg["backtester_config"]["symbol"])
        ]
        self.symbol_idx = {
            symbol: list(self._latest_bar.index.get_level_values(1)).index(symbol)
            for symbol in self.cfg["backtester_config"]["symbol"]
        }
        # 前回のFunding Fee付与・徴収タイミング
        self.previous_funding_timestamp = self._min_bar.index.get_level_values(
            0
        ).unique()[0]
        self._min_latest_index = 0
        self.min_length = len(self._min_bar) - len(
            self.cfg["backtester_config"]["symbol"]
        )

    # こっちは15分足用のstep
    def step(self) -> None:
        """次のバーに進める"""
        if self._next_order_index == len(self._raw_df) - (
            2 * len(self.cfg["backtester_config"]["symbol"])
        ):
            self._next_order_timestamp = self._raw_df.index.get_level_values(
                0
            ).unique()[-1]
            self._latest_signal = self._signals.iloc[
                -2
                * len(self.cfg["backtester_config"]["symbol"]) : -1
                * len(self.cfg["backtester_config"]["symbol"])
            ]
            return
        self._next_order_index += len(self.cfg["backtester_config"]["symbol"])
        self._next_order_timestamp = self._raw_df.index[
            len(self.cfg["backtester_config"]["symbol"]) + self._next_order_index
        ][0]
        self._latest_signal = self._signals.iloc[
            self._next_order_index : self._next_order_index
            + len(self.cfg["backtester_config"]["symbol"])
        ]

    # こっちは1分足用のstep
    def min_step(self) -> None:
        """次のバーに進める"""
        if self._min_latest_index == self.min_length - (
            2 * len(self.cfg["backtester_config"]["symbol"])
        ):
            self._latest_bar = self._min_bar.iloc[
                -2
                * len(self.cfg["backtester_config"]["symbol"]) : -1
                * len(self.cfg["backtester_config"]["symbol"])
            ]
            self._latest_timestamp = self._min_bar.index.get_level_values(0).unique()[
                -1
            ]
            return
        # latest_funding_recordの先頭をmin_step前のlatest_timestampにする
        self.previous_funding_timestamp = self.latest_timestamp
        self._min_latest_index += len(self.cfg["backtester_config"]["symbol"])
        self._latest_timestamp = self._min_bar.index[
            len(self.cfg["backtester_config"]["symbol"]) + self._min_latest_index
        ][0]
        self._latest_bar = self._min_bar.iloc[
            self._min_latest_index : self._min_latest_index
            + len(self.cfg["backtester_config"]["symbol"])
        ]

    @property
    def latest_timestamp(self) -> pd.Timestamp:
        return self._latest_timestamp  # type: ignore

    @property
    def next_order_timestamp(self) -> pd.Timestamp:
        return self._next_order_timestamp  # type: ignore

    @property
    def raw_df(self) -> pd.DataFrame:
        return self._raw_df

    @property
    def preprocessed_df(self) -> pd.DataFrame:
        return self._processed_df

    @property
    def latest_bar(self) -> pd.DataFrame:
        return self._latest_bar

    @property
    def latest_signal(self) -> pd.DataFrame:
        return self._latest_signal

    @property
    def latest_funding_record(self) -> pd.DataFrame:
        if self._fr_df.empty:
            return self._fr_df
        ts = self._fr_df.index.get_level_values(0)
        funding_record = self._fr_df[
            (ts > self.previous_funding_timestamp) & (ts <= self.latest_timestamp)
        ]
        return funding_record

    def align_dataframe(
        self, raw_df: pd.DataFrame, signals: pd.DataFrame
    ) -> tuple[pd.DataFrame, pd.DataFrame]:
        # merged_df = pd.merge(
        #     raw_df, signals, how="left", left_index=True, right_index=True
        # )
        # TODO: raw_dfにあってsignalsにないindexがある場合、おそらくnan埋めできてないためエラーでるのを修正
        # raw_df = raw_df.loc[merged_df.index]
        signals = signals.reindex(raw_df.index)
        return raw_df, signals
