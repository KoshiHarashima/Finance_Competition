from abc import ABCMeta, abstractmethod
from typing import Any

import pandas as pd

from ..utils.custom_types import AssetInfo, Order


class BaseStrategy(metaclass=ABCMeta):
    def __init__(self, cfg: dict) -> None:
        self.cfg = cfg

    def preprocess(self, raw_df: pd.DataFrame) -> pd.DataFrame:
        return raw_df

    @abstractmethod
    def get_signal(self, preprocessed_df: pd.DataFrame, model: Any) -> pd.DataFrame:
        pass

    @abstractmethod
    def get_orders(
        self,
        latest_timestamp: pd.Timestamp,
        latest_bar: pd.DataFrame,
        latest_signal: pd.DataFrame,
        asset_info: AssetInfo,
    ) -> list[Order]:
        pass

    def get_model(self, train_df: pd.DataFrame) -> Any:
        pass
