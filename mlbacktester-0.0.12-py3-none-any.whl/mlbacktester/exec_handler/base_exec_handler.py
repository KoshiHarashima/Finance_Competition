# Standard Library
from typing import Optional, cast

import hydra

# Third Party Library
import numpy as np

# Local Library
from ..data_handler.base_data_handler import BaseDataHandler
from ..event_handler.base_event_handler import BaseEventHandler
from ..pos_manager.base_pos_manager import BasePosManager
from ..utils.custom_types import Fill, OrderEvent


class BaseExecHandler:
    # Error values
    ErrType = "Order type should be only 'MARKET' or 'LIMIT' or 'STOP' "
    ErrSide = "Order side should be only 'BUY' or 'SELL' "
    ErrNonPositive = "Limit price is non-positive number"
    ErrorWrongType = "The type of limit price should be int or float"
    ErrMaxLot = "Order size is larger than max lot-size"
    ErrMinLot = "Order size lower than minimum lot-size"
    ErrMaxPos = "Effective margin is insufficient relative to the margin requirement"

    def __init__(
        self,
        event_handler: BaseEventHandler,
        data_handler: BaseDataHandler,
        pos_manager: BasePosManager,
        cfg: dict,
    ) -> None:
        self.event_handler = event_handler
        self.data_handler = data_handler
        self.pos_manager = pos_manager
        self.cfg = cfg
        self.fill_id = 0

    def execute(self) -> None:
        for symbol in self.cfg["backtester_config"]["symbol"]:
            not_executed_active_orders = []
            while True:
                order_event = self.event_handler.pop_order_event(symbol)
                if order_event is None:
                    break
                err = self._validate_order(order_event, symbol)
                if err is not None:
                    hydra.utils.log.warning(err)
                    continue
                expired = self._check_expire(order_event, symbol)
                if expired:
                    self.event_handler.append_expired_order(order_event, symbol)
                    continue
                order_event = self._check_triggered(order_event, symbol)
                fill = self._handle_order(order_event, symbol)
                if fill is None:
                    not_executed_active_orders.append(order_event)
                else:
                    (
                        exit_,
                        entry_position_id,
                        exit_position_ids,
                    ) = self.pos_manager.update_open_position(
                        fill,
                        order_event.type,
                        symbol,
                        order_event.exit,
                        order_event.exit_id,
                        order_event.params,
                    )
                    fill.exit = exit_
                    fill.entry_position_id = entry_position_id
                    fill.exit_position_ids = exit_position_ids
                    self.event_handler.append_fill_event(fill, symbol)
            # 約定しなかったがactiveなorderはorder_eventsに順番を保ちながら戻す
            for order in not_executed_active_orders:
                self.event_handler.append_order_event(order, symbol)
        self.pos_manager.check_forced_liquidation()

    def _check_expire(self, order_item: OrderEvent, symbol: str) -> bool:
        if order_item.type == "MARKET":
            return False
        # 注文の有効期限をチェック
        time_diff = self.data_handler.latest_timestamp - order_item.timestamp
        if (
            time_diff.total_seconds()
            > order_item.minutes_to_expire * 60 + self.cfg["backtester_config"]["delay"]
            or time_diff.total_seconds() < 0
        ):
            return True
        # check exit order is active or valid
        if order_item.exit:
            # exit_idが指定されている場合に,open_positions_idsにない場合
            # ユーザー側のミスか,すでにcloseしたかのどちらか
            if (
                order_item.exit_id
                and self.pos_manager.open_positions_ids[symbol].get(order_item.exit_id)
                is None
            ):
                return True
            # 新規のエントリーの場合もしくは既存のポジションを増やす場合はexitではない
            if (
                self.pos_manager.signed_pos_sizes[symbol] >= 0
                and order_item.side == "BUY"
            ) or (
                self.pos_manager.signed_pos_sizes[symbol] <= 0
                and order_item.side == "SELL"
            ):
                return True
        return False

    def _check_triggered(self, order_item: OrderEvent, symbol: str) -> OrderEvent:
        side = order_item.side
        price = order_item.price
        _type = order_item.type
        _triggered_timestamp = order_item.triggered_timestamp

        _dt = order_item.timestamp.to_pydatetime()
        _tick_size = self.pos_manager.get_value_at_datetime(
            _dt, self.cfg["exchange_config"], "tick_size"
        )

        if _type == "STOP_LIMIT" and (_triggered_timestamp is None):
            _price = round(price, -round(np.log10(_tick_size[symbol])))  # type: ignore
            # 買い注文の場合、トリガー価格よりも市場価格が上がっていたらトリガーされたことにする
            is_triggered = (
                side == "BUY"
                and _price
                <= self.data_handler.latest_bar.high.values[
                    self.data_handler.symbol_idx[symbol]
                ]
                # 売り注文の場合、トリガー価格よりも市場価格が下がっていたらトリガーされたことにする
            ) or (
                side == "SELL"
                and _price
                >= self.data_handler.latest_bar.low.values[
                    self.data_handler.symbol_idx[symbol]
                ]
            )

            if is_triggered:
                _triggered_timestamp = self.data_handler.latest_timestamp

        order_item.triggered_timestamp = _triggered_timestamp
        return order_item

    def _handle_order(self, order_item: OrderEvent, symbol: str) -> Optional[Fill]:
        size = order_item.size
        side = order_item.side
        _type = order_item.type
        _dt = order_item.timestamp.to_pydatetime()

        _tick_size = self.pos_manager.get_value_at_datetime(
            _dt, self.cfg["exchange_config"], "tick_size"
        )
        self.pos_manager.update_parameter("tick_sizes", _tick_size)

        _maker_fee = self.pos_manager.get_value_at_datetime(
            _dt, self.cfg["exchange_config"], "maker_fee"
        )
        self.pos_manager.update_parameter("_maker_fees", _maker_fee)

        _taker_fee = self.pos_manager.get_value_at_datetime(
            _dt, self.cfg["exchange_config"], "taker_fee"
        )
        self.pos_manager.update_parameter("_taker_fees", _taker_fee)

        # 約定価格
        exe_price = 0.0
        if _type == "MARKET":
            # MARKET注文の場合には始値にスリッページを加味して決済
            exe_price = self.data_handler.latest_bar.open.values[
                self.data_handler.symbol_idx[symbol]
            ]

        else:
            exe_price = order_item.price  # type: ignore

        # 呼び値単位に丸める
        exe_price = round(
            exe_price, -round(np.log10(_tick_size[symbol]))
        )  # type: ignore

        # 指値注文の約定判定
        if _type == "LIMIT" or _type == "TAKE_LIMIT":
            price = round(
                order_item.price, -round(np.log10(_tick_size[symbol]))  # type: ignore
            )
            # 買いたい価格よりも市場価格が下がっていたら買えたことにする
            lo_contract = (
                side == "BUY"
                and price
                >= self.data_handler.latest_bar.low.values[
                    self.data_handler.symbol_idx[symbol]
                ]
                # 売りたい価格よりも市場価格が上がっていたら売れたことにする
            ) or (
                side == "SELL"
                and price
                <= self.data_handler.latest_bar.high.values[
                    self.data_handler.symbol_idx[symbol]
                ]
            )
        else:
            lo_contract = False

        # ストップ注文の約定判定
        if _type == "STOP":
            price = round(
                order_item.price, -round(np.log10(_tick_size[symbol]))  # type: ignore
            )
            stop_contract = (
                side == "SELL"
                and price
                >= self.data_handler.latest_bar.low.values[
                    self.data_handler.symbol_idx[symbol]
                ]
            ) or (
                side == "BUY"
                and price
                <= self.data_handler.latest_bar.high.values[
                    self.data_handler.symbol_idx[symbol]
                ]
            )
        else:
            stop_contract = False

        # 逆指値注文の約定判定
        _triggered_timestamp = order_item.triggered_timestamp
        if _type == "STOP_LIMIT" and (_triggered_timestamp is not None):
            price = round(order_item.price, -round(np.log10(_tick_size)))  # type: ignore
            stop_limit_contract = (
                # トリガー直後の場合、買いたい価格よりも終値が下がっていたら買えたことにする
                (
                    _triggered_timestamp == self.data_handler.latest_timestamp
                    and side == "BUY"
                    and price
                    >= self.data_handler.latest_bar.close.values[
                        self.data_handler.symbol_idx[symbol]
                    ]
                )
                # トリガー直後ではない場合、買いたい価格よりも市場価格が下がっていたら買えたことにする
                or (
                    _triggered_timestamp < self.data_handler.latest_timestamp
                    and side == "BUY"
                    and price
                    >= self.data_handler.latest_bar.low.values[
                        self.data_handler.symbol_idx[symbol]
                    ]
                )
                # トリガー直後の場合、売りたい価格よりも終値が上がっていたら売れたことにする
                or (
                    _triggered_timestamp == self.data_handler.latest_timestamp
                    and side == "SELL"
                    and price
                    <= self.data_handler.latest_bar.close.values[
                        self.data_handler.symbol_idx[symbol]
                    ]
                )
                # トリガー直後ではない場合、売りたい価格よりも市場価格が上がっていたら売れたことにする
                or (
                    _triggered_timestamp < self.data_handler.latest_timestamp
                    and side == "SELL"
                    and price
                    <= self.data_handler.latest_bar.high.values[
                        self.data_handler.symbol_idx[symbol]
                    ]
                )
            )
        else:
            _triggered_timestamp = None
            stop_limit_contract = False

        # 注文処理
        if _type == "MARKET" or lo_contract or stop_contract or stop_limit_contract:
            # reduce_only注文でsizeがドテンの場合、ポジションサイズに合わせる
            is_opposite_direction = (
                order_item.side == "BUY"
                and self.pos_manager.signed_pos_sizes[symbol] < 0
            ) or (
                order_item.side == "SELL"
                and self.pos_manager.signed_pos_sizes[symbol] > 0
            )
            # 注文サイズが現在のポジションサイズより大きいかどうか
            is_size_exceeding = order_item.size > abs(
                self.pos_manager.signed_pos_sizes[symbol]
            )

            if is_opposite_direction and is_size_exceeding:
                size = abs(self.pos_manager.signed_pos_sizes[symbol])

            # sizeをロット単位に丸める
            size = round(
                size, -round(np.log10(self.cfg["exchange_config"][symbol]["min_lot"]))
            )
            self.fill_id += 1
            return Fill(
                str(self.fill_id),
                _type,
                side,
                size,
                exe_price,
                self.data_handler.latest_timestamp,
                _triggered_timestamp,
            )
        return None

    def _validate_order(  # noqa
        self, order_item: OrderEvent, symbol: str
    ) -> Optional[str]:
        _type = order_item.type
        side = order_item.side
        size = abs(order_item.size) if side == "BUY" else -abs(order_item.size)
        px = order_item.price
        # Check _type
        if _type not in ["MARKET", "LIMIT", "STOP", "STOP_LIMIT", "TAKE_LIMIT"]:
            return self.ErrType

        # Check order_side
        if side not in ["BUY", "SELL"]:
            return self.ErrSide

        # Check non-negative price in case of limit order
        if _type == "LIMIT" or _type == "STOP" or _type == "STOP_LIMIT":
            if (not isinstance(px, int)) and (not isinstance(px, float)):
                return self.ErrorWrongType
            elif px <= 0:
                return self.ErrNonPositive
        else:
            px = self.data_handler.latest_bar.open.values[
                self.data_handler.symbol_idx[symbol]
            ]

        # Check size
        # TODO: Inverse or Linearの分岐としてまとめたい
        if self.cfg["backtester_config"]["exchange"] == "deribit":
            if (
                abs(size)
                * self.data_handler.latest_bar.close.values[
                    self.data_handler.symbol_idx[symbol]
                ]
                < self.cfg["exchange_config"][symbol]["min_lot"]
            ):  # check minimum lot(deribit)
                return self.ErrMinLot + f", size:{abs(size)}"
            if (
                abs(size)
                * self.data_handler.latest_bar.close.values[
                    self.data_handler.symbol_idx[symbol]
                ]
                > self.cfg["exchange_config"][symbol]["max_lot"]
            ):  # check max lot(deribit)
                return self.ErrMaxLot + f", size:{abs(size)}"
        elif self.cfg["backtester_config"]["exchange"] == "binance":
            if (
                abs(size) < self.cfg["exchange_config"][symbol]["min_lot"]
            ):  # check minimum lot(binance)
                return self.ErrMinLot + f", size:{abs(size)}"
            if (
                _type == "LIMIT"
                and abs(size) > self.cfg["exchange_config"][symbol]["limit_max_lot"]
            ):  # check limit max lot(binance)
                return self.ErrMaxLot + f", size:{abs(size)}"
            elif (_type == "MARKET" or _type == "STOP") and abs(size) > self.cfg[
                "exchange_config"
            ][symbol][
                "market_max_lot"
            ]:  # check market max lot(binance)
                return self.ErrMaxLot + f", size:{abs(size)}"
        else:
            if (
                abs(size) < self.cfg["exchange_config"][symbol]["min_lot"]
            ):  # check minimum lot
                return self.ErrMinLot + f", size:{abs(size)}"
            if (
                abs(size) > self.cfg["exchange_config"][symbol]["max_lot"]
            ):  # check max lot
                return self.ErrMaxLot + f", size:{abs(size)}"

        px = cast(float, px)

        # 既存ポジションの必要証拠金
        signed_margin_req_dict = self.pos_manager.signed_margin_req_dict_by_symbol

        # 追加ポジションの必要証拠金
        additional_signed_margin_req = (
            px * size / self.cfg["trade_config"]["max_leverage"]
        )

        # 注文がエグジットか (かつドテンでないか) どうか判定
        is_exit = (
            signed_margin_req_dict[symbol] * additional_signed_margin_req < 0
        ) & (abs(signed_margin_req_dict[symbol]) >= abs(additional_signed_margin_req))

        # 追加ポジションの銘柄に関して必要証拠金を更新
        signed_margin_req_dict[symbol] += additional_signed_margin_req

        # 必要証拠金総額
        total_margin_req = sum(abs(value) for value in signed_margin_req_dict.values())

        # エグジットでなく、必要証拠金に対して十分な有効証拠金があるか
        if (not is_exit) & (self.pos_manager.effective_margin < total_margin_req):
            return self.ErrMaxPos

        return None
