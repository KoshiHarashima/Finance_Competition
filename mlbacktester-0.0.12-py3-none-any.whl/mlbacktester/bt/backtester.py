# Third Party Library
import hydra
import pandas as pd
from tqdm import tqdm

# Local Library
from ..data_handler.base_data_handler import BaseDataHandler
from ..event_handler.base_event_handler import BaseEventHandler
from ..exec_handler.base_exec_handler import BaseExecHandler
from ..pos_manager.base_pos_manager import BasePosManager
from ..stats.base_stats import BaseStats
from ..strategy.base_strategy import BaseStrategy
from ..utils.custom_types import MessageOnlyOrder, Order, OrderEvent
from ..utils.logging_utils import log_info_if_enabled


class BackTester:
    def __init__(
        self,
        cfg: dict,
    ) -> None:
        self.cfg = cfg
        self.logging_enabled = self.cfg["backtester_config"]["logging"]
        strategy_timeframe = self.cfg["trade_config"]["strategy_timeframe"]
        # strategy_timeframeを分に変換
        self.strategy_timeframe = self._conv_timeframe(strategy_timeframe)
        backtest_timeframe = self.cfg["backtester_config"]["backtest_timeframe"]
        # backtest_timeframeを分に変換
        self.backtest_timeframe = self._conv_timeframe(backtest_timeframe)

    def _conv_timeframe(self, timeframe: str) -> int:
        """configのtimeframeを分に変換"""
        if timeframe[-1] == "m":
            timeframe_min = int(timeframe[:-3])
        elif timeframe[-1] == "h":
            timeframe_min = int(timeframe[:-1]) * 60
        elif timeframe[-1] == "d":
            timeframe_min = int(timeframe[:-1]) * 60 * 24
        elif len(timeframe) > 3 and timeframe[-3:] == "min":
            timeframe_min = int(timeframe[:-3])
        else:
            raise ValueError("strategy_timeframe must be min, h, or d.")
        return timeframe_min

    def _check_symbol(
        self,
        min_bar: pd.DataFrame,
        external_bars: list[pd.DataFrame],
        fr_df: pd.DataFrame,
    ) -> None:
        """入力データにcfgで指定したsymbolがあるか確認する

        Args:
            min_bar (pd.DataFrame): 1分足の生データ
            external_bars (list[pd.DataFrame]): 外部データのリスト
            fr_df (pd.DataFrame): FundingRateのヒストリカルデータ
        """
        is_symbol_in_min_bar = all(
            symbol in min_bar.index.levels[1]
            for symbol in self.cfg["backtester_config"]["symbol"]
        )
        is_symbol_in_external_bars = all(
            [
                all(
                    symbol in df.index.levels[1]
                    for symbol in self.cfg["backtester_config"]["symbol"]
                )
                for df in external_bars
            ]
        )
        if not fr_df.empty:
            is_symbol_in_fr_df = all(
                symbol in fr_df.index.levels[1]
                for symbol in self.cfg["backtester_config"]["symbol"]
            )
            if not is_symbol_in_fr_df:
                raise SymbolNotFound("Symbol in config not found in fr_df")

        if not is_symbol_in_min_bar:
            raise SymbolNotFound("Symbol in config not found in min_bar")
        if not is_symbol_in_external_bars:
            raise SymbolNotFound("Symbol in config not found in external_bars")

        return None

    def assign_TZ(
        self,
        min_bar: pd.DataFrame,
        external_bars: list[pd.DataFrame],
        fr_df: pd.DataFrame,
    ) -> tuple[pd.DataFrame, list[pd.DataFrame], pd.DataFrame]:
        """assign_TZ

        Args:
            min_bar (pd.DataFrame): 1分足の生データ
            external_bars (list[pd.DataFrame]): 外部データのリスト
            fr_df (pd.DataFrame): FundingRateのヒストリカルデータ
        """
        # タイムゾーンの確認
        # OHLCVのタイムゾーンを確認
        min_bar_tz = min_bar.index.levels[0].tz
        if min_bar_tz is None:  # min_barにTZが設定されていない場合は警告しcfgに合わせる
            log_info_if_enabled(
                "Warning: OHLCV index has no timezone information.",
                self.logging_enabled,
            )
            min_bar.index = min_bar.index.set_levels(
                min_bar.index.levels[0].tz_localize(
                    self.cfg["backtester_config"]["time_zone"]
                ),
                level="timestamp",
            )
        elif (
            str(min_bar_tz) != self.cfg["backtester_config"]["time_zone"]
        ):  # min_barのTZがcfgと異なる場合はcfgに合わせる
            log_info_if_enabled(
                f"Timezone Check: OHLCV timezone {min_bar_tz} is converted to {self.cfg['backtester_config']['time_zone']}.",
                self.logging_enabled,
            )
            min_bar.index = min_bar.index.set_levels(
                min_bar.index.levels[0].tz_convert(
                    self.cfg["backtester_config"]["time_zone"]
                ),
                level="timestamp",
            )
        else:
            log_info_if_enabled(
                f"Timezone Check: OHLCV timezone {min_bar_tz} is consistent with the backtester_config.",
                self.logging_enabled,
            )
        # FundingRateヒストリカルデータのタイムゾーンを確認
        if not fr_df.empty:
            fr_tz = fr_df.index.levels[0].tz
            if fr_tz is None:
                log_info_if_enabled(
                    "Warning: fr_df index  has no timezone information.",
                    self.logging_enabled,
                )
                fr_df.index = fr_df.index.set_levels(
                    fr_df.index.levels[0].tz_localize(
                        self.cfg["backtester_config"]["time_zone"]
                    ),
                    level="timestamp",
                )
            elif str(fr_tz) != self.cfg["backtester_config"]["time_zone"]:
                log_info_if_enabled(
                    f"Timezone Check: fr_df timezone {fr_tz} is converted to {self.cfg['backtester_config']['time_zone']}.",
                    self.logging_enabled,
                )
                fr_df.index = fr_df.index.set_levels(
                    fr_df.index.levels[0].tz_convert(
                        self.cfg["backtester_config"]["time_zone"]
                    ),
                    level="timestamp",
                )
            else:
                log_info_if_enabled(
                    f"Timezone Check: fr_df timezone {fr_tz} is consistent with the backtester_config.",
                    self.logging_enabled,
                )
        # 外部データのタイムゾーンを確認
        for i, df in enumerate(external_bars):
            if df.index.levels[0].tz is None:
                log_info_if_enabled(
                    f"Warning: External data {i} has no timezone information.",
                    self.logging_enabled,
                )
                external_bars[i].index = df.index.set_levels(
                    df.index.levels[0].tz_localize(
                        self.cfg["backtester_config"]["time_zone"]
                    ),
                    level=0,
                )
            elif (
                str(df.index.levels[0].tz) != self.cfg["backtester_config"]["time_zone"]
            ):
                log_info_if_enabled(
                    f"Timezone Check: External data {i} timezone {df.index.levels[0].tz} is converted to {self.cfg['backtester_config']['time_zone']}.",
                    self.logging_enabled,
                )
                external_bars[i].index = df.index.set_levels(
                    df.index.levels[0].tz_convert(
                        self.cfg["backtester_config"]["time_zone"]
                    ),
                    level=0,
                )
            else:
                log_info_if_enabled(
                    f"Timezone Check: External data {i} timezone {df.index.levels[0].tz} is consistent with the backtester_config.",
                    self.logging_enabled,
                )
        return min_bar, external_bars, fr_df

    def preprocess_fr_df(self, fr_df: pd.DataFrame) -> pd.DataFrame:
        """FundingRateヒストリカルデータの欠損値を処理する

        Args:
            fr_df (pd.DataFrame): 入力となるfunding rateのヒストリカルデータ

        Returns:
            pd.DataFrame: 前処理後のfunding rateのヒストリカルデータ
        """
        # fundingRateに欠損がある場合は直前のfundingRateで埋める
        if not fr_df[fr_df["fundingRate"].isnull()].empty:
            fr_df["fundingRate"] = fr_df["fundingRate"].ffill()
        # markPriceが存在しない場合はmin_barのopenで穴埋めする
        if "markPrice" not in fr_df.columns:
            # fr_dfをbacktest_timeframeに合わせる
            _fr_df = fr_df.reset_index()
            _fr_df["funding_timestamp"] = _fr_df["timestamp"].copy(deep=True)
            _fr_df["timestamp"] = _fr_df["timestamp"].dt.floor(
                self.cfg["backtester_config"]["backtest_timeframe"]
            )
            _fr_df = _fr_df.set_index(["timestamp", "symbol"]).sort_index()
            # min_barのopenとマージしてfr_dfのtimestampを復元
            markPrice = self.min_bar[["open"]].rename(columns={"open": "markPrice"})
            fr_df = (
                pd.merge(
                    _fr_df, markPrice, how="left", left_index=True, right_index=True
                )
                .reset_index()
                .drop(columns="timestamp")
                .rename(columns={"funding_timestamp": "timestamp"})
            )
            fr_df = fr_df.set_index(["timestamp", "symbol"]).sort_index()
        # markPriceに欠損がある場合min_barのopen or 直前のmarkPriceで穴埋めする
        if not fr_df[fr_df["markPrice"].isnull()].empty:
            funding_interval = (
                fr_df.index.get_level_values(0).to_series().diff().dropna().mean()
            )
            # backtest_timeframeがfr_dfの頻度未満の場合は直前のmarkPriceで穴埋め
            if funding_interval < pd.Timedelta(minutes=self.backtest_timeframe):
                fr_df["markPrice"] = fr_df["markPrice"].ffill()
            else:
                # backtest_timeframeがfr_dfの頻度以上の場合はmin_barのopenで穴埋め
                markPrice_lack_idx = fr_df[fr_df["markPrice"].isnull()].index.copy()
                open_fill_loc = markPrice_lack_idx.copy().to_frame()
                open_fill_loc["timestamp"] = open_fill_loc["timestamp"].dt.floor(
                    self.cfg["backtester_config"]["backtest_timeframe"]
                )
                open_fill_loc = (
                    open_fill_loc.set_index(["timestamp", "symbol"]).sort_index().index
                )
                fr_df["markPrice"].loc[markPrice_lack_idx] = (
                    self.min_bar["open"].loc[open_fill_loc].values
                )
        return fr_df

    def data_initialize(
        self,
        min_bar: pd.DataFrame,
        external_bars: list[pd.DataFrame],
        fr_df: pd.DataFrame,
    ) -> pd.DataFrame:
        """data_initialize
        min_bar: backtester_timeframe間隔のohlcv
        external_bars: 戦略に必要なohlcv以外のデータのリスト
        fr_df: FundingRateのヒストリカルデータ

        Args:
            min_bar (pd.DataFrame): 1分足の生データ
        """
        # 1分足の生データを整形する
        min_bar = min_bar.rename(
            columns={"op": "open", "hi": "high", "lo": "low", "cl": "close"}
        )
        min_bar[["open", "high", "low", "close"]] = min_bar[
            ["open", "high", "low", "close"]
        ].astype(float)
        external_bars = [df.astype(float) for df in external_bars]
        fr_df = fr_df.astype(float)
        fr_df = fr_df[["fundingRate", "markPrice"]]

        # 外部データのsymbol indexを確認、ない場合はデータをohlcvのsymbol分増幅
        for i in range(len(external_bars)):
            df = external_bars[i]
            if "symbol" not in df.index.names:
                multiindex_df = (
                    pd.concat(
                        [df for _ in self.cfg["backtester_config"]["symbol"]],
                        keys=self.cfg["backtester_config"]["symbol"],
                        names=["symbol", "timestamp"],
                    )
                    .swaplevel()
                    .sort_index()
                )
                external_bars[i] = multiindex_df

        # タイムゾーンを確認
        min_bar, external_bars, fr_df = self.assign_TZ(min_bar, external_bars, fr_df)
        start_date = pd.to_datetime(
            self.cfg["backtester_config"]["start_date"]
        ).tz_localize(self.cfg["backtester_config"]["time_zone"])
        end_date = pd.to_datetime(
            self.cfg["backtester_config"]["end_date"]
        ).tz_localize(self.cfg["backtester_config"]["time_zone"])
        # 必要期間にデータを絞る
        self.min_bar = min_bar.loc[pd.IndexSlice[start_date:end_date, :], :]
        self.external_bars = [
            df.loc[pd.IndexSlice[start_date:end_date, :], :] for df in external_bars
        ]
        if fr_df.empty:
            self.fr_df = fr_df
        else:
            # fr_dfの不要な期間と不要なsymbolのデータを除外
            self.fr_df = fr_df.loc[
                pd.IndexSlice[
                    self.min_bar.index[0][0] : end_date,
                    self.cfg["backtester_config"]["symbol"],
                ],
                :,
            ]
            # funding rate付与・徴収時刻をbacktest_timeframeでroundする
            # fr時刻が17:00:40の時に、backtest_timeframeが60minだとfrの反映が18:00にずれてしまうので
            self.fr_df = self.fr_df.reset_index()
            self.fr_df["timestamp"] = self.fr_df["timestamp"].dt.round(
                self.cfg["backtester_config"]["backtest_timeframe"]
            )
            self.fr_df = self.fr_df.set_index(["timestamp", "symbol"]).sort_index()
        # configで指定したsymbolがmin_bar, 外部データにない場合エラーを出す
        self._check_symbol(self.min_bar, self.external_bars, self.fr_df)
        # backtest_timeframeの刻みにtimestampを設定しなおす
        self.min_bar = self._ohlcv_resample(
            self.min_bar, self.cfg["backtester_config"]["backtest_timeframe"]
        )
        # 外部データはstrategy_timeframeで十分
        self.external_bars = [
            self._external_data_resample(
                df, self.cfg["trade_config"]["strategy_timeframe"]
            )
            for df in self.external_bars
        ]
        # TODO: 厳密にbacktest_timeframeの刻みにtimestampを設定しなおすと欠損がある場合がある.
        # 欠損がある部分を抽出
        lack_idx = self.min_bar[self.min_bar.isnull().any(axis=1)].index
        if self.min_bar.loc[lack_idx, :].shape[0] == 0:
            log_info_if_enabled(
                "Missing Data Check: No missing values identified.",
                self.logging_enabled,
            )
        else:
            log_info_if_enabled(
                "Missing Data Check: Missing values found at",
                self.logging_enabled,
            )
            log_info_if_enabled(lack_idx, self.logging_enabled)
        # FundingRateヒストリカルデータの欠損値を確認
        if not self.fr_df.empty:
            fr_df_lack_idx = self.fr_df[self.fr_df.isnull().any(axis=1)].index
            if self.fr_df.loc[fr_df_lack_idx, :].shape[0] == 0:
                log_info_if_enabled(
                    "Missing Data Check: No missing values identified in fr_df.",
                    self.logging_enabled,
                )
            else:
                log_info_if_enabled(
                    "Missing Data Check: fr_df Missing values found at",
                    self.logging_enabled,
                )
                log_info_if_enabled(fr_df_lack_idx, self.logging_enabled)
        # 外部データの欠損確認
        lack_idxs_external = [
            df[df.isnull().any(axis=1)].index for df in self.external_bars
        ]
        for i, lack_idx in enumerate(lack_idxs_external):
            if self.external_bars[i].loc[lack_idx, :].shape[0] == 0:
                log_info_if_enabled(
                    f"Missing Data Check: No missing values identified in external data {i}.",
                    self.logging_enabled,
                )
            else:
                log_info_if_enabled(
                    f"Missing Data Check: Missing values found at external data {i}.",
                    self.logging_enabled,
                )
                log_info_if_enabled(lack_idx, self.logging_enabled)
        # ohlcに欠損がある場合は、それより前の欠損していない最新のcloseで埋める
        min_bar_list = []
        for symbol in self.min_bar.index.get_level_values(1).unique():
            single_min_bar = self.min_bar.loc[(slice(None), symbol), :].reset_index(
                "symbol", drop=True
            )
            single_min_bar["close"] = single_min_bar["close"].ffill()
            for col in ["open", "high", "low"]:
                single_min_bar[col] = single_min_bar[col].combine_first(
                    single_min_bar["close"].shift(1)
                )
            single_min_bar["symbol"] = symbol
            # volumeに欠損がある場合は、それより前の欠損していない最新のvolumeで埋める
            single_min_bar["volume"] = single_min_bar["volume"].ffill()
            min_bar_list.append(single_min_bar)
        self.min_bar = (
            pd.concat(min_bar_list).set_index("symbol", append=True).sort_index()
        )
        # 外部データの欠損処理は戦略側に任せる
        # ohlcvをtimeframeの刻みにtimestampを設定しなおす
        ohlcv_df_strategy_timeframe = self._ohlcv_resample(
            self.min_bar, self.cfg["trade_config"]["strategy_timeframe"]
        )
        ohlcv_start_date = ohlcv_df_strategy_timeframe.index.levels[0][0]
        ohlcv_end_date = ohlcv_df_strategy_timeframe.index.levels[0][-1]
        # fr_dfの期間をohlcvに合わせる(fr_dfがohlcvより長いとmarkPriceの欠損処理で差分のopenがないのに参照してエラーがでる)
        if not self.fr_df.empty:
            self.fr_df = self.fr_df.loc[
                pd.IndexSlice[ohlcv_start_date:ohlcv_end_date, :], :
            ]
        # 外部データの期間をohlcvの期間に合わせる(外部データがohlcvの期間より長いと欠損が発生する)
        self.external_bars = [
            df.loc[pd.IndexSlice[ohlcv_start_date:ohlcv_end_date, :], :]
            for df in self.external_bars
        ]

        # FundingRateヒストリカルデータの欠損値処理
        self.fr_df = self.preprocess_fr_df(self.fr_df)

        # ohlcv と 外部データを結合
        self.raw_df = pd.concat(
            [ohlcv_df_strategy_timeframe] + self.external_bars, axis=1
        )
        self.raw_df.index.name = "timestamp"  # concat で消えてそうなので再度設定

        return self.raw_df

    def initialize(self) -> None:
        """バックテストの初期化"""
        # データハンドラの生成
        self.data_handler = BaseDataHandler(self.cfg, self.min_bar, self.fr_df)
        # 注文と約定のイベントの管理
        self.event_handler = BaseEventHandler(self.cfg)
        # ポジションの管理
        self.pos_manager = BasePosManager(
            self.data_handler, self.event_handler, self.cfg
        )
        # 注文の約定の管理(約定のイベントを発生させる)
        self.exec_handler = BaseExecHandler(
            self.event_handler, self.data_handler, self.pos_manager, self.cfg
        )
        # 統計情報の管理
        self.stats = BaseStats(
            self.data_handler, self.pos_manager, self.event_handler, self.cfg
        )

    def _run(self, strategy: BaseStrategy) -> None:
        """バックテストの実行

        Args:
            signals (pd.DataFrame): シグナル
        """
        # 1分おきに実行するように調整
        warmup = 0
        for i in tqdm(
            range(
                0,
                self.data_handler.min_length,
                len(self.cfg["backtester_config"]["symbol"]),
            ),
            desc="Backtest Progress",
            disable=not self.logging_enabled,
        ):
            if warmup < self.cfg["trade_config"]["warmup_period"]:
                # timescaleのオーダータイミングになったら、raw_dfを次のバーへ
                # latest_timestampは現在の時刻, next_order_timestampは次のオーダーの予定時刻(>= latest_timestamp)
                if (
                    self.data_handler.latest_timestamp
                    == self.data_handler.next_order_timestamp
                ):
                    self.data_handler.step()
                    warmup += 1
                self.pos_manager.take_snapshot()
                self.data_handler.min_step()
                continue
            elif warmup == self.cfg["trade_config"]["warmup_period"]:
                self.pos_manager.eval_starttime = self.data_handler.latest_timestamp
                warmup += 1

            # Funding Feeを付与・徴収
            self.pos_manager.update_funding_fee()
            # (本戦略の)1分おきの約定判定
            # └ 1分おきに実行するだけに調整
            # 今の時刻のactive_ordersの約定判定
            self.exec_handler.execute()
            # ポジションの統計量を計算
            self.pos_manager.calc_statistic()
            self.pos_manager.take_snapshot()
            if self.pos_manager.forced_liquidation:
                return

            if (
                self.data_handler.latest_timestamp
                == self.data_handler.next_order_timestamp
            ):
                # 現状のデータ+特徴量での発注内容を取得
                order_list = strategy.get_orders(
                    self.data_handler.latest_timestamp,
                    self.data_handler.latest_bar,
                    self.data_handler.latest_signal,
                    self.pos_manager.asset_info,
                )
                # get_ordersの発注情報にsymbolがあるか確認(MessageOnlyOrderの場合はパス)
                for order in order_list:
                    self._check_order_symbol(order)
                order_dict = {
                    symbol: list(
                        filter(lambda order: order.symbol == symbol, order_list)
                    )
                    for symbol in self.cfg["backtester_config"]["symbol"]
                }
                # 発注内容をevent_handlerに記録
                for symbol, orders in order_dict.items():
                    for order in orders:
                        hydra.utils.log.info(order.message) if order.message else None
                        if isinstance(order, MessageOnlyOrder):
                            continue
                        if order.minutes_to_expire is None:
                            # minutes_to_expireがストラテジーによって指定されていない場合は、デフォルトとしてstrategy_timeframeとする
                            order.minutes_to_expire = self.strategy_timeframe
                        # TODO: ここでMARKETに直される処理は変える
                        _type = self._check_order(order, symbol)
                        order_event = OrderEvent(
                            type=_type,
                            side=order.side,
                            size=abs(order.size),
                            price=order.price,
                            timestamp=self.data_handler.latest_timestamp,
                            minutes_to_expire=order.minutes_to_expire,
                            exit=order.exit,
                            exit_id=order.exit_id,
                            params=order.params,
                            triggered_timestamp=None,
                        )
                        self.event_handler.append_order_event(order_event, symbol)
                        self.event_handler.append_order_history(order_event, symbol)
                self.data_handler.step()
            # 次のバーへ
            self.data_handler.min_step()

    def run(self, signals: pd.DataFrame, strategy: BaseStrategy) -> None:
        # テスト期間の初期化
        self.data_handler.initialize(self.raw_df, signals)
        # シグナルを用いてバックテストを行う.
        self._run(strategy)
        # 統計量の計算
        self.stats.make_stats()

    def _check_order_symbol(self, order: Order) -> None:
        # orderにsymbol情報があるかを確認
        if not isinstance(order, MessageOnlyOrder):
            if not hasattr(order, "symbol"):
                raise SymbolNotFound("Order Symbol is not set")
            elif order.symbol is None:
                raise SymbolNotFound("Order Symbol is None")

    def _check_order(self, order: Order, symbol: str) -> str:
        """stop orderの場合に正しい方向に価格を設定できているかチェックする.間違いの方向になっている場合には修正する.

        Args:
            order (Order): get_ordersで返されたorder

        Returns:
            str: orderのtype
        """
        _type = order.type
        if _type == "MARKET":
            return _type
        elif _type == "LIMIT":
            # 即時約定するlimitオーダーはtake_limitオーダーに変更する
            if (
                order.side == "BUY"
                and order.price
                > self.data_handler.latest_bar.close.values[
                    self.data_handler.symbol_idx[symbol]
                ]
            ):
                _type = "TAKE_LIMIT"
            if (
                order.side == "SELL"
                and order.price
                < self.data_handler.latest_bar.close.values[
                    self.data_handler.symbol_idx[symbol]
                ]
            ):
                _type = "TAKE_LIMIT"
            return _type
        else:
            # 有利な方向へのstopオーダーはmarketオーダーに変更する
            if (
                order.side == "BUY"
                and order.price
                < self.data_handler.latest_bar.close.values[
                    self.data_handler.symbol_idx[symbol]
                ]
            ):
                _type = "MARKET"
            if (
                order.side == "SELL"
                and order.price
                > self.data_handler.latest_bar.close.values[
                    self.data_handler.symbol_idx[symbol]
                ]
            ):
                _type = "MARKET"
            return _type

    def _ohlcv_resample(
        self, df: pd.DataFrame, strategy_timeframe: str
    ) -> pd.DataFrame:
        """ohlcvを指定した時間足にリサンプリングする

        Args:
            df (pd.DataFrame): ohlcv
            strategy_timeframe (str): リサンプリングする時間足

        Returns:
            pd.DataFrame: リサンプリングされたohlcv
        """
        # timeframeに合わせてリサンプリングする
        df_list = []
        for symbol in self.cfg["backtester_config"]["symbol"]:
            df_ohlc = (
                df.loc[(slice(None), symbol), ["open", "high", "low", "close"]]
                .reset_index("symbol", drop=True)
                .resample(strategy_timeframe, origin="start_day")
                .agg(
                    {
                        "open": "first",
                        "high": "max",
                        "low": "min",
                        "close": "last",
                    }
                )
            )
            df_volume = (
                df.loc[(slice(None), symbol), ["volume"]]
                .reset_index("symbol", drop=True)
                .resample(strategy_timeframe, origin="start_day")
                .sum()
            )
            df_ohlcv = pd.concat([df_ohlc, df_volume], axis=1)
            df_ohlcv["symbol"] = symbol
            df_list.append(df_ohlcv)
        df = pd.concat(df_list).set_index("symbol", append=True).sort_index()
        return df

    def _external_data_resample(
        self, df: pd.DataFrame, strategy_timeframe: str
    ) -> pd.DataFrame:
        """外部データを指定した時間足にリサンプリングする

        Args:
            df (pd.DataFrame): 外部データ
            strategy_timeframe (str): リサンプリングする時間足

        Returns:
            pd.DataFrame: リサンプリングされた外部データ
        """
        # TODO データの性質によってリサンプリング方法が変わりそう
        df_list = []
        for symbol in self.cfg["backtester_config"]["symbol"]:
            df_ = (
                df.loc[(slice(None), symbol), :]
                .reset_index("symbol", drop=True)
                .resample(strategy_timeframe, origin="start_day")
                .last()
            )
            df_["symbol"] = symbol
            df_list.append(df_)
        df = pd.concat(df_list).set_index("symbol", append=True).sort_index()
        return df


class SymbolNotFound(Exception):
    pass
