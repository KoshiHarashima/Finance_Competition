# Standard Library
from collections import deque
from typing import Optional

# Local Library
from ..utils.custom_types import CloseEvent, Fill, OrderEvent


class BaseEventHandler:
    def __init__(self, cfg: dict) -> None:
        """イベントを管理するクラス"""
        self.order_events: dict[str, deque[OrderEvent]] = {
            symbol: deque() for symbol in cfg["backtester_config"]["symbol"]
        }
        self.fill_events: dict[str, list[Fill]] = {
            symbol: [] for symbol in cfg["backtester_config"]["symbol"]
        }
        self.close_events: dict[str, list[CloseEvent]] = {
            symbol: [] for symbol in cfg["backtester_config"]["symbol"]
        }
        self.order_history: dict[str, list[OrderEvent]] = {
            symbol: [] for symbol in cfg["backtester_config"]["symbol"]
        }
        self.expired_orders: dict[str, list[OrderEvent]] = {
            symbol: [] for symbol in cfg["backtester_config"]["symbol"]
        }

    def append_order_event(self, order: OrderEvent, symbol: str) -> None:
        """order_eventsにorderを追加する

        Args:
            order (OrderEvent): order event
        """
        # MARKETの場合は先頭に追加する
        if order.type == "MARKET":
            self.order_events[symbol].appendleft(order)
        else:
            self.order_events[symbol].append(order)

    def append_order_history(self, order: OrderEvent, symbol: str) -> None:
        """order_historyにorderを追加する

        Args:
            order (OrderEvent): order event
        """
        self.order_history[symbol].append(order)

    def append_fill_event(self, fill: Fill, symbol: str) -> None:
        """fill_eventsにfillを追加する

        Args:
            fill (Fill): fill event
        """
        self.fill_events[symbol].append(fill)

    def append_close_event(self, close: CloseEvent, symbol: str) -> None:
        """close_eventsにcloseを追加する

        Args:
            close (CloseEvent): close event
        """
        self.close_events[symbol].append(close)

    def append_expired_order(self, order: OrderEvent, symbol: str) -> None:
        """expired_ordersにorderを追加する

        Args:
            order (OrderEvent): order event
        """
        self.expired_orders[symbol].append(order)

    def pop_order_event(self, symbol: str) -> Optional[OrderEvent]:
        """order_eventsからorderを取り出す

        Returns:
            Optional[OrderEvent]: order event
        """
        if len(self.order_events[symbol]) == 0:
            return None
        return self.order_events[symbol].popleft()
