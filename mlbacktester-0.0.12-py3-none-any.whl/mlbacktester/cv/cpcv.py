# Standard Library
import concurrent.futures
import os
import pickle
import shutil
from collections import deque
from concurrent.futures import ProcessPoolExecutor
from typing import Any, Optional

# Third Party Library
import numpy as np
import pandas as pd
from IPython.display import display  # noqa
from tqdm import tqdm

from ..bt import BackTester
from ..strategy.base_strategy import BaseStrategy
from ..utils.logging_utils import log_info_if_enabled

# Local Library
from .cv import CV


class CPCV(CV):
    def __init__(
        self,
        min_bar: pd.DataFrame,
        fr_df: pd.DataFrame,
        external_bars: list[pd.DataFrame],
        strategy: BaseStrategy,
        cfg: dict,
        output_path: Optional[str],
    ) -> None:
        """
        min_bar: backtest_timeframe間隔のohlcv
        fr_df: FundingRateヒストリカルデータ
        external_bars: 戦略に必要なohlcv以外のデータのリスト
        strategy: Strategyクラス

        n_path: int
            CV経路数
        """
        super().__init__(min_bar, fr_df, external_bars, strategy, cfg, output_path)

        # バックテスト経路数の指定
        self._n_path = cfg["cv"]["n_path"]
        self._n_split = self._n_path + 1

        # cpcv用の設定
        self.n_purge = cfg["cv"]["n_purge"]

        # グラフを描画するかどうか選択
        self.logging_enabled = cfg["backtester_config"]["logging"]

        # モデルを保存するかどうか選択
        self.save_model = cfg["backtester_config"]["save_model"]

    def cpcv(self, preprocessed_df: pd.DataFrame) -> list:
        """CPCV用のK-Fold

        Parameters:
        ----------
        df: pd.DataFrame
            特徴量と目的変数を格納したDataFrame


        Returns:
        ----------
        ret: list
            以下の要素を持ったリスト
            - train_idx: list
                学習期間のインデックス
            - val_idx1: list
                一つ目の検証期間のインデックス
            - val_idx2: list
                二つ目の検証期間のインデックス
        """
        length = len(preprocessed_df)
        idx = list(range(length))
        ret = []
        split_idx = [int(length * i / self._n_split) for i in range(self._n_split + 1)]
        for i in range(self._n_split):
            for j in range(i + 1, self._n_split):
                val_from1 = split_idx[i]
                val_to1 = split_idx[i + 1]
                val_from2 = split_idx[j]
                val_to2 = split_idx[j + 1]
                val_idx1 = idx[val_from1:val_to1]
                val_idx2 = idx[val_from2:val_to2]
                train_idx = []
                if val_from1 - self.n_purge > 1:
                    train_idx.append(idx[: val_from1 - self.n_purge])
                if val_to1 + self.n_purge < val_from2 - self.n_purge:
                    train_idx.append(
                        idx[val_to1 + self.n_purge : val_from2 - self.n_purge]
                    )
                if val_to2 + self.n_purge < len(idx):
                    train_idx.append(idx[val_to2 + self.n_purge :])
                ret.append([train_idx, val_idx1, val_idx2])
        return ret

    def run_get_model(
        self,
        preprocessed_df: pd.DataFrame,
        cv_num: int,
        train_idxes: list,
        val_idx1: list,
        val_idx2: list,
    ) -> list[Any]:
        # cpcvの分割にはtimestampを用いる
        # preprocessed_dfからtimestampのリストを取得するためにindexからsymbolをdropする
        # 訓練期間 -> train_idxes
        # 検証期間1 -> val_idx1
        # 検証期間2 -> val_idx2
        single_preprocessed_df = preprocessed_df.loc[
            (slice(None), self.cfg["backtester_config"]["symbol"][0]), :
        ].reset_index("symbol", drop=True)
        _train_idxes = []
        for _train_idx in train_idxes:
            _train_idxes.append(single_preprocessed_df.index[_train_idx])
        train_idxes = _train_idxes
        val_idx1 = single_preprocessed_df.index[val_idx1]
        val_idx2 = single_preprocessed_df.index[val_idx2]
        # get_modelを呼び出し学習させる
        if self.save_model:
            if os.path.exists(f"{self.output_path}/models/cv_num_{cv_num}/"):
                shutil.rmtree(f"{self.output_path}/models/cv_num_{cv_num}/")
        if not train_idxes:
            train_df = pd.DataFrame()
        else:
            train_df = pd.concat(
                [
                    preprocessed_df.loc[(train_idx, slice(None)), :].copy()
                    for train_idx in train_idxes
                ],
                axis=0,
            )
        # 訓練期間のデータを使ってモデルを学習
        # dfの構造は
        # timestamp           | symbol  | feature1 | feature2 | ...
        # 2020-01-01 00:00:00 | BTCUSDT | 0.1      |  0.2     | ...
        #                     | ETHUSDT | 0.3      |  0.4     | ...
        # ...

        # n_pathが1で、Strategyクラスのget_modelがBaseStrategyクラスのget_modelを上書きしている時、
        # CPCVだと、train_dfが空となり、get_modelの実行で問題が起きるので、エラーを出す
        if self._n_path == 1 and (
            getattr(self.strategy, "get_model").__func__ is not BaseStrategy.get_model
        ):
            raise CPCVError(
                "If n_path is 1, cannot override get_model in BaseStrategy. n_path must be set to 2 or higher if want to use model."
            )
        else:
            model = self.strategy.get_model(train_df)

        CPCV_FOLD_FOLDER = f"{self.output_path}/models/cv_num_{cv_num}/"
        CPCV_FOLD_PATH = CPCV_FOLD_FOLDER + "model.pkl"
        os.makedirs(CPCV_FOLD_FOLDER, exist_ok=True)
        if self.save_model:
            with open(CPCV_FOLD_PATH, mode="wb") as f:
                pickle.dump(model, f)
        return [cv_num, val_idx1, val_idx2, CPCV_FOLD_FOLDER]

    def run_get_model_in_parallel(
        self,
        cv: list,
        preprocessed_df: pd.DataFrame,
        oof_model_path_df: pd.DataFrame,
        get_model_num_worker: Any,
    ) -> None:
        with ProcessPoolExecutor(max_workers=get_model_num_worker) as executor:
            futures = []
            for cv_num, (train_idxes, val_idx1, val_idx2) in enumerate(cv, 1):
                futures.append(
                    executor.submit(
                        self.run_get_model,
                        preprocessed_df,
                        cv_num,
                        train_idxes,
                        val_idx1,
                        val_idx2,
                    )
                )
            for future in tqdm(
                concurrent.futures.as_completed(futures),
                total=len(futures),
                disable=not self.logging_enabled,
                desc="CPCV Folds Progress",
            ):
                cv_num, val_idx1, val_idx2, OUTPUT_FOLDER = future.result()
                for i in range(self._n_path):  # 対象Foldが未格納のカラムに格納する
                    if pd.isna(oof_model_path_df.loc[val_idx1[0], i]):
                        oof_model_path_df.loc[val_idx1, i] = OUTPUT_FOLDER
                        break
                for i in range(self._n_path):
                    if pd.isna(oof_model_path_df.loc[val_idx2[0], i]):
                        oof_model_path_df.loc[val_idx2, i] = OUTPUT_FOLDER
                        break

    # バックテスト経路の作成
    def get_backtest_path(
        self,
        preprocessed_df: pd.DataFrame,
    ) -> tuple[set, pd.DataFrame]:
        """
        1. 経路生成数n_pathに基づき，cpcvを実行
        2. get_modelを呼び出し，受け取った学習済みモデルを保存
        3. 保存したoofの学習済みモデルのパスと，バックテスト経路の対応関係をセットで保存する


        Parameters:
        ----------
        df: pd.DataFrame
            特徴量と目的変数を格納したDataFrame
        _n_split: int
            CVの分割数
        n_purge: int
            パージングする数

        Returns:
        ----------
        val_superset: set
            foldの最後のインデックス

        oof_model_path_df: pd.DataFrame
            各列は，バックテストの経路番号を表す
            oofのモデルが格納されているディレクトリのパスを格納したデータフレーム
        """
        # processed_dfから1symbolのデータを取り出す
        single_preprocessed_df = preprocessed_df.loc[
            (slice(None), self.cfg["backtester_config"]["symbol"][0]), :
        ].reset_index("symbol", drop=True)
        cv = self.cpcv(single_preprocessed_df)

        # 結果格納用のDataFrame
        oof_model_path_df = pd.DataFrame(index=single_preprocessed_df.index)

        # foldの最後のインデックスをval_supersetに格納
        _val_superset = []
        for train_idx, val_idx1, val_idx2 in cv:
            _val_superset.append(val_idx1[-1])
            _val_superset.append(val_idx2[-1])
        val_superset = set(_val_superset)

        # cv数をカウントする変数
        for i in range(self._n_path):
            oof_model_path_df.loc[:, i] = None
        if self.cfg["backtester_config"]["get_model_num_worker"] == "max":
            get_model_num_worker = os.cpu_count()
        else:
            get_model_num_worker = self.cfg["backtester_config"]["get_model_num_worker"]
        self.run_get_model_in_parallel(
            cv,
            preprocessed_df,
            oof_model_path_df,
            get_model_num_worker,
        )
        return val_superset, oof_model_path_df

    # 全期間のorder_supersetの作成
    # 検証グループが変わるたびにget_order_subsetを実行する
    def get_signals(
        self,
        preprocessed_df: pd.DataFrame,
        val_superset: set,
        oof_model_path_df: pd.DataFrame,
    ) -> dict:
        """
        時間足データ(と必要ならば学習済みモデル)を受け取り，注文情報を決定する関数

        Parameters
        ==========
        get_signals:

        Returns
        =======
        order_superset: dict
            バックテスト経路番号をkey．
            オーダー情報のpd.DataFrame{timestamp, type_, side, size, price}をitemにもつ辞書
        """
        signal_superset = {}
        for i in range(self._n_path):
            start_idx = 0
            signal_concat = None
            for row in range(len(preprocessed_df.index.get_level_values(0).unique())):
                if row in val_superset:
                    # 参照先のモデルが変わるタイミングで推論をまとめて実行
                    end_idx = row
                    start_time = preprocessed_df.index.get_level_values(0).unique()[
                        start_idx
                    ]  # noqa
                    end_time = preprocessed_df.index.get_level_values(0).unique()[
                        end_idx
                    ]  # noqa
                    # modelの取得
                    # type: ignore
                    model_path = oof_model_path_df.iloc[row, i]
                    if self.save_model:
                        with open(model_path + "model.pkl", "rb") as f:
                            model = pickle.load(f)
                    else:
                        model = None
                    signal_subset = self.strategy.get_signal(
                        preprocessed_df.loc[pd.IndexSlice[start_time:end_time, :]],
                        model,
                    )

                    if start_idx == 0:
                        signal_concat = signal_subset
                    else:
                        signal_concat = pd.concat(
                            [signal_concat, signal_subset]
                        )  # type: ignore
                    start_idx = end_idx + 1
            signal_superset[i] = signal_concat
        return signal_superset

    def run_backtest(self, i: int, signal_superset: dict, bt: BackTester) -> list[Any]:
        signal_data = signal_superset[i]
        bt.run(signal_data, self.strategy)
        log_messages: dict = {}
        # ログを作成
        if self.logging_enabled:
            log_messages["summary_log"] = []
            divider = "=" * 17 + f" Path {i} Results " + "=" * 17
            log_messages["summary_log"].append(divider)
            summary_info, forced_liquidation_summary_info = bt.stats.summary()
            log_messages["summary_log"] += summary_info
            # forced_liquidation_summary_infoが空でない場合 (ロスカット) はlogにforced_liquidation_summary_infoを追加
            if len(forced_liquidation_summary_info) != 0:
                log_messages["summary_log"] += forced_liquidation_summary_info
            log_messages["summary_log"].append("=" * 50)
            log_dir = f"{self.output_path}/log"
            os.makedirs(log_dir, exist_ok=True)
            bt.stats.save_results(
                os.path.join(log_dir, f"logs{i}.pkl"),
                os.path.join(log_dir, f"fills{i}.pkl"),
            )
        # wandbのログを追加
        if self.cfg["backtester_config"]["use_wandb"]:
            log_messages["wandb_log"] = bt.stats.log_summary()
        else:
            log_messages["wandb_log"] = []
        stats = bt.stats.stats
        return [i, stats, log_messages]

    def run_backtests_in_parallel(
        self, signal_superset: dict, bt: BackTester, backtest_num_worker: Any
    ) -> list[np.float64]:
        bt.initialize()
        with ProcessPoolExecutor(max_workers=backtest_num_worker) as executor:
            results = []
            for i in range(self._n_path):
                results.append(
                    executor.submit(self.run_backtest, i, signal_superset, bt)
                )

            scores = []
            snapshots_list = []
            stats_deque: deque = deque()
            for result in sorted(
                concurrent.futures.as_completed(results), key=lambda f: results.index(f)
            ):
                i, stats, log_messages = result.result()
                stats_deque.append(stats)
                scores.append(stats[self.cfg["backtester_config"]["scoring_method"]])
                # ログを出力
                if self.logging_enabled:
                    for log_message in log_messages["summary_log"]:
                        log_info_if_enabled(log_message)
                # wandbにログを出力
                if self.cfg["backtester_config"]["use_wandb"]:
                    for wandb_log_message in log_messages["wandb_log"]:
                        bt.stats.output_wandb_log(wandb_log_message)

            log_dir = f"{self.output_path}/log"
            for i in range(self._n_path):
                stats = stats_deque.popleft()
                log_path = os.path.join(log_dir, f"logs{i}.pkl")

                if not os.path.exists(log_path):
                    continue

                snapshots = pd.read_pickle(log_path)
                snapshots_list.append(snapshots)
                plot_filename = {
                    symbol: os.path.join(
                        log_dir, f"backtest_performance_path{i}_{symbol}.png"
                    )
                    for symbol in self.cfg["backtester_config"]["symbol"]
                }
                # 複数シンボルバックテストの場合はポートフォリオ全体の結果を出力
                if len(self.cfg["backtester_config"]["symbol"]) > 1:
                    plot_filename["portfolio"] = os.path.join(
                        log_dir, f"backtest_performance_path{i}_portfolio.png"
                    )
                bt.stats.plot_graph(
                    self.raw_df,
                    snapshots,
                    stats,
                    plot_filename,
                )

            if (self.cfg["cv"]["n_path"] > 1) and self.logging_enabled:
                bt.stats.plot_combined_effective_margin(
                    snapshots_list,
                    self.raw_df,
                    {
                        symbol: os.path.join(
                            f"{self.output_path}",
                            f"combined_effective_margin_{symbol}.png",
                        )
                        for symbol in self.cfg["backtester_config"]["symbol"]
                    },
                )
        return scores

    def run(self) -> np.float64:
        # バックテストの実行
        bt = BackTester(self.cfg)
        # データをtimeframeに合わせて整形し、テスト期間のみを抽出
        self.raw_df = bt.data_initialize(self.min_bar, self.external_bars, self.fr_df)
        log_info_if_enabled(
            "Preprocessing: Starting data preparation.", self.logging_enabled
        )
        preprocessed_df = self.strategy.preprocess(self.raw_df.copy())
        log_info_if_enabled(
            "Preprocessing: Data preparation completed.", self.logging_enabled
        )

        log_info_if_enabled("Modeling: Starting model training.", self.logging_enabled)

        val_superset, oof_model_path_df = self.get_backtest_path(preprocessed_df)

        log_info_if_enabled("Modeling: Model training completed.", self.logging_enabled)

        log_info_if_enabled(
            "Signal Generation: Starting model inference.", self.logging_enabled
        )
        signal_superset = self.get_signals(
            preprocessed_df, val_superset, oof_model_path_df
        )
        log_info_if_enabled(
            "Signal Generation: Model inference completed.", self.logging_enabled
        )

        log_info_if_enabled("Backtesting: Starting backtest.", self.logging_enabled)
        if self.cfg["backtester_config"]["backtest_num_worker"] == "max":
            backtest_num_worker = os.cpu_count()
        else:
            backtest_num_worker = self.cfg["backtester_config"]["backtest_num_worker"]

        scores = self.run_backtests_in_parallel(
            signal_superset, bt, backtest_num_worker
        )
        log_info_if_enabled("Backtesting: Backtest completed.", self.logging_enabled)

        log_info_if_enabled(
            f"Backtesting: Scores {[round(score, 3) for score in scores]}",
            self.logging_enabled,
        )

        score = np.round(np.mean(scores), 5)
        return score  # type: ignore


class CPCVError(Exception):
    pass
