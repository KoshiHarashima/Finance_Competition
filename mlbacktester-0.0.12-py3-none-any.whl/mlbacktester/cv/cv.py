from datetime import datetime, timedelta, timezone
from typing import Optional

import hydra
import pandas as pd
import wandb

from ..strategy.base_strategy import BaseStrategy


class CV:
    def __init__(
        self,
        min_bar: pd.DataFrame,
        fr_df: pd.DataFrame,
        external_bars: list[pd.DataFrame],
        strategy: BaseStrategy,
        cfg: dict,
        output_path: Optional[str],
    ) -> None:
        if output_path is not None:
            self.output_path = output_path
        else:
            try:
                self.output_path = (
                    hydra.core.hydra_config.HydraConfig.get().runtime.output_dir
                )
            except Exception:
                self.output_path = "./"
        self.min_bar = min_bar
        self.fr_df = fr_df
        self.external_bars = external_bars
        self.strategy = strategy
        self.cfg = cfg
        # wandb
        if cfg["backtester_config"]["use_wandb"]:
            tz_jst = timezone(timedelta(hours=9))
            strategy_name = (
                cfg["strategy_config"]["file_path"].split("/")[-1].replace(".py", "")
            )
            run_name = (
                datetime.now(tz_jst).strftime("%Y%m%d-%H%M%S") + "-" + strategy_name
            )
            wandb.init(
                project=cfg["wandb"]["pjt_name"],
                name=run_name,
                entity=cfg["wandb"]["entity"],
                config=cfg,
                tags=cfg["wandb"]["tag"],
            )

    def finish(self) -> None:
        if self.cfg["backtester_config"]["use_wandb"]:
            wandb.finish()
