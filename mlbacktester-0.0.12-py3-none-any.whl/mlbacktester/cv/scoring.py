import json
import sys
from datetime import date, datetime
from importlib import import_module
from typing import Optional

import numpy as np
import pandas as pd
from omegaconf import DictConfig

from ..strategy.base_strategy import BaseStrategy
from ..utils.config import override_cfg
from ..utils.logging_utils import log_info_if_enabled
from .cpcv import CPCV


# date, datetimeの変換関数
def json_serial(obj: object) -> Optional[str]:
    # 日付型の場合には、文字列に変換します
    if isinstance(obj, (datetime, date)):
        return obj.isoformat()
    # 上記以外はサポート対象外.
    raise TypeError("Type %s not serializable" % type(obj))


def read_dataframe(path: str) -> pd.DataFrame:
    """パスからDataFrameを読み込み"""
    if ".pkl" in path:
        df = pd.read_pickle(path)
    elif ".csv" in path:
        df = pd.read_csv(path)
        df["timestamp"] = pd.to_datetime(df["timestamp"], format="mixed")
        df = df.set_index(["timestamp", "symbol"]).sort_index()
    else:
        ValueError(f"Path {path} is invalid.")
    return df


class Scoring:
    supported_cv = {
        "cpcv": CPCV,
    }

    def __init__(
        self,
        config: DictConfig,
        raw_df: Optional[pd.DataFrame] = None,
        fr_df: Optional[pd.DataFrame] = None,
        external_dfs: Optional[list[pd.DataFrame]] = None,
        Strategy: Optional[BaseStrategy] = None,
    ) -> None:
        """Backtester

        Args:
            config (Optional[dict], optional): config辞書形式.必要なキーを用意する必要がある. Defaults to None.
            raw_df (Optional[pd.DataFrame], optional): データ. Defaults to None.
            fr_df (Optional[pd.DataFrame], optional): FundingRateデータ. Defaults to None.
            external_dfs (Optional[list[pd.DataFrame]]): ohlcv以外の戦略に必要なデータのリスト. Defaults to None.
            Strategy (Optional[BaseStrategy], optional): ストラテジー. Defaults to None.

        Raises:
            ValueError: config_file or config must be specified
            KeyError: configにbacktester_configがない
            KeyError: configにtrade_configがない
        """
        # yamlからconfigを読み込む
        if config is not None:
            cfg = override_cfg(cfg=config)
        else:
            raise ValueError("hydra config must be specified")

        # configのチェック
        cfg = self._check_cfg(cfg)
        # データの読み込み
        if raw_df is not None:
            raw_df_ = raw_df
        else:
            raw_df_ = read_dataframe(cfg["backtester_config"]["ohlcv_data_path"])
        # FundingRateのデータ読み込み
        if fr_df is not None:
            fr_df_ = fr_df
        else:
            fr_data_path = cfg["backtester_config"].get("fr_data_path", None)
            if fr_data_path is not None:
                fr_df_ = read_dataframe(fr_data_path)
            else:
                fr_df_ = pd.DataFrame(columns=["fundingRate", "markPrice"])
        if external_dfs is not None:  # 外部データの読み込み
            external_dfs_ = external_dfs
        else:
            external_dfs_ = []
            if (
                "external_data_paths" in cfg["backtester_config"]
                and cfg["backtester_config"]["external_data_paths"]
            ):
                for external_df_path in cfg["backtester_config"]["external_data_paths"]:
                    external_df = read_dataframe(external_df_path)
                    external_dfs_.append(external_df)
        if Strategy is not None:
            strategy = Strategy(cfg)  # type: ignore
        else:
            sys.path.append(cfg["strategy_config"]["file_path"].rsplit("/", 1)[0])
            strategy_module_name = (
                cfg["strategy_config"]["file_path"].split("/")[-1].replace(".py", "")
            )
            strategy = import_module(strategy_module_name).Strategy(cfg)
        if cfg["backtester_config"].get("output_path", None) is not None:
            output_path = cfg["backtester_config"]["output_path"]
        else:
            output_path = None
        self.scoring = self.supported_cv[cfg["cv"]["type"]](
            min_bar=raw_df_,
            fr_df=fr_df_,
            external_bars=external_dfs_,
            strategy=strategy,
            cfg=cfg,
            output_path=output_path,
        )

        log_info_if_enabled(
            json.dumps(cfg, indent=4, default=json_serial),
            cfg["backtester_config"]["logging"],
        )

    def _check_cfg(self, cfg: dict) -> dict:
        # self.cfgのチェック
        if cfg.get("backtester_config") is None:
            raise KeyError("backtester_config is not found in config file")
        if cfg.get("trade_config") is None:
            raise KeyError("trade_config is not found in config file")
        # 評価指標のチェック
        scoring_method = ["annual_sharpe_ratio", "average_annual_return"]
        cfg_scoring_method = cfg["backtester_config"].get("scoring_method", None)
        if cfg_scoring_method not in scoring_method:
            if cfg_scoring_method is None:
                log_info_if_enabled(
                    "Scoring_method is not set. Set to annual_sharpe_ratio",
                    cfg["backtester_config"]["logging"],
                )
            else:
                log_info_if_enabled(
                    f"{cfg_scoring_method} is not a configurable scoring method({scoring_method}). Set to annual_sharpe_ratio",
                    cfg["backtester_config"]["logging"],
                )
            cfg["backtester_config"]["scoring_method"] = "annual_sharpe_ratio"
        return cfg

    def run(self) -> np.float64:
        return self.scoring.run()

    def finish(self) -> None:
        self.scoring.finish()
